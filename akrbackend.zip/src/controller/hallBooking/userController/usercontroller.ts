import { Request, Response } from 'express';
import { config } from '../../../config/config.json';
import logger from '../../../utils/logger/logger';
import DB from '../../../database/sql_db/db_connection_factory';
import * as sql from 'mssql';

import * as jwt from 'jsonwebtoken';
import { CommonBusinessService } from '../../../utils/business';

export default class UserController {
  public async login(req: Request, res: Response) {
    let commonBussiness = new CommonBusinessService();
    let party_logid = req.body.party_logid ? req.body.party_logid : '';
    let party_logpwd = req.body.party_logpwd ? req.body.party_logpwd : '';
    try {
      let connection = new DB();

      const getUserQuery = `select * from MasterEmployee where EmpStatus='live'`;

      let result = await connection.ERP_db(getUserQuery);
      if (result.rowsAffected[0] === 0) {
        res.status(config.statusCode.successful).json({
          data: {},
          messege: 'invalid user Id',
        });
      } else {
        if (result.recordset[0].party_logpwd === party_logpwd) {
          let token = commonBussiness.generateAuthToken(party_logid);
          res.status(config.statusCode.successful).json({
            messege: 'Sucessfully logged-in',
            data: { userDetails: result.recordsets[0], auth_token: token },
          });
        } else {
          res.status(config.statusCode.successful).json({
            messege: 'incorrect password',
          });
        }
      }
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async logout(req: Request, res: Response) {
    try {
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
