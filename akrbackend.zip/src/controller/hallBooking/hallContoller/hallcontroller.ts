import { Request, Response } from 'express';
import { config } from '../../../config/config.json';
import DB from '../../../database/sql_db/db_connection_factory';

import logger from '../../../utils/logger/logger';
import moment = require('moment');
import * as _ from 'lodash';

export default class hallController {
  public async getHallDetails(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getDetailsQuery = `exec stp_slotPivot`;

      let result = await connection.ERP_db(getDetailsQuery);
      res
        .status(config.statusCode.successful)
        .json({ data: result.recordsets[0] });
    } catch (err) {
      console.log('getHallDetails-error:', err);
      logger.error(`getHallDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
//for getting hall details

  public async getProcess(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getProcessQuery = `select mainProcess,duration from MasterDyeProcessCode`;
      let result = await connection.ERP_db(getProcessQuery);
      let test = _.map(result.recordset, (value) => {
        return value;
      });

      res.status(config.statusCode.successful).json({ data: test });
    } catch (err) {
      console.log('getProcess-error:', err);
      logger.error(`getProcess-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async getHall(req: Request, res: Response) {
    try {
      let connection = new DB();
      const getHallQuery = `select * from `;
      let result = await connection.ERP_db(getHallQuery);
      let hall = _.map(result.recordset, (value) => {
        return value;
      });
      res.status(config.statusCode.successful).json({ data: hall});
    } catch (err) {
      console.log('Get-hall-error :', err);
      logger.error(`Get-hall-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async bookHall(req: Request, res: Response) {
    
  }
  public async getBookedHall(req: Request, res: Response) {
    let { userName } = req.query;
    try {
      let connection = new DB();

      const getBookedQuery = `select * from  `;

      let result = await connection.ERP_db(getBookedQuery);

      res.status(config.statusCode.successful).json({ data: result.recordset });
    } catch (err) {
      logger.error(`getBooked-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
 
  public async getHallEligibility(req: Request, res: Response) {
    let { userName } = req.query;
    try {
      let connection = new DB();

      const getEligibleQuery = `SELECT DISTINCT MachineCode as hall,RFD,White,SingleDye,DoubleDye,CapMax,CapMin  FROM TableRohiniMachineMaster where [type]='Fabric'`;

      let result = await connection.ERP_db(getEligibleQuery);

      res.status(config.statusCode.successful).json({ data: result.recordset });
    } catch (err) {
      logger.error(`geteligible-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  
}
