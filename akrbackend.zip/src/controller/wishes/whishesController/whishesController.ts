import DB from '../../../database/sql_db/db_connection_factory';
import { Request, Response } from 'express';
import * as jwt from 'jsonwebtoken';
import * as _ from 'lodash';
import { config } from '../../../config/config.json';
import logger from '../../../utils/logger/logger';

export default class BatchManagementContoller {
  public async getWish(req: Request, res: Response) {
    let KEY = req.query.id;
    try {
      let connection = new DB();

      let getWishQuery = `select a.EmployeeName,b.messege from masterEmployee A inner join TableNKwishes B on b.empid =a.EmployeeId where PayrollEmpno=${KEY} `;

      let result: any = await connection.ERP_db(getWishQuery);
      if (result.rowsAffected > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: 'sucessfully fetched' });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: '', messege: 'No records found' });
      }
    } catch (err) {
      console.log('Accounts-vendorList-error:', err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
