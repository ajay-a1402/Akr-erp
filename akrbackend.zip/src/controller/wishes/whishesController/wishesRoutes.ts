import WishesController from './whishesController';
import { Router } from 'express';

class WishRoutes {
  private wishesController = new WishesController();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get('/getWish', this.wishesController.getWish);
  }
}

const wishRoutes = new WishRoutes();
wishRoutes.init();
export default wishRoutes.router;
