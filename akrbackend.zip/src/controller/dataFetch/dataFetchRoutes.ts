import DataFetchContoller from "./dataFetchController";
import { Router } from "express";

class DataFetchRoutes {
  private dataFetchContoller = new DataFetchContoller();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get("/data", this.dataFetchContoller.getData);
    this.router.get("/cal_data", this.dataFetchContoller.getCalanderData);
    this.router.get(
      "/dedection_data",
      this.dataFetchContoller.getDetectionData
    );
  }
}

const dataFetchRoutes = new DataFetchRoutes();
dataFetchRoutes.init();
export default dataFetchRoutes.router;
