import { Request, Response } from "express";
import * as jwt from "jsonwebtoken";
import * as _ from "lodash";
import DB from "../../database/sql_db/db_connection_factory";
import { ENV } from "../../config/config.json";
import { config } from "../../config/config.json";
import logger from "../../utils/logger/logger";

export default class DataFetchContoller {
  public async getData(req: Request, res: Response) {
    let KEY = req.query.search;
    try {
      let connection = new DB();

      //   let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let result: any = await connection.ERP_db(getDataQuery);
      console.log("result", result);
      if (result.rowsAffected.length > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: "sucessfully fetched" });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: "", messege: "No records found" });
      }
    } catch (err) {
      console.log("Fetch-data-error:", err);
      logger.error(`Fetch-data-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async getCalanderData(req: Request, res: Response) {
    try {
      let connection = new DB();

      //   let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let getDataQuery = `select ROW_NUMBER() OVER (ORDER BY Expiry) id,Expiry as start,CONCAT(Unit,' - ',Points) as title,DATEADD(day, DATEDIFF(day, 0, Expiry), '03:30:00') as 'end',Points as 'desc' from forCheckListsubHR where Close_Enno is null`;
      let result: any = await connection.ERP_db(getDataQuery);

      if (result.rowsAffected.length > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: "sucessfully fetched" });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: "", messege: "No records found" });
      }
    } catch (err) {
      console.log("Fetch-cal-data-error:", err);
      logger.error(`Fetch-cal-data-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async getDetectionData(req: Request, res: Response) {
    try {
      const connection = new DB();
      const user = req.query.userId;
      const fromDate = req.query.fromDate;
      const toDate = req.query.toDate;
      const type = req.query.type;
      let getDataQuery = "";
      if (type) {
        getDataQuery = `select ROW_NUMBER()  OVER (ORDER BY a.DeductionId) AS id,a.DeductionId,c.EmployeeName,c.AEmpno, b.unitname,a.Amount,a.Deductiontype ,a.Dateandtime,a.EntryDate,a.Remarks from TableDeduction a inner join masterunit b on b.UnitID = a.UnitId inner join MasterEmployee c on c.EmpId=a.EmpId where  AEmpno=${user} and dateandtime between  '${fromDate}' and '${toDate}'`;
      } else {
        getDataQuery = `select ROW_NUMBER()  OVER (ORDER BY a.DeductionId) AS id,a.DeductionId,c.EmployeeName,c.AEmpno, b.unitname,a.Amount,a.Deductiontype ,a.Dateandtime,a.EntryDate,a.Remarks from TableDeduction a inner join masterunit b on b.UnitID = a.UnitId inner join MasterEmployee c on c.EmpId=a.EmpId where  AEmpno=${user}  and a.Deductiontype = 'Canteen' and dateandtime between  '${fromDate}' and '${toDate}'`;
      }
      // let getDataQuery = `select ROW_NUMBER()  OVER (ORDER BY DeductionId) AS id,* from TableDeduction where EmpId=(select EmpId from MasterEmployee where AEmpno=${user} )and Dateandtime between '${fromDate}' and '${toDate}'`;
      let result: any = await connection.user_db(getDataQuery, "payroll");
      if (result.rowsAffected.length > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: "sucessfully fetched" });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: "", messege: "No records found" });
      }
    } catch (err) {
      console.log("Fetch-cal-data-error:", err);
      logger.error(`Fetch-cal-data-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
}
interface MutatedRequest extends Request {
  user: any;
}
