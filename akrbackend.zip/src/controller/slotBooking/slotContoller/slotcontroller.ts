import { Request, Response } from 'express';
import { config } from '../../../config/config.json';
import DB from '../../../database/sql_db/db_connection_factory';

import logger from '../../../utils/logger/logger';
import moment = require('moment');
import * as _ from 'lodash';

export default class SlotController {
  public async getSlotDetails(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getDetailsQuery = `exec stp_slotPivot`;

      let result = await connection.ERP_db(getDetailsQuery);
      res
        .status(config.statusCode.successful)
        .json({ data: result.recordsets[0] });
    } catch (err) {
      console.log('getSlotDetails-error:', err);
      logger.error(`getSlotDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async getProcess(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getProcessQuery = `select mainProcess,duration from MasterDyeProcessCode`;
      let result = await connection.ERP_db(getProcessQuery);
      let test = _.map(result.recordset, (value) => {
        return value;
      });

      res.status(config.statusCode.successful).json({ data: test });
    } catch (err) {
      console.log('getProcess-error:', err);
      logger.error(`getProcess-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async getVessels(req: Request, res: Response) {
    try {
      let connection = new DB();
      const getVesselQuery = `SELECT DISTINCT MachineCode FROM TableRohiniMachineMaster where [type]='Fabric' `;
      let result = await connection.ERP_db(getVesselQuery);
      let vessels = _.map(result.recordset, (value) => {
        return value;
      });
      res.status(config.statusCode.successful).json({ data: vessels });
    } catch (err) {
      console.log('Get-vessel-error :', err);
      logger.error(`Get-vessel-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async bookSlot(req: Request, res: Response) {
    let { colour, process, Qty, Select_Date, Select_vessel, userName } =
      req.body;
    try {
      let connection = new DB();

      let checkEligibleQuery = '';
      switch (process.mainProcess) {
        case 'SINGLE DYEING COTTON':
        case 'SINGLE DYEING POLYSTER':
          checkEligibleQuery = `select MachineCode from TableRohiniMachineMaster where type='Fabric' and enddate>getdate() and capmax>${Qty} and CapMin<${Qty} and SingleDye='Yes' and MachineCode='${Select_vessel}'`;
          break;
        case 'DOUBLE DYEING':
        case 'CROSS DYEING':
          checkEligibleQuery = `select MachineCode from TableRohiniMachineMaster where type='Fabric' and enddate>getdate() and capmax>${Qty} and CapMin<${Qty}  and DoubleDye='Yes' and MachineCode='${Select_vessel}'`;
          break;
        case 'RFD':
          checkEligibleQuery = `select MachineCode from TableRohiniMachineMaster where type='Fabric' and enddate>getdate() and capmax>${Qty} and RFD = 'yes' and MachineCode='${Select_vessel}'`;
          break;
        case 'WHITE':
          checkEligibleQuery = `select MachineCode from TableRohiniMachineMaster where type='Fabric' and enddate>getdate() and capmax>${Qty}and WHITE = 'yes' and MachineCode='${Select_vessel}'`;
          break;
        default:
          checkEligibleQuery = `select MachineCode from TableRohiniMachineMaster where type='Fabric' and enddate>getdate() and capmax>${Qty} and CapMin<${Qty} and MachineCode='${Select_vessel}' `;
      }
      let eligibleSlot = await connection.ERP_db(checkEligibleQuery);
      if (eligibleSlot.rowsAffected[0] > 0) {
        const maxSlotQuery = `select max(slotno)+1 from TableSlotBooking `;
        let maxSlot = await connection.ERP_db(maxSlotQuery);

        const avalSlotQuery = `select starttime,dateadd(hh,${process.duration},starttime) as endTime from ForSlotBookingMatrix where DateandTime='${Select_Date}' and MachineCode ='${Select_vessel}' and Avail > ${process.duration}`;
        let availSlot = await connection.ERP_db(avalSlotQuery);

        if (availSlot.recordset.length > 0) {
          let startTime = new Date(availSlot.recordset[0].starttime);
          let endTime = availSlot.recordset[0].endTime;
          const bookSlotQuery = `Insert into TableSlotBooking(vessel,SlotNo,AkrDyeLot,BatchNo,LoadTime,UnloadTime,SlotStart,Duration,PartyName,Qty,PrcEnno,PostHour,PreHour,fabCol,oProcess,UserId) values
          ('${Select_vessel}','${maxSlot.recordset[0]['']}','0','','${moment(
            startTime
          )
            .utc()
            .format()}','${moment(endTime).utc().format()}','${moment(startTime)
            .utc()
            .format()}',
          '${
            process.duration
          }','${userName}','${Qty}','0','96','96','${colour}','${
            process.mainProcess
          }','154')`;
          let insertSlot = await connection.ERP_db(bookSlotQuery);
          if (insertSlot.rowsAffected[0]) {
            const getDetailsQuery = `exec stp_slotPivot`;
            let result = await connection.ERP_db(getDetailsQuery);

            res.status(config.statusCode.successful).json({
              messege: 'Sucessfully Slot Booked',
              data: result.recordsets[0],
            });
          } else {
            res
              .status(config.statusCode.badRequest)
              .json({ messege: 'Unable to Book Slot, Try again later' });
          }
        } else {
          res
            .status(config.statusCode.badRequest)
            .json({ messege: 'Check duriation, Try again later' });
        }
      } else {
        res
          .status(config.statusCode.badRequest)
          .json({ messege: `vessel ${Select_vessel} is not eligible` });
      }
    } catch (err) {
      console.log('Book-slot-error: ', err);
      logger.error(`error: ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async getBookedSlots(req: Request, res: Response) {
    let { userName } = req.query;
    try {
      let connection = new DB();

      const getBookedQuery = `select SlotStart as Date,Vessel,loadTime,oProcess as process,STS as Status,UnloadTime from TableSlotBooking Where  PartyName = '${userName}' `;

      let result = await connection.ERP_db(getBookedQuery);

      res.status(config.statusCode.successful).json({ data: result.recordset });
    } catch (err) {
      logger.error(`getBooked-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async getVeeselEligibility(req: Request, res: Response) {
    let { userName } = req.query;
    try {
      let connection = new DB();

      const getEligibleQuery = `SELECT DISTINCT MachineCode as vessel,RFD,White,SingleDye,DoubleDye,CapMax,CapMin  FROM TableRohiniMachineMaster where [type]='Fabric'`;

      let result = await connection.ERP_db(getEligibleQuery);

      res.status(config.statusCode.successful).json({ data: result.recordset });
    } catch (err) {
      logger.error(`geteligible-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
