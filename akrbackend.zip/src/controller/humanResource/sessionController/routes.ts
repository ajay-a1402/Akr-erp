import UserManagementSession from "./controller";
import { Router } from "express";

class HrSessionRoutes {
  private userManagementSession = new UserManagementSession();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.post("/login", this.userManagementSession.login);
  }
}

const hrSessionRoutes = new HrSessionRoutes();
hrSessionRoutes.init();
export default hrSessionRoutes.router;
