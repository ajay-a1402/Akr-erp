import { Request, Response } from "express";
import * as jwt from "jsonwebtoken";
import DB from "../../../../database/sql_db/db_connection_factory";
import { ENV } from "../../../../config/config.json";
import { config } from "../../../../config/config.json";
import { CommonBusinessService } from "../../../../utils/business";
import logger from "../../../../utils/logger/logger";
import { createImage, getImageData } from "../../../../utils/saveimage";
import * as fs from "fs";
import * as _ from "lodash";
const sharp = require("sharp");
import { Buffer } from "buffer";

let dir = ENV.LOG_DIR;
const fsPromise = fs.promises;
interface MutatedRequest extends Request {
  user: any;
}

export default class UserManagementControl {
  public async getUserDetails(req: MutatedRequest, res: Response) {
    let KEY = req.query.key;
    let user = req.user.foo;
   
    try {
      let connection = new DB();
      let getUserQuery = "";
      if (user.user_db === "veeraCloth") {
        getUserQuery = `select A.EmployeeName,B.DepartmentName,C.Designationname ,A.Empno as AEmpno,D.UnitName,A.image1 as EmpImg  from masteremployee A
          inner join MasterDepartment B on a.DepartmentId=b.DepartmentID
          inner join masterdesignation C on a.DesignationId=c.Designationid
          inner join MasterUnit D on a.UnitId=D.UnitID  where Empno=${KEY} AND A.delflag=0`;
      } else {
        getUserQuery = `select A.EmployeeName,B.DepartmentName,C.Designationname ,A.AEmpno,D.UnitName,A.image1 as EmpImg  from masteremployee A
          inner join MasterDepartment B on a.DepartmentId=b.DepartmentID
          inner join masterdesignation C on a.DesignationId=c.Designationid
          inner join MasterUnit D on a.UnitId=D.UnitID
          where A.AEmpno=${KEY} AND A.delflag=0`;
      }
      const result = await connection.user_db(getUserQuery, user.user_db);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: _.reduce(
            result.recordsets[0],
            (result, value) => {
              let newResult = result;
              let newValue = _.update(
                _.update(value, "EmpImg", (o) => {
                  if (o) {
                    let newimg = getImageData(o);
                    return newimg;
                  }
                })
              );
              newResult.push(newValue);
              return newResult;
            },
            []
          ),
          messege: "Sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.empty).json({
          status: "fail",
          messege: "No User Found",
        });
      }
    } catch (err) {
      console.log("error:", err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async saveSignature(req: MutatedRequest, res: Response) {
    let user = req.user.foo;
    let emp_id = req.body.empId;
    let user_sign = req.body.trimmedData;
    try {
      let connection = new DB();
      createImage(user_sign, emp_id)
        .then(async (img_data: any) => {
          getImageData(`0x${img_data}`);
          const insertSignQuery = `exec stp_addSignature '${emp_id}',0x${img_data},${user.user_id}`;
          await connection.user_db_procedure(
            insertSignQuery,
            user.user_db,
            (data) => {
              if (data.rowsAffected.length > 0) {
                res
                  .status(config.statusCode.successful)
                  .json({ messege: "Signature updated" });
              }
            }
          );
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (err) {
      console.log("error:", err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }

  public async saveEmpImg(req: MutatedRequest, res: Response) {
    let user = req.user.foo;
    let emp_id = req.body.empId;
    let user_Img = req.body.trimmedData;
    try {
      let connection = new DB();
      createImage(user_Img, emp_id + "_prfl").then(async (img_data: any) => {
        const InsertImgQuery = `exec stp_addEmpImg '${emp_id}',0x${img_data}`;
        await connection.user_db_procedure(
          InsertImgQuery,
          user.user_db,
          (data) => {
            if (data.rowsAffected.length > 0) {
              res
                .status(config.statusCode.successful)
                .json({ messege: "User Image updated" });
            }
          }
        );
      });
    } catch (err) {
      console.log("error:", err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }

  public async getHrSignature(req: MutatedRequest, res: Response) {
    let user = req.user.foo;
    let user_token = req.header("authorization");
    const bearer = user_token.split(" ");
    const bearerToken = bearer[1];
    let token = bearerToken;
    let hr_id = req.query.hr_id;
    try {
      let connection = new DB();
      let getHrSignQuery = "";
      if (user.user_db === "veeraCloth") {
        getHrSignQuery = `select EmpSign from TableSignatureMain where Empno=${hr_id} And delFlag=0`;
      } else {
        getHrSignQuery = `select EmpSign from TableSignatureMain where AEmpno=${hr_id} And delFlag=0`;
      }
      const result = await connection.user_db(getHrSignQuery, user.user_db);
      if (result.rowsAffected[0] > 0) {
        let imageUrl = getImageData(result.recordsets[0][0].EmpSign);
        res.status(config.statusCode.successful).json({
          data: {
            hr_image: imageUrl,
          },
          messege: "Sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.successful).json({
          data: {},
          messege: "No record Found",
        });
      }
    } catch (err) {
      console.log("error:", err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
}
