import SessionController from './sessionController';
import { Router } from 'express';

class SessionRoutes {
  private SessionController: SessionController =
    new SessionController();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get('/getuser', this.SessionController.GetUser);
  }
}
const sessionRoutes = new SessionRoutes();
sessionRoutes.init();
export default sessionRoutes.router;
