import PermissionController from './permissionController';
import { Router } from 'express';

class PermssionRoutes {
  private permissionController: PermissionController =
    new PermissionController();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get('/getusers', this.permissionController.getUsers);
    this.router.put('/updatePerms', this.permissionController.updatePermission);
  }
}
const permssionRoutes = new PermssionRoutes();
permssionRoutes.init();
export default permssionRoutes.router;
