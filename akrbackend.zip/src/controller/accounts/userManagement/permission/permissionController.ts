import { Request, Response } from 'express';
import logger from '../../../../utils/logger/logger';
import { config } from '../../../../config/config.json';
import DB from '../../../../database/sql_db/db_connection_factory';

export default class PermissionController {
  public async getUsers(req: Request, res: Response) {
    try {
      let connection = new DB();
      const getUser = `select a.UserEnno,a.PermApprov1,a.PermApprov2,a.PermBatch,a.PermBills,a.PermDel,a.SuperUser,b.PayrollEmpno,b.EmployeeName,b.EmployeeId from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  a.sts=1`;
      let result = await connection.ERP_db(getUser);
      if (result.recordset.length > 0) {
        res.status(config.statusCode.successful).json({
          status: 'success',
          messege: 'successfully fetched',
          data: result.recordset,
        });
      } else {
        res.status(config.statusCode.empty).json({
          status: 'fail',
          messege: 'User not found',
        });
      }
    } catch (err) {
      console.error('Accounts-login-error:', err);
      logger.error(`Accounts-login-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async updatePermission(req: Request, res: Response) {
    try {
      let connection = new DB();
      const user: User = req.body.user;
      const updatePermissionQuery = `update TableAccWebUserMain set PermBatch=${user.PermBatch},PermBills=${user.PermBills},SuperUser=${user.SuperUser},PermDel=${user.PermApprov2},PermApprov1=${user.PermApprov1},PermApprov2=${user.PermApprov2} where UserEnno=${user.UserEnno}`;
      let result = await connection.ERP_db(updatePermissionQuery);
      if (result.rowsAffected > 0) {
        const getUser = `select a.UserEnno,a.PermApprov1,a.PermApprov2,a.PermBatch,a.PermBills,a.PermDel,a.SuperUser,b.PayrollEmpno,b.EmployeeName from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  a.sts=1`;
        let userResult = await connection.ERP_db(getUser);
        if (userResult.recordset.length > 0) {
          res.status(config.statusCode.successful).json({
            status: 'success',
            messege: 'successfully perms added',
            data: userResult.recordset,
          });
        } else {
          res.status(config.statusCode.empty).json({
            status: 'fail',
            messege: 'Users not found',
          });
        }
      } else {
        res.status(config.statusCode.empty).json({
          status: 'fail',
          messege: 'User not found',
        });
      }
    } catch (err) {
      console.error('Accounts-login-error:', err);
      logger.error(`Accounts-login-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
interface User {
  UserEnno: number;
  PermApprov1: number;
  PermApprov2: number;
  PermBatch: number;
  PermBills: number;
  PermDel: number;
  SuperUser: number;
  EmployeeCode: number;
  EmployeeName: string;
}
