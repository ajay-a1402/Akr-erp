import UsersContoller from './uersContoller';
import { Router } from 'express';

class UsersRoutes {
  private usersContoller = new UsersContoller();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get('/getUsers', this.usersContoller.searchUser);
    this.router.post('/addUser', this.usersContoller.addUser);
    this.router.delete('/delUser', this.usersContoller.delUser);
  }
}

const usersRoutes = new UsersRoutes();
usersRoutes.init();
export default usersRoutes.router;
