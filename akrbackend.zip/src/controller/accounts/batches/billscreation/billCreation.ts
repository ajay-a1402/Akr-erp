import { Request, Response } from "express";
import { config } from "../../../../config/config.json";
import DB from "../../../../database/sql_db/db_connection_factory";
import logger from "../../../../utils/logger/logger";
import moment = require("moment");
import * as _ from "lodash";
import { CommonBusinessService } from "../../../../utils/business";
const staticQuery = {
  getBatchesQuery: `select A.*,B.EmployeeName,c.PayAllotEnno,c.FundAvailable,c.OurBankId from TablePayBatchMain A 
			inner join MasterEmployee B on A.UserId = B.EmployeeId 
			left join TablePayAllotMain c on c.PayBatchEnno = a.PayBatchEnno where a.delFlag=0 
				and A.PayBatchEnno not in (select PayBatchEnno from TablePayAllotSub)`,
};
export default class BillCreationController {
  public async getBatchdetails(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getBatchesQuery = `select A.*,B.EmployeeName,c.PayAllotEnno,c.FundAvailable,c.OurBankId from TablePayBatchMain A 
			inner join MasterEmployee B on A.UserId = B.EmployeeId 
			left join TablePayAllotMain c on c.PayBatchEnno = a.PayBatchEnno where a.delFlag=0 
				and A.PayBatchEnno not in (select PayBatchEnno from TablePayAllotSub)`;

      let result = await connection.ERP_db(getBatchesQuery);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: "sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: "no records found",
          data: [],
        });
      }
    } catch (err) {
      console.log("Accounts-vendorList-error:", err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async getBankDetails(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getBanksQuery = `
      select * from MasterOurPayBank`;

      let result = await connection.ERP_db(getBanksQuery);

      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: "sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: "no records found",
        });
      }
    } catch (err) {
      console.log("Accounts-BankList-error:", err);
      logger.error(`Accounts-BankList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async getbatchvendors(req: Request, res: Response) {
    try {
      let connection = new DB();
      let batch_enno = req.query.batch_enno;
      const getbatchVendorsQuery = `select
                                       A.*,
                                      b.PartyName,b.vendorcode,
                                      b.AccNo,b.AccName,
                                      b.BankName,b.Branch,b.IFSCode,
                                      C.BillAmount,C.BillBalance,
                                      C.BillPaidBalance,C.PreviousBatchBalance,
                                      C.Below30,C.Days30to60,C.Days60to90,
                                      C.Above90 ,
                                      d.AllotAmount,
                                      d.PayAllotSubEnno
                                    from 
                                      TablePayBatchSub A  
                                    inner join
                                       MasterPartySub b 
                                    on 
                                      b.PartyId=A.Partyid 
                                    inner join 
                                      ForPayBillBalSumSlabWise C 
                                    on 
                                      C.Partyid=a.Partyid 
                                    left join 
                                      TablePayAllotSub d
                                    on
                                       a.Partyid = d.Partyid
                                   
                                    where 
                                      a.PayBatchEnno=${batch_enno}`;

      let result = await connection.ERP_db(getbatchVendorsQuery);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: "sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: "no records found",
        });
      }
    } catch (err) {
      console.log("Accounts-batchVendorList-error", err);
      logger.error(`Accounts-batchVendorsList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async getInvoiceDetails(req: Request, res: Response) {
    try {
      let connection = new DB();
      let PartyId = req.query.party_id;
      let duration = req.query.duration;
      let getInvoiceQuery = "";
      switch (duration) {
        case "Below30":
          getInvoiceQuery = `select a.BillBalance as AllotAmount,A.*,b.PartyName from ForPayBillBalSum A inner join masterpartySub B on A.partyid = B.PartyId where B.delflag=0 and BDays<=30 and a.BillBalance != 0 and A.partyid=${PartyId} order by a.BDate ASC`;
          break;
        case "Days30to60":
          getInvoiceQuery = `select a.BillBalance as AllotAmount,A.*,b.PartyName from ForPayBillBalSum A inner join masterpartySub B on A.partyid = B.PartyId  where B.delflag=0 and BDays>30 and BDays<=60 and a.BillBalance != 0 and A.partyid=${PartyId} order by a.BDate ASC`;
          break;
        case "Days60to90":
          getInvoiceQuery = `select a.BillBalance as AllotAmount,A.*,b.PartyName from ForPayBillBalSum A inner join masterpartySub B on A.partyid = B.PartyId  where B.delflag=0 and BDays>60 and BDays<=90 and a.BillBalance != 0 and A.partyid=${PartyId} order by a.BDate ASC`;
          break;
        case "Above90":
          getInvoiceQuery = `select a.BillBalance as AllotAmount,A.*,b.PartyName from ForPayBillBalSum A inner join masterpartySub B on A.partyid = B.PartyId  where B.delflag=0 and BDays>90 and a.BillBalance != 0 and A.partyid=${PartyId} order by a.BDate ASC `;
          break;
      }

      let result = await connection.ERP_db(getInvoiceQuery);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: "sucessfully fetched",
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: "no records found",
        });
      }
    } catch (err) {
      console.log("Accounts-InvoiceList-error:", err);
      logger.error(`Accounts-InvoiceList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async createAllotment(req: MutatedRequest, res: Response) {
    try {
      let connection = new DB();
      const userId = req.user.foo.UserId;
      const PayBatchEnno = req.body.PayBatchEnno;
      const FundAvailable = req.body.availableAmount;
      const BankID = req.body.ourBankId;
      const createAllotQuery = `exec stp_updateinvoice @userId=${userId},@PayBatchEnno=${PayBatchEnno},@BankID=${BankID},@FundAvailable=${FundAvailable}`;
      let resultToSend: any = await connection.ERP_db(createAllotQuery);
      if (resultToSend.recordset.length > 0) {
        res.status(config.statusCode.successful).json({
          messege: "sucessfully Updated",
          data: resultToSend.recordset,
        });
      }
    } catch (err) {
      console.log("Accounts-allotBill-error:", err);
      logger.error(`Accounts-allotBill-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }

  public async UpdateAllotment(req: MutatedRequest, res: Response) {
    try {
      let connection = new DB();
      const userId = req.user.foo.UserId;
      const PayAllotEnno = req.body.PayAllotEnno;
      const FundAvailable = req.body.availableAmount;
      const BankID = req.body.ourBankId;
      const createAllotQuery = `update TablePayAllotMain set FundAvailable =${FundAvailable} ,UserId=${userId},OurBankId=${BankID} where PayAllotEnno=${PayAllotEnno}`;
      let result: any = await connection.ERP_db(createAllotQuery);
      if (result.rowsAffected > 0) {
        let resultToSend: any = await connection.ERP_db(
          staticQuery.getBatchesQuery
        );
        if (resultToSend.rowsAffected > 0) {
          res.status(config.statusCode.successful).json({
            messege: "sucessfully Updated",
            data: resultToSend.recordset,
          });
        } else {
          res.status(config.statusCode.successful).json({
            messege: "No records found",
            data: resultToSend.recordset,
          });
        }
      }
    } catch (err) {
      console.log("Accounts-allotBill-error:", err);
      logger.error(`Accounts-allotBill-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: "Internal server Error" });
    }
  }
  public async updateBillDetails(req: MutatedRequest, res: Response) {
    try {
      const userId = req.user.foo.UserId;
      const PayAllotEnno = req.body.PayAllotEnno;
      const PayBatchEnno = req.body.PayBatchEnno;
      const batchDetails = req.body.batchDetails;
      const selectedInvoice = req.body.selectedInvoice;
      let connection = new DB();
      let values = _.reduce(
        batchDetails,
        (o, a) => {
          let ini = [];
          ini.push(PayAllotEnno);
          ini.push(a.PayBatchEnno);
          ini.push(userId);
          ini.push(a.Partyid);
          ini.push(a.AccNo);
          ini.push(`'${a.AccName}'`);
          ini.push(`'${a.BankName}'`);
          ini.push(`'${a.Branch}'`);
          ini.push(`'${a.IFSCode}'`);
          ini.push(a.AllotAmount);
          o.push(ini);
          return o;
        },
        []
      );
      const insertQuery = `INSERT INTO TablePayAllotSub(PayAllotEnno,PayBatchEnno,UserId,Partyid,AccNo,AccName,BankName,Branch,IFSCode,AllotAmount) VALUES ${values

        .map((i) => "(" + i + ")")
        .join()}`;
      let result_2 = await connection.ERP_db(insertQuery);
      if (result_2.rowsAffected.length > 0) {
        let invoiceQueries = _.reduce(
          selectedInvoice,
          (o, a) => {
            o.push(`INSERT INTO 
                        TablePayAllotSubBill 
                        (PayAllotEnno,PayAllotSubEnno,
                          PayBatchEnno,BillGroupno,
                          Bno,Bdate,
                          PayAmount) 
                      select 
                          PayAllotEnno,PayAllotSubEnno,
                          PayBatchEnno,Billgroupno,
                          Bno,BDate,
                          ${a.AllotAmount} 
                      from 
                          TablePayAllotSub 
                      A inner join 
                        ForPayBillBalSum B 
                      on 
                        A.Partyid=b.partyid
                      where A.PayAllotEnno = ${PayAllotEnno} 
                    and 
                      A.PayBatchEnno=${PayBatchEnno} 
                    and 
                      B.Billgroupno=${a.Billgroupno} 
                    and 
                      B.Bno='${a.Bno}'
                    and 
                      B.partyid=${a.partyid}`);
            return o;
          },
          []
        );
        // ref https://stackoverflow.com/questions/55794441/node-js-how-to-return-callback-with-array-from-for-loop-with-mysql-query
        const result_3 = await Promise.all(
          invoiceQueries.map(async (insertquery) => {
            const host = await connection.ERP_db(insertquery);
          })
        )
          .then(async () => {
            let result = await connection.ERP_db(staticQuery.getBatchesQuery);

            res.status(config.statusCode.successful).json({
              messege: "sucessfully Updated",
              data: result.recordset,
            });
          })
          .catch((err) => {
            console.log("Accounts-invoiceUpdate-error", err);
            logger.error(`Accounts-invoiceUpdate-error : ${err.stack}`);
            res.status(config.statusCode.internalServer).json({
              messege: "Internal server Error",
              status: "failure",
            });
          });
      }
    } catch (err) {
      console.log("Accounts-billupdates-error", err);
      logger.error(`Accounts-billUpdates-error : ${err.stack}`);
      res.status(config.statusCode.internalServer).json({
        messege: "Internal server Error",
        status: "failure",
      });
    }
  }
}

interface MutatedRequest extends Request {
  user: any;
}
