import BatchManagementContoller from './batchManagementController';
import { Router } from 'express';

class BatchRoutes {
  private batchManagementRoutes = new BatchManagementContoller();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get('/getvendorlist', this.batchManagementRoutes.getVendorList);
    this.router.get(
      '/getVendorsWithPayments',
      this.batchManagementRoutes.getVendorsWithPayments
    );
    this.router.post(
      '/createPayBatch',
      this.batchManagementRoutes.createPayBatch
    );
    this.router.delete(
      '/deletePayBatch',
      this.batchManagementRoutes.deletePayBatch
    );
  }
}

const batchRoutes = new BatchRoutes();
batchRoutes.init();
export default batchRoutes.router;
