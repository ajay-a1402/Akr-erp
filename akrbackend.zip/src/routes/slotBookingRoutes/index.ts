import SlotController from '../../controller/slotBooking/slotContoller/slotcontroller';
import UserController from '../../controller/slotBooking/usercontroller/userController';
import { Request, Response } from 'express';

export class AppRoutes {
  public SlotController: SlotController = new SlotController();
  public UserController: UserController = new UserController();
  public SlotRoutes(app): void {
    app.route('/api/login').post(this.UserController.login);
    app.route('/api/logout').post(this.UserController.login);
    app.route('/api/processlist').get(this.SlotController.getProcess);
    app.route('/api/getSlotlist').get(this.SlotController.getSlotDetails);
    app.route('/api/getVessels').get(this.SlotController.getVessels);
    app.route('/api/refreshSlots').get(this.SlotController.getSlotDetails);
    app.route('/api/bookSlot').post(this.SlotController.bookSlot);
    app.route('/api/getbookedSlots').get(this.SlotController.getBookedSlots);
    app.route('/api/eligibility').get(this.SlotController.getVeeselEligibility);
  }
}
