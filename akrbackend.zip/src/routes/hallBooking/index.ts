import Hallcontroller from '../../controller/hallBooking/hallContoller/hallcontroller';
import UserController from '../../controller/hallBooking/usercontroller/userController';
import { Request, Response } from 'express';

export class AppRoutes {
  public Hallcontroller: Hallcontroller = new Hallcontroller();
  public UserController: UserController = new UserController();
  public SlotRoutes(app): void {
    app.route('/api/login').post(this.UserController.login);
    app.route('/api/logout').post(this.UserController.login);
    // for getting hall list
    app.route('/api/gethalllist').get(this.Hallcontroller.getHallDetails);
    app.route('/api/processlist').get(this.Hallcontroller.getProcess);
    //for individual hall
    app.route('/api/gethall').get(this.Hallcontroller.getHall);
    // for booking hall
    app.route('/api/bookHall').post(this.Hallcontroller.bookHall);
    //for getting booked hall
    app.route('/api/getbookedHall').get(this.Hallcontroller.getBookedHall);
    
  }
}
