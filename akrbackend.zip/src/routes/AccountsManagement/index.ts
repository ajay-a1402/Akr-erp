import batchRoutes from '../../controller/accounts/batches/batchManagement/batchRoutes';
import batchReviewRoutes from '../../controller/accounts/batches/batchReview/batchReviewRoutes';
import billCreationRoutes from '../../controller/accounts/batches/billscreation/billCreationRoutes';
import permissionRoutes from '../../controller/accounts/userManagement/permission/permissionRoutes';
import { CommonBusinessService } from '../../utils/business';

import BatchController from '../../controller/accounts/batches/billscreation/billCreation';
import BatchReviewController from '../../controller/accounts/batches/batchReview/batchReviewController';
import AccountsSessionController from '../../controller/accounts/sessionController/sessionController';
import userRoutes from '../../controller/accounts/userManagement/users/usersRoutes';
import sessionRoutes from '../../controller/accounts/sessionController/sessionRoutes';
export class AccountsRoutes {
  public commonBusinessService: CommonBusinessService =
    new CommonBusinessService();

  public BatchController: BatchController = new BatchController();
  public BatchReviewController: BatchReviewController =
    new BatchReviewController();
  public AccountsSessionController: AccountsSessionController =
    new AccountsSessionController();

  public AccountsRoutes(app): void {
    app.use(
      '/api/accounts/payBatch',
      this.commonBusinessService.auth,
      batchRoutes
    );
    app.use(
      '/api/accounts/batchReview',
      this.commonBusinessService.auth,
      batchReviewRoutes
    );
    app.use(
      '/api/accounts/bills',
      this.commonBusinessService.auth,
      billCreationRoutes
    );
    app.use(
      '/api/accounts/userManagemnt',
      this.commonBusinessService.auth,
      userRoutes
    );
    app
      .route('/api/accounts/auth')
      .post(this.AccountsSessionController.AuthLogin);
    app.use(
      '/api/accounts/userManagement/permission',
      this.commonBusinessService.auth,
      permissionRoutes
    );
    app.use(
      '/api/accounts/auth',
      this.commonBusinessService.auth,
      sessionRoutes
    );
  }
}
