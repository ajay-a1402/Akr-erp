import wishesRoutes from '../../controller/wishes/whishesController/wishesRoutes';
export class WishRoutes {
  public WishRoutes(app): void {
    app.use('/newYear', wishesRoutes);
  }
}
