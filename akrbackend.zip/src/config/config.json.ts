import * as dotenv from "dotenv";
import * as _ from "lodash";
export interface IENV {
  NODE_ENV: string;
  DB_HOST: string;
  DB_USER: string;
  DB_PASS: string;
  LOG_DIR: string;
  LOGIN_SECRET_KEY: string;
  HASH_SALT_ROUND: string;
  DB_PAYROLL_HOST: string;
  DB_PAYROLL_USER: string;
  DB_PAYROLL_PASS: string;
}
let ENV: any = {};
try {
  ENV = dotenv.config().parsed;
  if (_.isEmpty(ENV)) {
    console.error("~FILE .env NEED TO BE CONFIGURED~");
  }
} catch (err) {
  console.error("~FILE .env NEED TO BE CONFIGURED~");
  process.exit(1);
}

let config = {
  statusCode: {
    successful: 200,
    created: 201,
    empty: 204,
    badRequest: 400,
    Unauthorized: 401,
    Forbidden: 403,
    timeOut: 408,
    internalServer: 500,
    conflict: 409,
    preconditionFailed: 412,
    multiStatus: 207,
  },
};
export { config, ENV };
