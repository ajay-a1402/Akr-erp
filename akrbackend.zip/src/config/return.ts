export class Return {
  data: any;
  message: string;
  error: boolean;

  constructor(data: any, message: string, error: boolean) {
    this.data = data;
    this.message = message;
    this.error = error;
  }
}

export class ReturnData {
  data: any;
  message: string;
  status: ReturnStatus;
  httpStatus: number = 200;
  constructor(
    data: any,
    message: string,
    status: ReturnStatus,
    httpStatus?: number
  ) {
    this.data = data;
    this.message = message;
    this.status = status;
    this.httpStatus = httpStatus;
  }
}

export enum ReturnStatus {
  Success = 1,
  Error,
  Warning,
  Info,
}

export enum ErrorStatus {
  Severity = 'Error',
  Code = '23505',
}
