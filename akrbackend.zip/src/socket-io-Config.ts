import { App } from "./app";
import { Server, Socket } from "socket.io";
import { createServer } from "http";
import * as jwt from "socketio-jwt-auth";
// var jwtAuth = require('socketio-jwt-auth');

import { CommonBusinessService } from "./utils/business";
import { ENV } from "./config/config.json";

// export default function (app, httpServer) {
//   const io = new Server(httpServer, {
//     cors: {
//       origin: "*",
//       methods: ["GET", "POST"],
//       allowedHeaders: ["my-custom-header"],
//       credentials: true,
//     },
//   });
//   io.use(socketAuth);
//   io.on("connection", function (socket: Socket) {
//     console.log("a user connected");
//     socket.on("messege:new", (data) => {
//       console.log("data", data);
//     });
//     // whenever we receive a 'message' we log it out
//   });
//   io.on("message", function (message: any) {
//     console.log(message);
//   });
//   io.on("connect_error", function (err: any) {
//     console.log(err);
//   });
// }
let connection: any = null;

class SocketIo {
  socket: any;
  public commonBusinessService = new CommonBusinessService();
  constructor() {
    this.socket = null;
  }
  connect(httpServer) {
    const io = new Server(httpServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"],
        credentials: true,
      },
    });
    io.use(this.commonBusinessService.socketAuth);
    io.on("connection", function (socket: Socket) {
      io.emit("user-connected", socket.data);
      this.socket = socket;
    });
  }
  sendEvent(event, data) {
    this.socket.emit(event, data);
  }
  registerEvent(event, handler) {
    this.socket.on(event, handler);
  }

  static init(server: any) {
    if (!connection) {
      connection = new SocketIo();
      connection.connect(server);
    }
  }
  static getSocketConnection() {
    if (connection) {
      return connection;
    }
  }
}
export default {
  connect: SocketIo.init,
  connection: SocketIo.getSocketConnection,
};
