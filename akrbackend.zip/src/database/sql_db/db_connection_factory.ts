import * as mssql from 'mssql';
import * as util from 'util';
import logger from '../../utils/logger/logger';
import { ENV } from '../../config/config.json';

export const sqlConfig = {
  user: ENV.DB_USER,
  password: ENV.DB_PASS,
  database: 'AKRERP',
  server: ENV.DB_HOST,
  options: {
    trustedConnection: true,
    encrypt: true,
    enableArithAbort: true,
    trustServerCertificate: true,
  },
  pool: {
    max: 100,
    min: 0,
  },
};
export default class DB {
  public async ERP_db(query) {
    try {
      let sql = await new mssql.connect(sqlConfig);
      let data = await sql.query(query);
      sql.close();
      return data;
    } catch (err) {
      console.log('sql-Query-error:', err);
      logger.error(`sql-Query-error : ${err.stack}`);
    }
  }
  public async user_db(query, db) {
    try {
      let sql = await new mssql.connect({
        user: ENV.DB_PAYROLL_USER,
        password: ENV.DB_PAYROLL_PASS,
        database: db,
        server: ENV.DB_PAYROLL_HOST,
        options: {
          trustedConnection: true,
          encrypt: true,
          enableArithAbort: true,
          trustServerCertificate: true,
        },
      });
      let data = await sql.query(query);
      sql.close();
      return data;
    } catch (err) {
      console.log('sql-Query-userDB-error:', err);
      logger.error(`sql-userDB-error : ${err.stack}`);
    }
  }
  public async user_db_procedure(query, db, callback) {
    try {
      mssql.connect(
        {
          user: ENV.DB_PAYROLL_USER,
          password: ENV.DB_PAYROLL_PASS,
          database: db,
          server: ENV.DB_PAYROLL_HOST,
          options: {
            trustedConnection: true,
            encrypt: true,
            enableArithAbort: true,
            trustServerCertificate: true,
          },
        },
        function (err) {
          if (err) console.log(err);
          // create Request object
          var request = new mssql.Request();
          let data = request.query(query, (err, recordset) => {
            if (err) {
              console.log(err);
              mssql.close();
            }
            mssql.close();
            callback(recordset);
          });
        }
      );
    } catch (err) {
      console.log('sql-request-error:', err);
      logger.error(`sql-request-error : ${err.stack}`);
    }
  }
}

mssql.on('error', (err) => {
  console.log('Sql-error:', err);
  logger.error(`sql-error : ${err.stack}`);
});
