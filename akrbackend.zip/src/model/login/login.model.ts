export interface LoginDetils {
  password: string;
  userId: number;
  token: string;
}
