export interface hallDetail {
    
    name: string;
    purpose: string;
    hall:string;
    time:string;
    Date: string;
   food:Boolean;
   foodDetails:string;
   transport:Boolean;
   transportDetails:string;
  }
  