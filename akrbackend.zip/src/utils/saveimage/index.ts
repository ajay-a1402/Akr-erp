import * as fs from "fs";
import * as path from "path";
import { ENV } from "../../config/config.json";
import { getTime } from "date-fns";

const sharp = require("sharp");
import { Buffer } from "buffer";
let dir = ENV.LOG_DIR;
if (!dir) dir = path.resolve("logs");

// create directory if it is not present
if (!fs.existsSync(dir)) {
  // Create the directory if it does not exist
  fs.mkdirSync(dir);
}
const fsPromise = fs.promises;

export const createImage = async (trimmedUrl, emp_id: String) => {
  let timeString = getTime(new Date());
  let base64String = trimmedUrl.replace(/^data:image\/\w+;base64,/, "");
  //convert to binary

  var buf = Buffer.from(base64String, "base64");
  fs.writeFileSync(dir + `/${emp_id}${timeString}.jpg`, buf);
  await sharp(dir + `/${emp_id}${timeString}.jpg`)
    .jpeg({ mozjpeg: true })
    .toFile(dir + `/${emp_id}_sharp.jpg`);

  var readStream = fs.createReadStream(dir + `/${emp_id}_sharp.jpg`);
  return new Promise((resolve, reject) => {
    let data: any = [];
    readStream.on("data", (chunk) => {
      data.push(chunk.toString("hex"));
    });

    readStream.on("end", () => {
      fs.unlink(`${dir}/${emp_id}${timeString}.jpg`, () => {});
      fs.unlink(`${dir}/${emp_id}_sharp.jpg`, () => {
        resolve(data.join(""));
      });
    });
    readStream.on("error", (err) => {
      reject(err);
    });
  });
};

export const getImageData = (buffer) => {
  let buf = Buffer.from(buffer, "binary");
  var base64data = buf.toString("base64");
  return `data:image/jpg;base64,${base64data}`;
};
