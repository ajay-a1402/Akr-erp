import { App } from "./app";
import socket from "./socket-io-Config";
let appClass = new App().app;
const port = 5000;
let server = appClass.listen(port, () => {
  console.log("Node server running at port:" + port);
});
socket.connect(server);
