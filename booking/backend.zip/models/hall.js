const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const hallSchema =new Schema({
   
    hallname:{
        type:String,
        required:true,
        unique:true
    },
},{
    timestamps:true,
});

const Hall = mongoose.model('Hall',hallSchema);
module.exports = Hall;