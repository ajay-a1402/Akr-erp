
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const bookingSchema = new Schema({ 
       username:{
             type:String,
             require:true
               } ,
       guestname:{
            type:String,
            require:true
                } ,
        purpose:{
            type:String,
            require:true
              } ,
        hall:{
            type: String,
            require:true
            } ,
        meetingfrom:{
            type:Date,
            require:true
             },
        meetingto:{
            type:Date,
            require:true
             },
        food:{
            type:Boolean,
            require:true
           },
        fooddetails:{
            type:String,
            require:true
           },
        transport:{
            type:Boolean,
            require:true
           },
          
        transportdetails:{
            type:String,
            require:true
        },
    },
    
    {
            timestamps:true
        })


module.exports = booking = mongoose.model('Booking',bookingSchema);