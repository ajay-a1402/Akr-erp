const router = require('express').Router();
let Hall = require('../models/hall');

router.route('/').get((req, res) => {
  Hall.find()
    .then(users => res.json(users))
    .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/add').post((req, res) => {
  
  const hallname=req.body.hallname;

  const newHall = new Hall({hallname});

  newHall.save()
    .then(() => res.json('Hall added!'))
    .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;
