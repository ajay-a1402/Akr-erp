const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dbConfig = require('./database/db');


const app = express();
const port = process.env.PORT || 8000;

app.use(cors());
app.use(express.json());



// Configure mongoDB Database
//mongoose.set('useNewUrlParser', true);
//mongoose.set('useFindAndModify', false);
//mongoose.set('useCreateIndex', true);
//mongoose.set('useUnifiedTopology', true);

mongoose.connect(dbConfig.db).then(() => {
  console.log('Database successfully connected!')
  },
  error => {
    console.log('Could not connect to database : ' + error)
  }
  )
//routing Path
  const hallBooking = require('./routes/bookinghall');
  const usersRouter = require('./routes/users');
  const hall = require('./routes/hall');
  
  app.use('/bookinghall',hallBooking);
  app.use('/users', usersRouter);
  app.use('/halls',hall);

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});
