import React, { Component } from 'react';

import axios from 'axios';


const Booking = props => (
  <tr>
        <td>{props.booking.username}</td>
        <td>{props.booking.guestname}</td>
        <td> { props.booking.hall}</td>
        <td>{props.booking.meetingfrom}</td>
        <td>{props.booking.meetingto}</td>
        <td>{props.booking.fooddetails}</td>
        <td>{props.booking.transportdetails}</td>
  </tr>
)

export default class BookingsList extends Component {
  constructor(props) {
    super(props);

    this.deleteBooking = this.deleteBooking.bind(this)

    this.state = {bookings: []};
  }

  componentDidMount() {
    axios.get('http://localhost:8000/bookinghall')
      .then(response => {
        this.setState({ bookings: response.data })
      })
      .catch((error) => {
        console.log(error);
      })
  }

  deleteBooking(id) {
    axios.delete('http://localhost:8000/hallbooking/'+id)
      .then(response => { console.log(response.data)});

    this.setState({
      bookings: this.state.bookings.filter(el => el._id !== id)
    })
  }

  bookingList() {
    return this.state.bookings.map(currentbooking => {
      return <Booking booking={currentbooking} deleteBooking={this.deleteBooking} key={currentbooking._id}/>;
    })
  }

  render() {
    return (
      <div>
        <h3>Booked Hall</h3>
        <table className="table" style={{backgroundColor:"#ccf6ff"}}>
          <thead className="thead-light">
            <tr>
                            <th> Username</th>
                            <th>Guestname</th>
                            <th> Hall</th>
                            <th>MeetingFrom</th>
                            <th>MeetingTo</th>
                            <th>FoodDetails</th>
                            <th>TransportDetails</th>
            </tr>
          </thead>
          <tbody>
            { this.bookingList() }
          </tbody>
        </table>
      </div>
    )
  }
}