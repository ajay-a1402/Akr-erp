import React, { Component } from 'react';
import axios from 'axios';

export default class CreateUser extends Component {
    constructor(props){
            super(props);
            
            this.onChangeUsername = this.onChangeUsername.bind(this);
           // this.onChangeHall = this.onChangeHall.bind(this);
            this.onSubmit = this.onSubmit.bind(this);

            this.state ={
                username:''
              //  hall:''
               
            }
         }

        onChangeUsername(e){
            this.setState({
                username:e.target.value
            })
        }
        /*
        onChangeHall(e){
          this.setState({
            hall:e.target.value
          })
        }
              */
        onSubmit(e){
            e.preventDefault();
        
         const user = {
            username: this.state.username,
           // hall:this.state.hall
           
          }
          console.log(user);
          axios.post('http://localhost:8000/users/add',user)
          .then(res => console.log(res.data));
          this.setState({
            username:'',
         
           
          })
        }
        render(){
            return(
                 <div className='container'>
                      
                            <h3> Create New User</h3>
                              <div  className='card' style={{width:'200',backgroundColor:"powderblue"}}>
                                 <form onSubmit={this.onSubmit}>
                                    <div className='card-body'>
                                        <div className='row'>
                                        <div className='col-4'>
                                            <></>
                                        </div>
                                        <div className='col-4'>
                                           <label style={{fontFamily:'arial',fontSize:20}}>Username</label>
                                             <input type="text"
                                               required
                                               className='form-control'
                                                value={this.state.username}
                                                 onChange={this.onChangeUsername}
                                                 /><br/>
                                            
                                                    <input type="submit" value="Create User" className="btn btn-primary"  style={{marginLeft:75}}/>
                                        </div>
                                        <div className='col-4'>
                                            <></>
                                        </div>
                                        </div>
                                        
                                    </div>
                                    
                                 </form>
                               </div>
                           
                       
                 </div>
            )
      }
}
