import React, { Component } from 'react';
import axios from 'axios';

export default class CreateHall extends Component {
    constructor(props){
            super(props);
            
            this.onChangeHall = this.onChangeHall.bind(this);
            this.onSubmit = this.onSubmit.bind(this);

            this.state ={
                hallname:'',
               
            }
         }

        onChangeHall(e){
            this.setState({
                hallname:e.target.value
            })
        }
      

        onSubmit(e){
            e.preventDefault();
        
         const hall = {
            hallname: this.state.hallname,
           
          }
          console.log(hall);
          axios.post('http://localhost:8000/halls/add',hall)
          .then(res => console.log(res.data));
          this.setState({
            hallname:'',
           
          })
        }
        render(){
            return(
                 <div className='container'>
                      
                            <h3> Create New Hall</h3>
                              <div  className='card' style={{width:'200',backgroundColor:"powderblue"}}>
                                 <form onSubmit={this.onSubmit}>
                                    <div className='card-body'>
                                        <div className='row'>
                                        <div className='col-4'>
                                            <></>
                                        </div>
                                        <div className='col-4'>
                                           <label style={{fontFamily:'arial',fontSize:20}}>Hall</label>
                                             <input type="text"
                                               required
                                               className='form-control'
                                                value={this.state.hallname}
                                                 onChange={this.onChangeHall}
                                                 /><br/>
                                            
                                                    <input type="submit" value="Create New Hall" className="btn btn-primary"  style={{marginLeft:75}}/>
                                        </div>
                                        <div className='col-4'>
                                            <></>
                                        </div>
                                        </div>
                                        
                                    </div>
                                    
                                 </form>
                               </div>
                           
                       
                 </div>
            )
      }
}
