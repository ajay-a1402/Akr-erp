import React, { Component} from 'react';
import axios from 'axios';
import { DatePicker } from "rsuite";
import "rsuite/dist/rsuite.min.css";

 

 class CreateBooking extends Component{
           
        constructor(props){
            super(props);
             
            this.onChangeUsername = this.onChangeUsername.bind(this);
            this.onChangeGuestname = this.onChangeGuestname.bind(this);
            this.onChangePurpose = this.onChangePurpose.bind(this);
            this.onChangeHall = this.onChangeHall.bind(this);
            this.onChangeMeetingfrom = this.onChangeMeetingfrom.bind(this);
            this.onChangeMeetingto = this.onChangeMeetingto.bind(this);
            this.onChangeFood = this.onChangeFood.bind(this);
            this.onChangeFooddetails = this.onChangeFooddetails.bind(this);
            this.onChangeTransport = this.onChangeTransport.bind(this);
            this.onChangeTransportdetails = this.onChangeTransportdetails.bind(this);
            this.onSubmit = this.onSubmit.bind(this);
            this.state ={
                username : '',
                guestname : '',
                purpose :'',
                hall : '',
                meetingfrom : new Date(),
                meetingto: new Date(),
                food: '',
                fooddetails :'',
                transport :'',
                transportdetails :'',
                users:[],
                user:[]
            }
        }
        
     
        componentDidMount(){

                axios.get('http://localhost:8000/users/')
                .then(response =>{
                    if(response.data.length > 0){
                        this.setState({
                            users:response.data.map(user =>user.username),
                            username : response.data[0].username,
                            user:response.data.map(user  => user.hall),
                            hall:response.data[0].hall
                        })
                    }
                })
                .catch((error) => {
                    console.log(error);
                  })
        }
        onChangeUsername(e){
            this.setState({
                username : e.target.value
            })
        }
        onChangeGuestname(e){
            this.setState({
                guestname:e.target.value
            })
        }
        onChangePurpose(e){
            this.setState({
                purpose : e.target.value
            })
        }
        onChangeHall(e){
            this.setState({
                hall: e.target.value
            })
        }
        onChangeMeetingfrom(date){
            this.setState({
                meetingfrom:date
            })
        }
        onChangeMeetingto(date){
            this.setState({
                meetingto :date
            })
        }
        onChangeFood(e){
            this.setState({
                food: e.target.value
            })
        }
        onChangeFooddetails(e){
            this.setState({
                fooddetails:e.target.value
            })
        }
        onChangeTransport(e){
            this.setState({
                transport: e.target.value
            })
        }
        onChangeTransportdetails(e){
            this.setState({
                transportdetails:e.target.value
            })
        }
        onSubmit(e){
            e.preventDefault();
            const booking = {
                username :this.state.username,
                guestname:this.state.guestname,
                purpose:this.state.purpose,
                hall:this.state.hall,
                meetingfrom:this.state.meetingfrom,
                meetingto:this.state.meetingto,
                food:this.state.food,
                fooddetails:this.state.fooddetails,
                transport:this.state.transport,
                transportdetails:this.state.transportdetails
            }
            console.log(booking);
            axios.post('http://localhost:8000/bookinghall/add',booking)
            .then(res =>console.log(res.data));
            window.location = '/';
        }
        
        render(){
            return(
                <div className='container' style={{backgroundColor:"powderblue"}}>
                    <h1>Book New Hall</h1>
                    <br/>
                      <form onSubmit ={this.onSubmit}>
                         <div className='row'>
                            <div className='col-sm'>
                                <label style={{fontFamily:'arial',fontSize:20}}>Username</label>
                                   <select ref="userInput"
                                   required
                                   className="form-control"
                                   value={this.state.username}
                                   onChange={this.onChangeUsername}>
                                   {
                                     this.state.users.map(function(user) {
                                       return <option 
                                         key={user}
                                         value={user}>{user}
                                         </option>
                                     })
                                   }
                               </select>
                            </div>
                            <div className='col-sm'>
                                 <label style={{fontFamily:'arial',fontSize:20}}>GuestName</label>
                                    <input type="text"
                                        required
                                        className='form-control'
                                        value = {this.state.guestname}
                                        onChange={this.onChangeGuestname}/>

                            </div>
                            <div className='col-sm'>
                            <label style={{fontFamily:'arial',fontSize:20}}>Purpose</label>  
                               < input type="text"
                                     required
                                     className='form-control'
                                     value={this.state.purpose}
                                     onChange={this.onChangePurpose} />
                            </div>

                         </div>

                         <br/>
                         <div className='row'>
                            <div className='col-sm'>
                            <label style={{fontFamily:'arial',fontSize:20}}>Select Hall</label>  
                            <select ref="userInput"
                                   required
                                   className="form-control"
                                   value={this.state.hall}
                                   onChange={this.onChangeHall}>
                                   {
                                     this.state.user.map(function(user) {
                                       return <option 
                                         key={user}
                                         value={user}>{user}
                                         </option>
                                     })
                                   }
                               </select>
                            </div>
                            
                            <div className='col-sm'>
                               <label style={{fontFamily:'arial',fontSize:20}}>Meeting From</label>  <br/>
                               <DatePicker  
                                   
		                            selected={this.state.meetingfrom}
                                    onChange={this.onChangeMeetingfrom}
                                    format="dd-MM-yyyy HH:mm:ss" 
                    
                                   />
                            </div>
                            <div className='col-sm'>
                                 <label style={{fontFamily:'arial',fontSize:20}}>Meeting To</label> <br/>
                                   <DatePicker  
		                            selected={this.state.meetingto}
                                    onChange={this.onChangeMeetingto}
                                    format="dd-MM-yyyy HH:mm:ss" 
                    
                                   /> 
                            </div>
                         </div>
                         <br/>
                         
                         <div className='row'>
                            <div className='col-sm' >
                                <label style={{fontFamily:'arial',fontSize:20}}>Food</label> <br/>
                                 <div style={{marginLeft:20}}>
                                   
                                            <input className="form-check-input" type="radio" name ="exampleRadios" id="exampleRadio"
                                            required
                                            value={this.state.food}
                                            onChange={this.onChangeFood}
                                            checked={true}
                                         
                                            />yes <br/>
                                            <input className="form-check-input" type="radio" name ="exampleRadios" id="exampleRadio"
                                            required
                                            value={this.state.food}
                                            onChange= {this.onChangeFood}
                                            />
                                            No<br/>
                                            </div>
                                        <hr/>
                                    <label style={{fontFamily:'arial',fontSize:20}}> Food Details</label>
                                    <input type="text"
                                      required
                                      className='form-control'
                                      value={this.state.fooddetails}
                                      onChange={this.onChangeFooddetails}/>
                                    
       
                             </div>
                            <div className='col-sm'>
                                <label style={{fontFamily:'arial',fontSize:20}}>Transport</label> <br/>
                                &nbsp; <input className="form-check-input"  type="radio" name="exampleRadios" id='exampleRadio'
                                              required
                                              value={this.state.transport}
                                              onChange={this.onChangeTransport}
                                
                                            />Yes<br/>
                                   &nbsp;  <input className="form-check-input" type ="radio" name="exampleRadios" id='exampleradio'
                                              required
                                              value={this.state.transport}
                                              onChange={this.onChangeTransport}
                                              />No<br/>
                                <hr/>
                                <label style={{fontFamily:'arial',fontSize:20}}>Transport Details</label>  
                                       < input type="text"
                                          required
                                           className='form-control'
                                           value={this.state.transportdetails}
                                          onChange={this.onChangeTransportdetails} />
                        
                            </div>
                         </div>
                         <br/>
                         <div className='row'>
                            <div className='col-4'>
                                <></>
                            </div>
                            <div className='col-4'>
                                <center> 
                             
                                <input type="submit" value="Create New Hall " className="btn btn-primary" />
                              </center>
                            </div>
                            <div className='col-4'>
                                <></>
                            </div>
                         </div>
                           <br/>
                      </form>
                        
                </div>
            )
        }

}
export default CreateBooking