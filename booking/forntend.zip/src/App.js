import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route} from "react-router-dom";

import Navbar from "./components/navbar.component"


import CreateHall from "./components/createbookhall";
import CreateUser from "./components/createUser";
import BookedHall from './components/hallbooked';
import CreateNewHall from './components/createHall';

function App() {
  return (
    <Router>
      <div>
      <Navbar />
      <br/>
      
      
      <Route path="/create" component={CreateHall} />
      <Route path="/user"  component={CreateUser} />
      <Route path ="/hall" component={CreateNewHall} />
      <Route path="/" exact  component={BookedHall} />
      </div>
    </Router>
  );
}

export default App;
