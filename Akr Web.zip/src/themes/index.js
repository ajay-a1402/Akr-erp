import { createTheme, responsiveFontSizes } from '@material-ui/core';
const lightTheme = createTheme({
  palette: {
    primary: {
      light: '#83c098', //'#62a8d7',
      main: '#65b17f', //'#3b93cd',
      dark: '#467b58', //'#29668f',
      primaryBg: '#e6f7f6',
      contrastText: '#fff',
    },

    secondary: {
      light: '#fa5f86',
      main: '#ed134a',
      dark: '#910f2f',
    },
    grey: {
      50: '#f0f0f0',
      100: '#DCDCDC',
      200: '#D3D3D3',
      300: '#C0C0C0',
      400: '#A9A9A9	',
      500: '#808080',
      600: '#696969',
      700: '#778899',
      800: '#708090',
      900: '#2F4F4F',
    },
    success: {
      light: '#9bcf63',
      main: '#82c43c',
      dark: '#5b892a',
    },
    error: {
      light: '#fc7b7b',
      main: '#fc5a5a',
      dark: '#b03e3e',
    },
    warning: {
      light: '#ffab6e',
      main: '#ff974a',
      dark: '#b26933',
    },
    info: {
      light: '#73c3ff',
      main: '#50b5ff',
      dark: '#387eb2',
    },
    almostBlack: {
      0: '#ffffff',
      100: '#fafafb',
      200: '#f1f1f5',
      300: '#e2e2ea',
      400: '#d5d5dc',
      500: '#b5b5be',
      600: '#92929d',
      700: '#696974',
      800: '#44444f',
      900: '#171725',
    },
    background: {
      paper: '#fff',
      default: '#fafafb',
    },
    text: {
      primary: '#171725',
      secondary: '#92929d',
      disabled: '#e2e2ea',
      hint: '#e2e2ea',
    },
    others: {
      tableHeaderBg: {
        main: '#9e9c9c14',
      },
    },
    glassX: {
      bgColor: '#fafcff',
      laneColor: '#f2f6fa',
    },
    progress: {
      inprogress: '#ffa500',
      completed: '#65b17f',
    },
  },
  status: {
    danger: 'orange',
  },

  headerHeight: '64px',
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 900,
      lg: 1200,
      xl: 1536,
    },
  },
});

export default {
  light: responsiveFontSizes(lightTheme),
};
