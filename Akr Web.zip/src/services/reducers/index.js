import { combineReducers } from 'redux';
import snackbar from '../snackbar/reducers';
import showAdvanceSnackbar from '../snackbarAdvance/reducers';
import session from '../../scenes/slotBooking/services/session/reducer';
import slotReducer from '../../scenes/slotBooking/services/api/dashboard/reducers';
import userSession from '../../scenes/userManagement/services/session/reducer';
import userManagementReducer from '../../scenes/userManagement/services/api/reducers';
import AccountsBatchReducer from '../../scenes/Accounts/services/api/reducers/accountsBatchReducer';
import AccountsBillsReducer from '../../scenes/Accounts/services/api/reducers/billsReducer';
import AccountsBillsReviewReducer from '../../scenes/Accounts/services/api/reducers/BillsreviewReducer';
import AccountsSessionReducer from '../../scenes/Accounts/services/api/reducers/sessionReducer';

import loader from '../loader/reducers';
export default combineReducers({
  snackbar,
  showAdvanceSnackbar,
  session,
  slotReducer,
  userSession,
  userManagementReducer,
  loader,
  AccountsBatchReducer,
  AccountsBillsReducer,
  AccountsBillsReviewReducer,
  AccountsSessionReducer,
});
