import { Box, Icon, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  Text: {
    display: 'flex',
    height: '80Vh',
    justifyContent: 'center',
    alignItems: 'center',
  },
  subContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  Icon: {
    fontSize: '100px',
  },
}));
const InProgress = ({ componentText }) => {
  const classes = useStyles();
  return (
    <Box className={classes.Text}>
      <Box className={classes.subContainer}>
        <Icon className={classes.Icon}>precision_manufacturing</Icon>
        <Typography variant='h4'>{componentText} In Progress</Typography>
      </Box>
    </Box>
  );
};

export default InProgress;
