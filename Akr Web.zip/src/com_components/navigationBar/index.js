import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  MenuItem,
  Box,
  Menu,
} from '@material-ui/core';
import { AccountCircle, Menu as MenuIcon } from '@material-ui/icons';
import { Link } from 'react-router-dom';
import proptypes from 'prop-types';
import _ from 'lodash';

const useStyles = makeStyles((theme) => ({
  root: {
    zIndex: theme.zIndex.drawer + 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
  linkText: {
    color: theme.palette.almostBlack[0],
  },
  appbarLinks: {
    paddingRight: theme.spacing(1),
    textDecoration: 'none',
  },
  appbarMenu: {
    display: 'flex',
    flexGrow: 1,
  },
}));

function NavigationBar(props) {
  const { setDrawer, session, options, logout } =
    props;
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const profileOpen = Boolean(anchorEl);
  const handleDrawer = () => {
    setDrawer((drawer) => !drawer);
  };
  const handleClickProfile = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleProfileClose = () => {
    setAnchorEl(null);
  };
  const handleLogout = () => {
    logout();
    setAnchorEl(null);
    // history.push('/');
  };
  return (
    <div>
      <AppBar className={classes.root}>
        <Toolbar variant='dense'>
          {' '}
          <IconButton
            edge='start'
            className={classes.menuButton}
            color='inherit'
            aria-label='menu'
            onClick={handleDrawer}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Box className={classes.appbarMenu}>
            {options.map((option, idx) => {
              return (
                <Link
                  to={_.get(option, 'link')}
                  key={idx}
                  className={classes.appbarLinks}
                >
                  <Typography className={classes.linkText}>
                    {option.label}{' '}
                  </Typography>
                </Link>
              );
            })}
          </Box>
          <div>
            {_.get(session, 'isAuthenticated', false) && (
              <IconButton
                aria-label='account of current user'
                aria-controls='menu-appbar'
                aria-haspopup='true'
                onClick={handleClickProfile}
                color='inherit'
              >
                <AccountCircle />
              </IconButton>
            )}
          </div>
        </Toolbar>
        <Menu
          id='menu-appbar'
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          keepMounted
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          open={profileOpen}
          onClose={handleProfileClose}
        >
          {' '}
          <MenuItem onClick={() => {}}>
            {_.get(session, 'userDetails.EmployeeName', 'unknown')}
          </MenuItem>
          <MenuItem onClick={handleLogout}>Log Out</MenuItem>
        </Menu>
      </AppBar>
    </div>
  );
}

export default NavigationBar;
NavigationBar.propTypes = {
  setDrawer: proptypes.func,
  session: proptypes.object,
  options: proptypes.array,
  logout: proptypes.func,
};
