import React from 'react';
import {
  Drawer,
  Toolbar,
  Box,
  Typography,
  Icon,
  makeStyles,
  Divider,
  withWidth,
  useMediaQuery,
} from '@material-ui/core';
import { Link } from 'react-router-dom';
import _ from 'lodash';
import propTypes from 'prop-types';
import classnames from 'classnames';
import { useTheme } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  drawer: (drawer) => ({
    width: drawer.width,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  }),
  drawerPaper: (drawer) => ({
    width: drawer.width,
  }),
  drawerOpen: (drawer) => ({
    width: drawer.width,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(7) + 1,
    },
  },

  drawerText: {
    paddingLeft: theme.spacing(1),
  },
  drawerContainer: {
    padding: `0 ${theme.spacing(2)}px`,
  },
  drawerContent: {
    padding: theme.spacing(1, 1),
    textDecoration: 'none',
    color: theme.palette.primary.main,
    display: 'flex',
  },
  footer: {
    paddingBottom: 10,
  },
  footerContainer: {
    display: 'flex',
    padding: theme.spacing(1, 1),
  },
  footerText: {
    paddingLeft: theme.spacing(2),
  },
}));
const CustomDrawer = ({ options, drawer }) => {
  const classes = useStyles(drawer);
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  return (
    <>
      <Drawer
        className={classnames(classes.drawer, {
          [classes.drawerOpen]: drawer.state,
          [classes.drawerClose]: !drawer.state,
        })}
        open={drawer.state}
        variant={isBelowMd ? 'persistent' : 'permanent'}
        classes={{
          paper: classnames({
            [classes.drawerOpen]: drawer.state,
            [classes.drawerClose]: !drawer.state,
          }),
        }}
      >
        <Toolbar />
        <Box className={classes.drawerContainer}>
          {_.map(
            options,
            (value, idx) =>
              !value.hide && (
                <Link
                  to={value.link}
                  key={idx}
                  className={classes.drawerContent}
                >
                  <Icon>{value.icon}</Icon>
                  <Typography className={classes.drawerText}>
                    {value.label}
                  </Typography>
                </Link>
              )
          )}
          <Divider />
          <div className={classes.footer}>
            <Box className={classes.footerContainer}>
              <Icon>copyright</Icon>
              <Typography className={classes.footerText}>ERP AKR</Typography>
            </Box>
          </div>
        </Box>
      </Drawer>
    </>
  );
};
export default withWidth()(CustomDrawer);
CustomDrawer.propTypes = {
  options: propTypes.array.isRequired,
  drawer: propTypes.object.isRequired,
};
