import React, { useEffect } from 'react';
import { Box, TableCell, Table, TableHead, TableRow } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import PropTypes from 'prop-types';
import * as _ from 'lodash';
const useStyles = makeStyles((theme) => ({}));
export default function CustomTable(props) {
  const classes = useStyles();
  const { coldef, rowdata } = props;

  console.log('rowdata', rowdata);
  return (
    <Box>
      <Table>
        {/* {_.map(coldef, (def) => (
          <TableRow></TableRow>
        ))} */}
      </Table>
    </Box>
  );
}

CustomTable.propTypes = {
  rowdata: PropTypes.array,
  coldef: PropTypes.array,
};
