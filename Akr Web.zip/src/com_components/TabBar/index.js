import React, { useEffect } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Tabs from "@material-ui/core/Tabs";
import Box from "@material-ui/core/Box";
import { Grid, Toolbar, Tab, Typography } from "@material-ui/core";
import * as _ from "lodash";

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && <>{children}</>}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    "aria-controls": `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper,
  },
}));

export default function ScrollableTabsButtonAuto(props) {
  const { options, defaultTabId, ...rest } = props;
  const classes = useStyles();
  const [value, setValue] = React.useState(defaultTabId);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <div className={classes.root}>
      <Grid container>
        <Grid item xs={12}>
          <Toolbar position="static" color="default">
            <Tabs
              value={value}
              onChange={handleChange}
              indicatorColor="primary"
              textColor="primary"
              variant="scrollable"
              //   scrollButtons='auto'
            >
              {options.map((tab, idx) => {
                return <Tab key={tab.id} label={tab.label} value={tab.id} />;
              })}
            </Tabs>
          </Toolbar>
        </Grid>
        <Grid item xs={12}>
          {_.map(options, (tab, idx) => {
            return (
              <TabPanel
                key={tab.id}
                label={tab.label}
                value={value}
                index={tab.id}
              >
                {React.createElement(tab.tabPanel, { ...rest })}
              </TabPanel>
            );
          })}
        </Grid>
      </Grid>
    </div>
  );
}
