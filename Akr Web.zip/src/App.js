/* eslint-disable react/prop-types */
import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { CssBaseline, Snackbar } from '@material-ui/core';
import PropTypes from 'prop-types';
import { connect, useDispatch } from 'react-redux';
//mport PageNotFound from './scenes/404';
import MuiAlert from '@material-ui/lab/Alert';
import { hideAdvaceSnackbar } from './services/snackbarAdvance/actions';
import EmployeeAdmin from './scenes/userManagement/pages';
import SlotBooking from './scenes/slotBooking/pages';
import Accounts from './scenes/Accounts/pages';
import Mainpage from './scenes/main';
import Loader from './com_components/Loader';

//import WishesPage from './wishes';
import DataFetch from './scenes/dataFetch';
import TradingApp from './scenes/Trading/pages';
import { useEffect } from 'react';
//import axios from 'axios';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}

function App(props) {
  const dispatch = useDispatch();
  //creating function to load ip address from the API
  const getData = async () => {
  //  const res = await axios.get('https://geolocation-db.com/json/');
    //console.log(res.data);
  };

  useEffect(() => {
    //passing getData method to the lifecycle method
    getData();
  }, []);
  const {
    advanceSnackbar: { showAdvanceSnackbar, severity, snackbarText, onClose },
    loader,
  } = props;
  return (
    <>
      <Router>
        <div className='App'>
          <React.Fragment>
            <CssBaseline />
          </React.Fragment>
          <Switch>
            <Route exact path='/'>
              <Mainpage />{' '}
            </Route>
            <Route
              exact
              path='/employeDetails/:module'
              component={EmployeeAdmin}
            />
            <Route exact path='/slotBooking/:module' component={SlotBooking} />
            <Route path='/trading' component={TradingApp} />
            {/* <Route exact path='/trading' component={TradingApp} /> */}
            <Route path='/accounts' component={Accounts} />
            {/* <Route path='/newYear/' component={WishesPage} /> */}
            <Route path='/datafetch' component={DataFetch} />
            {/* <Route path='/newYear/:id' component={WishesPage} />
            <Route path='*' component={PageNotFound} /> */}
          </Switch>
        </div>
      </Router>
      <Snackbar
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        open={showAdvanceSnackbar}
        onClose={onClose ? () => dispatch(hideAdvaceSnackbar()) : null}
        autoHideDuration={onClose ? 2000 : null}
      >
        <Alert
          severity={severity}
          onClose={onClose ? () => dispatch(hideAdvaceSnackbar()) : null}
        >
          {snackbarText}
        </Alert>
      </Snackbar>
      <Loader {...loader}></Loader>
    </>
  );
}

const mapStateToProps = (state) => ({
  snackbar: state.snackbar,
  advanceSnackbar: state.showAdvanceSnackbar,
  loader: state.loader,
});
export default connect(mapStateToProps)(App);
App.prototype = {
  snackbar: PropTypes.object,
  advanceSnackbar: PropTypes.any,
};
