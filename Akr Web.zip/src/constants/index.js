export const API_ENDPOINTS = {
  //SESSION
  LOGIN: '/api/login',
  LOGOUT: '/api/logout',
  BOOK_SLOT: '/api/bookSlot',
  FETCH_PROCESS: '/api/processlist',
  FETCH_ELIGIBILITY: '/api/eligibility',

  FETCH_TABLE: '/api/getSlotlist',
  FETCH_VESSELS: '/api/getVessels',
  FETCH_BOOKED_SLOTS: '/api/getbookedSlots',

  //userManagement
  USER_LOGIN: '/api/hr/session/login',
  USER_LOGOUT: '/api/Spruser/logout',
  GET_EMP: '/api/Spruser/getUser',
  GET_HR_SIGN: '/api/Spruser/getHrSign',
  SAVE_SIGN: '/api/Spruser/saveSign',

  //accounts Management
  AUTH_LOGIN_ACCOUNTS: '/api/accounts/auth',
  AUTH_USER_ACCOUNTS: '/api/accounts/auth/getuser',
  FETCH_VENDOR: '/api/accounts/payBatch/getvendorlist',
  FETCH_VENDOR_BILLS: '/api/accounts/payBatch/getVendorsWithPayments',
  DELETE_PAYBATCH: '/api/accounts/payBatch/deletePayBatch',
  FETCH_BATCH_DETAILS: '/api/accounts/bills/getbatchDetails',
  FETCH_BANK_DETAILS: '/api/accounts/bills/getBankDetails',
  FETCH_BATCH_VENDORS: '/api/accounts/bills/getbatchedVendors',
  CREATE_PAYBATCH_ALLOT: '/api/accounts/bills/createAllotment',
  UPDATE_PAYBATCH_ALLOT: '/api/accounts/bills/UpdateAllotment',
  FETCH_VENDOR_INVOICE: '/api/accounts/bills/getinvoice',
  FETCH_BATCH_INVOICE: '/api/accounts/batchReview/getBatchInvoice',
  FETCH_REVIEW_BATCHES: '/api/accounts/batchReview/getBatches',
  SEARCH_USER: '/api/accounts/userManagemnt/getUsers',
  GET_USERS: '/api/accounts/userManagement/permission/getusers',
  UPDATE_PERMS: '/api/accounts/userManagement/permission/updatePerms',
  DELETE_USER: '/api/accounts/userManagemnt/delUser',
  ADD_USER: '/api/accounts/userManagemnt/addUser',
  UPDATE_BATCHES: '/api/accounts/payBatch/createPayBatch',
  UPDATE_BILLS: '/api/accounts/bills/updateBillDetails',
  UPDATE_APPROVE_STATUS: '/api/accounts/batchReview/updateApproveStatus',

  //fetch
  GET_DATA: '/getdata/data',
};
export const ACTION_TYPES = {
  //LOGIN ACTIONS CONSTANTS
  AUTH_LOGIN: 'AUTH_LOGIN',
  LOGIN_USER_SUCCESS: 'LOGIN_USER_SUCCESS',
  LOGIN_USER_INVALID: 'LOGIN_USER_INVALID',
  LOGIN_USER_ERROR: 'LOGIN_USER_ERROR',
  AUTH_LOGIN_FULFILLED: 'AUTH_LOGIN_FULFILLED',
  AUTH_LOGIN_REJECTED: 'AUTH_LOGIN_REJECTED',

  //USERMANAGEMENT CONSTANTS
  USER_AUTH_LOGOUT: 'USER_AUTH_LOGOUT',
  USER_UNAUTH_ERROR: 'USER_UNAUTH_ERROR',
  USER_LOGIN_SUCCESS: 'USER_LOGIN_SUCCESS',
  USER_LOGIN_ERROR: 'USER_LOGIN_ERROR',

  GET_EMP_SUCCESS: 'GET_EMP_SUCCESS',
  GET_EMP_PENDING: 'GET_EMP_PENDING',
  GET_EMP_FAILURE: 'GET_EMP_FAILURE',
  GET_HR_SIGN_SUCCESS: 'GET_HR_SIGN_SUCCESS',
  GET_HR_SIGN_PENDING: 'GET_HR_SIGN_PENDING',
  GET_HR_SIGN_FAILURE: 'GET_HR_SIGN_FAILURE',

  //SESSION IN USER MANAGEMENT
  USER_SESSION_TIMEOUT: 'USER_SESSION_TIMEOUT',

  //LOGGED IN USER ACTIONS
  FETCH_CURRENT_USER_PENDING: 'FETCH_CURRENT_USER_PENDING',
  FETCH_CURRENT_USER_FULFILLED: 'FETCH_CURRENT_USER_FULFILLED',
  FETCH_CURRENT_USER_REJECTED: 'FETCH_CURRENT_USER_REJECTED',
  RESET_CURRENT_USER: 'RESET_CURRENT_USER',

  //LOGOUT ACTIONS CONSTANTS
  AUTH_LOGOUT: 'AUTH_LOGOUT',
  AUTH_LOGOUT_PENDING: 'AUTH_LOGOUT_PENDING',
  AUTH_LOGOUT_FULFILLED: 'AUTH_LOGOUT_FULFILLED',
  AUTH_LOGOUT_REJECTED: 'AUTH_LOGOUT_REJECTED',
  AUTH_LOGOUT_DISMISS_ERROR: 'AUTH_LOGOUT_DISMISS_ERROR',

  //SNACK BAR ACTIONS
  SHOW_SNACKBAR: 'SHOW_SNACKBAR',
  HIDE_SNACKBAR: 'HIDE_SNACKBAR',
  SHOW_ADVANCE_SNACKBAR: 'SHOW_ADVANCE_SNACKBAR',
  HIDE_ADVANCE_SNACKBAR: 'HIDE_ADVANCE_SNACKBAR',

  //UNAUTHORIZED ERROR ACTION (INVALID TOKEN)
  UNAUTH_ERROR: 'UNAUTH_ERROR',

  //Book Slot Actions
  BOOK_SLOT_SUCCESS: 'BOOK_SLOT_SUCCESS',
  BOOK_SLOT_PENDING: 'BOOK_SLOT_PENDING',
  BOOK_SLOT_FAILURE: 'BOOK_SLOT_FAILURE',
  
  //Hall Booking Actions

  //LOADER
  SHOW_LOADER_CONFIRM: 'SHOW_LOADER_CONFIRM',
  SHOW_LOADER: 'SHOW_LOADER',
  SHOW_LOADER_SUCCESS: 'SHOW_LOADER_SUCCESS',
  HIDE_LOADER: 'HIDE_LOADER',
  SHOW_LOADER_ERROR: 'SHOW_LOADER_ERROR',
  SHOW_LOADER_WARNING: 'SHOW_LOADER_WARNING',
  //Accounts Session
  UPDATE_ACCOUNTS_SESSION: 'UPDATE_ACCOUNTS_SESSION',
  //Accounts Invoice Add
  UPDATE_BILL_PARAMS: 'UPDATE_BILL_PARAMS',
  UPDATE_BILLS_INVOICE_LIST: 'UPDATE_BILLS_INVOICE_LIST',
  UPDATE_BILLS_AVAIL_AMOUNT: 'UPDATE_BILLS_AVAIL_AMOUNT',
  UPDATE_BATCH_AMOUNT: 'UPDATE_BATCH_AMOUNT',
  UPDATE_BATCH_SELECTED: 'UPDATE_BATCH_SELECTED',
  CREATE_BATCH_SUCCESS: 'CREATE_BATCH_SUCCESS',
  CHANGE_BATCH: 'CHANGE_BATCH',
  UPDATE_SELECTED_INVOICE: 'UPDATE_SELECTED_INVOICE',
  UPDATE_BATCH_LIST: 'UPDATE_BATCH_LIST',

  //Accounts Review Invoice
  UPDATE_REVIEW_INVOICE_LIST: 'UPDATE_REVIEW_INVOICE_LIST',
};

export const SAGA_ACTION_TYPES = {
  SAGA_LOGIN_USER: 'SAGA_LOGIN_USER',
  //USERMANAGEMENT
  SAGA_USER_LOGIN: 'SAGA_USER_LOGIN',
  SAGA_USER_LOGOUT: 'SAGA_USER_LOGOUT',
  SAGA_FETCH_EMP: 'SAGA_FETCH_EMP',
  SAGA_SAVE_SIGN: 'SAGA_SAVE_SIGN',
  SAGA_FETCH_HR_SIGN: 'SAGA_FETCH_HR_SIGN',

  //Slot Booking Sagas
  SAGA_BOOK_SLOT: 'SAGA_BOOK_SLOT',

  //Accounts
  SAGA_UPDATE_BATCH: 'SAGA_UPDATE_BATCH',
  SAGA_BATCH_WITH_BILLS: 'SAGA_BATCH_WITH_BILLS',
};

export const LOADER_MODE = {
  LOADING: 'LOADING',
};
export const statusCode = {
  successful: 200,
  created: 201,
  empty: 204,
  badRequest: 400,
  Unauthorized: 401,
  internalServer: 500,
  conflict: 409,
  preconditionFailed: 412,
  multiStatus: 207,
};
