import moment from 'moment';
import _ from 'lodash';
import { useLocation } from 'react-router-dom';
import { useTheme, useMediaQuery } from '@material-ui/core';
export const isLogin = () => {
  if (localStorage.getItem('authToken')) {
    return true;
  }
  return false;
};
export const isMasterUserLogin = () => {
  if (localStorage.getItem('spr_user_authToken')) {
    return true;
  }
  return false;
};

export const isModuleAccessGranted = (
  moduleName,
  permissionType,
  permissions
) => {
  if (_.isEmpty(moduleName)) return true;
  else {
    const modulePerms = _.find(permissions, { module_name: moduleName });
    return _.get(modulePerms, `permissions.${permissionType}`, false);
  }
};

export const convertLocalTimeToGmtStr = (timeString) => {
  let t =
    !!timeString &&
    moment(timeString, 'YYYY-MM-DD HH:mm:ss Z')
      .utc()
      .format('ddd, DD MMM YYYY HH:mm:ss [GMT]');
  return t;
};

export const convertGmtToLocalTime = (timeString, format) => {
  return moment(timeString).local().format(format);
};

export function useQuery() {
  return new URLSearchParams(useLocation().search);
}

export function isValidSting(string) {
  if (string === '') {
    return false;
  } else if (string === undefined) {
    return false;
  } else if (string === null) {
    return false;
  } else {
    return true;
  }
}
export function isBelowMd() {
  const theme = useTheme();
  return useMediaQuery(theme.breakpoints.down('md'));
}
