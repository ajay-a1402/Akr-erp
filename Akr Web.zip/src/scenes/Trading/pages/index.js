import React, { useState } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import propTypes from 'prop-types';
import NavigationBar from '../../../com_components/navigationBar';
import { makeStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import { Toolbar } from '@material-ui/core';
import CustomDrawer from '../../../com_components/Drawer';
import { useRouteMatch } from 'react-router-dom/cjs/react-router-dom.min';
import PrivateRoute from '../components/PrivateRoute';
import Login from './login';
import RegistrationForm from './Register';
const drawerWidth = 190;
const useStyles = makeStyles((theme) => ({
  rootContainer: {
    marginLeft: theme.spacing(7) + 1,
  },
  shiftContent: {
    marginLeft: drawerWidth,
  },
  mainContainer: {
    padding: theme.spacing(0, 2),
    marginLeft: theme.spacing(7) + 1,
  },
}));
const TradingApp = (props) => {
  const classes = useStyles();
  const { session, logout } = props;
  const [drawer, setDrawer] = useState(false);
  let { path } = useRouteMatch();
  console.log('path', path);

  return (
    <div>
      <Switch>
        <Route exact path={`${path}/:module`} component={TradingNoAuth} />
        <PrivateRoute path={`${path}/:module/:sub`} component={TradingHome} />
      </Switch>
    </div>
  );
};
const TradingNoAuth = () => {
  return (
    <Switch>
      <Route path={`/trading/login`} component={Login} />
    </Switch>
  );
};
const TradingHome = (props) => {
  const classes = useStyles();
  const { session, logout } = props;
  let { path } = useRouteMatch();
  console.log('path', path);
  const [drawer, setDrawer] = useState(false);
  const appbarOptions = [
    {
      label: 'Home',
      // icon: icon1,
      link: '/trading/app/home',
    },
  ];
  const drawerOptions = [
    // {
    //   label: 'Slots Booking',
    //   icon: 'access_time',
    //   link: '/slotBooking/dashboard',
    // },
  ];
  return (
    <>
      <NavigationBar
        setDrawer={setDrawer}
        options={appbarOptions}
        logout={logout}
        session={session}
      />{' '}
      <Toolbar />
      <div className={classes.rootContainer}>
        <Switch>
          <Route
            exact
            path={`/trading/app/register`}
            component={RegistrationForm}
          />
        </Switch>
      </div>
      <CustomDrawer
        drawer={{ state: drawer, width: drawerWidth }}
        options={drawerOptions}
      />
    </>
  );
};
const mapDispatchToProps = (dispatch) => ({
  logout: () => dispatch(),
});
const mapStateToProps = (state) => {
  return {
    session: {},
    empDetails: {},
  };
};
connect(mapStateToProps, mapDispatchToProps)(TradingHome);
export default TradingApp;
TradingHome.propTypes = {
  session: propTypes.object,
  logout: propTypes.func,
};
TradingNoAuth.propTypes = {};
