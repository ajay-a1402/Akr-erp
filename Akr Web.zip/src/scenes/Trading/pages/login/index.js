import React from 'react';
import { Typography } from '@material-ui/core';
const Login = () => {
  return (
    <div>
      <Typography>Login</Typography>
    </div>
  );
};
export default Login;
