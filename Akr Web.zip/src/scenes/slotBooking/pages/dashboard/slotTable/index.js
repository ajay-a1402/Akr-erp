/* eslint-disable no-console */
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AgGridCustom from '../../../../../com_components/AgGridCustom';
import { AgGridColumn } from 'ag-grid-react';
import dashboardApi from '../../../services/api/dashboard';
import Axios from 'axios';
import propTypes from 'prop-types';
import _ from 'lodash';
import withWidth from '@material-ui/core/withWidth';
import { Typography, Divider, IconButton, Box } from '@material-ui/core';
import {
  withCellRenderState,
  dateCellRenderer,
  vesselCellRenderer,
} from './customCell';
import SyncIcon from '@material-ui/icons/Sync';
import moment from 'moment';
const useStyles = makeStyles((theme) => ({
  tableroot: {
    marginTop: theme.spacing(4),
    height: '80%',
  },
  tableHeading: {
    textTransform: 'uppercase',
    marginBottom: theme.spacing(2),
    color: theme.palette.grey[600],
    fontSize: '20px',
    fontWeight: 600,
  },
  dateCellContent: {
    height: '100%',
    display: 'flex',
    textAlign: 'center',
    justifyContent: 'center',

    fontWeight: 600,
    // '&:focus': {},
  },
  vesselCellContent: {
    display: 'flex',
    height: '100%',
    fontWeight: 600,
    justifyContent: 'center',
    textAlign: 'center',
    lineHeight: 'initial',
    '& .m-details': {
      display: 'flex',
      flex: 1,
      flexDirection: 'column',
      justifyContent: 'center',
    },
  },
  headingContainer: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  refreshIconButton: {
    paddingTop: 0,
    paddingLeft: theme.spacing(2),
    paddingBottom: theme.spacing(2),
  },
  subHeadingContainer: {
    display: 'flex',
  },
  tableSubHeading: {
    color: theme.palette.error.light,
  },
  elig_button: {},
}));
const SlotTable = (props) => {
  const { width, setData, data } = props;
  const classes = useStyles();
  const [vessels, setVessels] = useState();
  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState();
  const fetchData = () => {
    setLoading(true);
    dashboardApi.fetchTable(
      (res) => {
        setRowData(res.data.data);
        setLoading(false);
      },
      (err) => {
        if (!Axios.isCancel(err)) console.log(err);
        setLoading(false);
      }
    );
  };
  useEffect(() => {
    fetchData();
    setTimeout(() => {
      dashboardApi.fetchVessel(
        (res) => {
          setVessels(res.data.data);
        },
        (err) => {
          if (!Axios.isCancel(err)) console.log(err);
        }
      );
    }, 2000);
  }, []);
  const handleCellClick = (e) => {
    let data = JSON.parse(e.data[e.colDef.field]);
    if (e.colDef.field !== 'Date' && !_.inRange(data.avail, -25, 4)) {
      setData((prev) => ({
        ...prev,
        Select_Date: e.data.Date,
        Select_vessel: e.colDef.field,
      }));
    }
  };
  const handleRefresh = () => {
    window.location.reload();
  };
  return (
    <div className={classes.tableroot}>
      <Box className={classes.headingContainer}>
        <Typography variant='h4' className={classes.tableHeading}>
          Slot Table
        </Typography>

        {!_.isEmpty(data.Select_Date) && (
          <Box style={{ display: 'flex' }}>
            <Typography variant='h6' style={{ paddingRight: '50px' }}>
              <span> Date: </span>{' '}
              {moment(data.Select_Date).format(' MMMM Do YYYY')}
            </Typography>
            <Typography variant='h6'>
              <span> Vessel : </span>
              {data.Select_vessel}
            </Typography>
          </Box>
        )}

        <Box className={classes.subHeadingContainer}>
          <Typography variant='h6' className={classes.tableSubHeading}>
            **kindly Refresh Before select Slot
          </Typography>
          <IconButton
            aria-label='refresh'
            className={classes.refreshIconButton}
            onClick={handleRefresh}
          >
            <SyncIcon style={{ fontSize: 30 }} />
          </IconButton>
        </Box>
      </Box>

      <Divider />

      <AgGridCustom
        loading={loading}
        rowData={rowData}
        height={500}
        defaultColDef={{
          initialWidth: 140,
          sortable: true,
        }}
        frameworkComponents={{
          dateCellRenderer: withCellRenderState(dateCellRenderer),
          vesselCellRenderer: withCellRenderState(vesselCellRenderer),
        }}
        rowHeight={_.isEqual(width, 'xs') ? 60 : 70}
        handleCellClick={handleCellClick}
      >
        <AgGridColumn
          field='Date'
          pinned='left'
          width={100}
          maxWidth={_.isEqual('xs', width) ? 120 : 170}
          cellClass='no-border'
          cellRenderer='dateCellRenderer'
          suppressCellFlash={true}
          suppressCellSelection={true}
          suppressSizeToFit={true}
          disableClickSelection={true}
          cellRendererParams={{
            containerClass: classes.dateCellContent,
          }}
        />
        {_.map(vessels, (value, idx) => (
          <AgGridColumn
            field={value.MachineCode}
            suppressSizeToFit={true}
            minWidth={100}
            maxWidth={_.isEqual('xs', width) ? 150 : 170}
            style={{ paddingTop: '50px' }}
            cellRenderer='vesselCellRenderer'
            cellRendererParams={{
              containerClass: classes.vesselCellContent,
            }}
            key={idx}
          />
        ))}
      </AgGridCustom>
    </div>
  );
};

export default withWidth()(SlotTable);
SlotTable.propTypes = {
  width: propTypes.string,
  setData: propTypes.func,
  data: propTypes.object,
};
