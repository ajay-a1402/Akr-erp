import { Container, useTheme } from '@material-ui/core';
import React from 'react';
import MaterialTable from 'material-table';
import { makeStyles } from '@material-ui/core/styles';
import _ from 'lodash';
import withWidth from '@material-ui/core/withWidth';
import propTypes from 'prop-types';
const useStyles = makeStyles((theme) => ({
  tableHeading: {
    paddingBottom: theme.spacing(4),
  },
  toolbar: theme.mixins.toolbar,
}));

const EligibleTable = ({ rowData }) => {
  const classes = useStyles();
  const theme = useTheme();
  return (
    <div>
      <div className={classes.toolbar} />
      <Container>
        <div style={{ maxWidth: '100vW' }}>
          <MaterialTable
            columns={[
              {
                title: 'vessel',
                field: 'vessel',
                cellStyle: {
                  backgroundColor: theme.palette.grey[400],
                },
              },
              { title: 'CapMax', field: 'CapMax' },
              { title: 'CapMin', field: 'CapMin' },
              { title: 'RFD', field: 'RFD' },
              { title: 'White', field: 'White' },
              { title: 'SingleDye', field: 'SingleDye' },
              { title: 'DoubleDye', field: 'DoubleDye' },
            ]}
            data={rowData}
            title='Slot deatails'
            options={{
              pageSize: 10,
              maxBodyHeight: 500,
            }}
          />
        </div>
      </Container>
    </div>
  );
};

export default withWidth()(EligibleTable);
EligibleTable.propTypes = {
  rowData: propTypes.array.isRequired,
  width: propTypes.string,
};
