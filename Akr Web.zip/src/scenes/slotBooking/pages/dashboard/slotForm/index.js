/* eslint-disable no-console */
import React, { useState } from 'react';
import { Formik } from 'formik';
import { makeStyles } from '@material-ui/core/styles';
import Autocomplete from '@material-ui/lab/Autocomplete';
import classnames from 'classnames';
import { connect } from 'react-redux';
import './test.css';
import {
  TextField,
  Grid,
  AppBar,
  Toolbar,
  IconButton,
  Slide,
  Box,
  Button,
  Typography,
  Dialog,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import * as Yup from 'yup';
import Axios from 'axios';
import propTypes from 'prop-types';
import EligibleTable from './eligibileTable';
import dashboardApi from '../../../services/api/dashboard';
import { bookSlot } from '../../../services/api/dashboard/actions';
const useStyles = makeStyles((theme) => ({
  formInputBox: {},
  filedLable: {
    fontSize: '18px',
    fontWeight: 400,
    color: theme.palette.grey[600],
  },
  textField: {
    '& .MuiOutlinedInput-root ': {
      height: '40px',
    },
  },
  input: {},

  autocomplete: {
    '& .MuiTextField-root': {
      '& .MuiInputBase-input': {
        padding: theme.spacing(0),
      },
    },
  },
  autoCompleteOption: {
    display: 'flex',
    flex: 1,
    justifyContent: 'space-between',
  },
  elig_button: {
    color: theme.palette.warning.dark,
  },
  appBar: {
    backgroundColor: theme.palette.secondary.dark,
  },
  appBarHeading: {
    paddingLeft: theme.spacing(2),
  },
}));

const validateSchema = Yup.object().shape({
  colour: Yup.string().required('Required'),
  process: Yup.object().required('required').nullable(),
  Qty: Yup.number().min(1, 'Please enter  more than 1 ').required('Required'),
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction='up' ref={ref} {...props} />;
});

const SlotForm = (props) => {
  const { data, bookSlot, session } = props;
  const classes = useStyles();
  const [loading, setLoading] = useState(false);
  const [processList, setProcessList] = useState([]);
  const [eligibleData, setEligibleData] = useState();

  React.useEffect(() => {
    dashboardApi.fetchProcess(
      (res) => {
        setLoading(false);
        setProcessList(res.data.data);
      },
      (err) => {
        if (!Axios.isCancel(err)) setLoading(false);
        console.log(err);
      }
    );
    setTimeout(() => {
      dashboardApi.fetchEligibility(
        (res) => {
          setLoading(false);
          setEligibleData(res.data.data);
        },
        (err) => {
          if (!Axios.isCancel(err)) setLoading(false);
          console.log(err);
        }
      );
    }, 2000);
  }, []);
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  return (
    <>
      <p className='marquee'>
        <span>
          ** If you have any doubts regards vessel and Process kindly check
          eligibility by clicking VIEW ELIGIBILITY . **
        </span>
      </p>
      <Formik
        initialValues={data}
        onSubmit={(values) => {
          bookSlot({
            colour: values.colour,
            process: values.process,
            Qty: values.Qty,
            Select_Date: data.Select_Date,
            Select_vessel: data.Select_vessel,
            userName: session.userName,
          });
        }}
        validationSchema={validateSchema}
      >
        {({
          errors,
          handleChange,
          handleSubmit,
          /* and other goodies */
        }) => (
          <Grid container spacing={2}>
            <Grid item md={3} xs={12} className={classes.formInputBox}>
              <Typography className={classes.filedLable}>Colour :</Typography>
              <TextField
                variant='outlined'
                className={classes.textField}
                fullWidth
                name='colour'
                onChange={handleChange}
                helperText={errors.colour}
                inputProps={{
                  className: classes.input,
                }}
              />
            </Grid>
            <Grid item md={3} className={classes.formInputBox} xs={12}>
              <Typography className={classes.filedLable}>Process :</Typography>
              <Autocomplete
                variant='outlined'
                className={classnames(classes.textField, classes.autocomplete)}
                fullWidth
                loading={loading}
                noOptionsText='No Process Found'
                options={processList}
                getOptionLabel={(option) => option.mainProcess}
                getOptionSelected={(option, value) =>
                  option.duration === value.duration
                }
                onChange={(e, value) => {
                  handleChange({
                    target: {
                      name: 'process',
                      value,
                    },
                  });
                }}
                name='process'
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant='outlined'
                    helperText={errors.process}
                    style={{ padding: 0 }}
                  />
                )}
                renderOption={(option) => (
                  <>
                    <Box className={classes.autoCompleteOption}>
                      <Typography>{option.mainProcess}</Typography>
                      <Typography>{option.duration} Hrs</Typography>
                    </Box>
                  </>
                )}
              />
            </Grid>
            <Grid item md={2} className={classes.formInputBox} xs={12}>
              <Typography className={classes.filedLable}>Qty :</Typography>
              <TextField
                variant='outlined'
                className={classes.textField}
                fullWidth
                type='number'
                InputProps={{
                  inputProps: {
                    min: 1,
                  },
                }}
                onChange={handleChange}
                helperText={errors.Qty}
                name='Qty'
              />
            </Grid>
            <Grid item md={2} xs={12}>
              <div style={{ minHeight: '27px' }}> </div>
              <Button
                variant='contained'
                color='primary'
                fullWidth
                className={classes.saveButton}
                onClick={handleSubmit}
              >
                Save
              </Button>
            </Grid>
            <Grid item md={2} xs={12}>
              <div style={{ minHeight: '27px' }}> </div>
              <Button
                variant='contained'
                fullWidth
                className={classes.elig_button}
                onClick={handleClickOpen}
              >
                view Eligibility
              </Button>
            </Grid>
          </Grid>
        )}
      </Formik>
      <Dialog
        fullScreen
        TransitionComponent={Transition}
        onClose={handleClose}
        aria-labelledby='simple-dialog-title'
        open={open}
      >
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton
              edge='end'
              color='inherit'
              onClick={handleClose}
              aria-label='close'
            >
              <CloseIcon />
            </IconButton>
            <Typography variant='h6' className={classes.appBarHeading}>
              Vessel Details
            </Typography>
          </Toolbar>
        </AppBar>
        <EligibleTable rowData={eligibleData} />
      </Dialog>
    </>
  );
};

const mapDispatchToProps = (dispatch) => ({
  bookSlot: (value) => dispatch(bookSlot(value)),
});

const mapStateToProps = (state) => ({
  session: state.session,
});
export default connect(mapStateToProps, mapDispatchToProps)(SlotForm);
SlotForm.propTypes = {
  data: propTypes.object,
  session: propTypes.object,
  bookSlot: propTypes.func.isRequired,
};
