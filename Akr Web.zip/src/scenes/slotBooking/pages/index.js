import React, { useState } from 'react';
import { Switch, Route, useRouteMatch } from 'react-router-dom';
import PrivateRoute from '../components/PrivateRoute';
import NavigationBar from '../../../com_components/navigationBar';
import CustomDrawer from '../../../com_components/Drawer';
import BookedSlots from './bookedSlot';
import Dashboard from './dashboard';
import SignIn from './login';
import { logout } from '../services/session/actions';
import { connect } from 'react-redux';
import { Toolbar, Box } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import PageNotFound from '../../404';
import propTypes from 'prop-types';
//import classNames from 'classnames';
//import { ThemeContext } from '@emotion/react';
const drawerWidth = 190;
const useStyles = makeStyles((theme) => ({
  rootContainer: {
    marginLeft: theme.spacing(7) + 1,
  },
}));
const SlotBooking = ({ logout, session }) => {
  const [drawer, setDrawer] = useState(false);
  let { path } = useRouteMatch();
  const classes = useStyles();
  const appbarOptions = [
    {
      label: 'Home',
      // icon: icon1,
      link: '/',
    },
    // {
    //   label: 'Dash Board',
    //   // icon: 'dashboard',
    //   link: '/slotBooking/dashboard',
    // },
    // {
    //   label: 'Booked Slots',
    //   // icon: icon1,
    //   link: '/slotBooking/bookedSlots',
    // },
  ];
  const drawerOptions = [
    {
      label: 'DashBoard',
      icon: 'dashboard',
      link: '/slotBooking/dashboard',
    },
    {
      label: 'Booked Slots',
      icon: 'bookmark_add',
      link: '/slotBooking/bookedSlots',
    },
    // {
    //   label: 'User Management',
    //   icon: 'people',
    //   link: '/employeDetails/main',
    // },
  ];

  return (
    <div>
      <NavigationBar
        setDrawer={setDrawer}
        options={appbarOptions}
        logout={logout}
        session={session}
      />
      <Toolbar />
      <Box className={classes.rootContainer}>
        <Switch>
          <Route exact path='/slotBooking/login' component={SignIn} />
          <PrivateRoute exact path={path} component={SlotBookingMain} />
        </Switch>
      </Box>
      <CustomDrawer
        drawer={{ state: drawer, width: drawerWidth }}
        options={drawerOptions}
      />
    </div>
  );
};
const SlotBookingMain = () => {
  return (
    <Switch>
      <Route exact path='/slotBooking/dashboard' component={Dashboard} />
      <Route exact path={`/slotBooking/bookedSlots`} component={BookedSlots} />
      <Route path='*' component={PageNotFound} />
    </Switch>
  );
};
const mapDispatchToProps = (dispatch) => ({
  logout: () => dispatch(logout()),
});
const mapStateToProps = (state) => {
  return {
    session: state.session,
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(SlotBooking);
SlotBooking.propTypes = {
  session: propTypes.object,
  logout: propTypes.func,
};
