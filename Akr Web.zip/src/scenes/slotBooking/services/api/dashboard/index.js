/* eslint-disable no-undef */
import Axios from 'axios';
import { API_ENDPOINTS } from '../../../../../constants';
import { getLocalStorageItem } from '../../../../../services/localStorage';
export default {
  fetchProcess: (sucessCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_PROCESS}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  fetchEligibility: (sucessCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_ELIGIBILITY}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  fetchVessel: (sucessCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_VESSELS}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },

  fetchTable: (sucessCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_TABLE}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },

  bookSlot: (payload) => {
    return Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.BOOK_SLOT}`,
      { ...payload },
      {
        headers: {
          Authorization:
            'Bearer ' + btoa(`${payload.username}:${payload.password}`),
          'Content-Type': 'application/json',
        },
        params: {
          userName: getLocalStorageItem('userName'),
        },
      }
    );
  },
  fetchSlotBooked: (successCallback, failureCallback, username) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_BOOKED_SLOTS}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        params: {
          userName: username,
        },
      }
    )
      .then((res) => {
        successCallback(res);
      })
      .catch((err) => {
        failureCallback(err);
      });
  },
};
