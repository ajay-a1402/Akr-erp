import { put, call, takeLatest } from 'redux-saga/effects';
import { SAGA_ACTION_TYPES, ACTION_TYPES } from '../../../../../../constants';
import api from '../index';
import _ from 'lodash';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';
export function* slotSaga(action) {
 // console.log('saga:', action);
  try {
    if (_.isEmpty(action.payload.Select_Date)) {
      yield put(
        showAdvanceSnackbar({
          msg: `Select vessel First`,
          severity: 'error',
          onclose: true,
        })
      );
    } else {
      yield put({ type: ACTION_TYPES.BOOK_SLOT_PENDING });
      const res = yield call(api.bookSlot, { ...action.payload });
      if (res.status === 200) {
        yield put({
          type: ACTION_TYPES.BOOK_SLOT_SUCCESS,
          payload: res.data.data,
        });
        yield put(
          showAdvanceSnackbar({
            msg: `${res.data.messege}`,
            severity: 'success',
            onclose: true,
          })
        );
        // window.location.reload();
      } else {
        yield put({ type: ACTION_TYPES.BOOK_SLOT_FAILURE });
        yield put(
          showAdvanceSnackbar({
            msg: `${res.data.messege}`,
            severity: 'error',
            onclose: true,
          })
        );
      }
    }
  } catch (error) {
    yield put(
      showAdvanceSnackbar({
        msg: _.get(error.response.data, 'messege', error),
        severity: 'error',
        onclose: true,
      })
    );
    yield put({ type: ACTION_TYPES.BOOK_SLOT_FAILURE });
  }
}

export function* slotWatcher() {
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_BOOK_SLOT, slotSaga);
}
