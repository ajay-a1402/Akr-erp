import { API_ENDPOINTS } from '../../../../constants';
import Axios from 'axios';
export default {
  login: (payload) => {
    return Axios.post(
      // eslint-disable-next-line no-undef
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.LOGIN}`,
      { party_logid: payload.username, party_logpwd: payload.password },
      {
        headers: {
          Authorization:
            'Bearer ' + btoa(`${payload.username}:${payload.password}`),
          'Content-Type': 'application/json',
        },
        timeout: 5000,
      }
    );
  },
};
