import api from '../../session/api'
import { put, call, takeLatest } from 'redux-saga/effects'
import { ACTION_TYPES, SAGA_ACTION_TYPES } from '../../../../../constants'
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions'

export function* loginSaga(action) {
  try {
    const res = yield call(api.login, { ...action.payload })

    if (res.data.messege === 'invalid user Id') {
      yield put(
        showAdvanceSnackbar({
          msg: res.data.messege,
          severity: 'error',
          onclose: true,
        })
      )
    }
    if (res.data.messege === 'incorrect password') {
      yield put(
        showAdvanceSnackbar({
          msg: res.data.messege,
          severity: 'error',
          onclose: true,
        })
      )
    }
    if (res.data.messege === 'Internal server Error') {
      yield put(
        showAdvanceSnackbar({
          msg: `${res.data.messege} Try again later `,
          severity: 'error',
          onclose: true,
        })
      )
    }
    if (res.data.messege === 'Sucessfully logged-in') {
      yield put({
        type: ACTION_TYPES.LOGIN_USER_SUCCESS,
        payload: {
          token: res.data.data.auth_token,
          user_details: res.data.data.userDetails[0],
        },
      })
    }
  } catch (error) {
    yield put(
      showAdvanceSnackbar({
        msg: `${error} ,Try again later `,
        severity: 'error',
        onclose: true,
      })
    )
    yield put({ type: ACTION_TYPES.LOGIN_USER_ERROR, error })
  }
}

export function* loginWatcher() {
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_LOGIN_USER, loginSaga)
}
