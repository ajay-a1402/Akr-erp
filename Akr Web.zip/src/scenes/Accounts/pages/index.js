import {
  Toolbar,

  
  
} from '@material-ui/core';
import React, { useEffect, useMemo, useState } from 'react';
import NavigationBar from '../../../com_components/navigationBar';
import PrivateRoute from '../components/PrivateRoute';
import { Route, Switch, useRouteMatch, useHistory } from 'react-router-dom';
import AuthFail from './authfail';
import Batch from './Billings/Batch';
import PageNotFound from '../../404';
import CustomDrawer from '../../../com_components/Drawer';
import { makeStyles } from '@material-ui/core/styles';
import BatchInvoiceAdd from './Billings/InvoiceAdd';
import BatchReview from './Billings/Review';
import Home from './home';
import Login from './login';
import { connect, useDispatch } from 'react-redux';
import { updateSession } from '../services/api/actions';
import {
  clearAllSession,
  
} from '../../../services/sessionStorage';
import UserMagement from './UserManagement';
import api from '../services/api';
import { API_ENDPOINTS } from '../../../constants';
import { isLogin } from '../utils';
import { hideLoader } from '../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../services/snackbarAdvance/actions';
import * as _ from 'lodash';
import { getModulePerms } from '../utils/perms';
const useStyles = makeStyles((theme) => ({
  rootContainer: {
    marginLeft: theme.spacing(7) + 1,
    [theme.breakpoints.down('md')]: {
      marginLeft: theme.spacing(1),
    },
  },
}));
const drawerWidth = 180;

const Accounts = ({ session, UpdateSession }) => {
  const classes = useStyles();
  const history = useHistory();
  const [drawer, setDrawer] = useState(false);
  let { path } = useRouteMatch();
  //const theme = useTheme();
 // const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  let batch_perms = getModulePerms('PermBatch');
  let bill_perms = getModulePerms('PermBills');
  //let super_user_perms = getModulePerms('SuperUser');
  let app1_perms = getModulePerms('PermApprov1');
  let app2_perms = getModulePerms('PermApprov2');
  const dispatch = useDispatch();

  const appbarOptions = [
    {
      label: 'Home',
      // icon: icon1,
      link: '/',
    },
    {
      label: 'Main',
      // icon: icon1,
      link: '/accounts/login',
    },
  ];
  const drawerOptions = useMemo(
    () => [
      {
        label: 'Create Batch',
        icon: 'note_add',
        link: '/accounts/bills/newBatch',
        hide: !batch_perms,
      },
      {
        label: 'Invoice Update',
        icon: 'request_quote',
        link: '/accounts/bills/billAdd',
        hide: !bill_perms,
      },
      {
        label: 'Review Batch',
        icon: 'flaky',
        link: '/accounts/bills/billReview',
        hide: !(app1_perms || app2_perms),
      },
    ],
    [batch_perms, bill_perms, app1_perms, app2_perms]
  );
  useEffect(() => {
    if (isLogin()) {
      api.GetRequest(
        API_ENDPOINTS.AUTH_USER_ACCOUNTS,

        (res) => {
          dispatch(hideLoader());
          const loginResult = res.data;
          if (loginResult.status === 'success') {
            UpdateSession({
              details: _.get(loginResult, 'data', {}),
              isAuthenticated: true,
            });
          }
        },
        (err) => {
          dispatch(hideLoader());
          if (err.response) {
            if (err.response.status === 408) {
              clearAllSession();
              history.replace('/accounts/authfail');
            } else {
              dispatch(
                showAdvanceSnackbar({
                  msg: _.get(err.response.data, 'messege', 'Error'),
                  severity: 'error',
                  onclose: true,
                })
              );
            }
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'Check network Connection',
                severity: 'error',
                onclose: true,
              })
            );
          }
        }
      );
    }
  }, []);

  const logout = () => {
    UpdateSession({});
    clearAllSession();
    history.push('/accounts/login');
  };
  return (
    <div>
      <NavigationBar
        setDrawer={setDrawer}
        options={appbarOptions}
        logout={logout}
        session={session}
      />
      <Toolbar />
      <div className={classes.rootContainer}>
        <Switch>
          <Route exact path={`${path}/:module`} component={AccountsMain} />
          <PrivateRoute path={`${path}/:module/:sub`} component={AccountsSub} />
        </Switch>
      </div>
      <CustomDrawer
        drawer={{ state: drawer, width: drawerWidth }}
        options={drawerOptions}
      />
    </div>
  );
};

const mapStateToProps = (state) => ({
  session: state.AccountsSessionReducer,
});
const mapDispatchToProps = (dispatch) => ({
  UpdateSession: (data) => dispatch(updateSession(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Accounts);
export const AccountsMain = () => {
  return (
    <Switch>
      <Route path={`/accounts/Authfail`} component={AuthFail} />
      <PrivateRoute path='/accounts/home' component={Home} />
      <PrivateRoute path='/accounts/usermanagement' component={UserMagement} />
      <Route path='/accounts/login' component={Login} />
      <Route path='*' component={PageNotFound} />
    </Switch>
  );
};
export const AccountsSub = () => {
  let { path } = useRouteMatch();
  return (
    <Switch>
      <Route exact path='/accounts/bills/newBatch' component={Batch} />
      <Route exact path='/accounts/bills/billAdd' component={BatchInvoiceAdd} />
      <Route exact path='/accounts/bills/billReview' component={BatchReview} />
      <Route path='*' component={PageNotFound} />
    </Switch>
  );
};
