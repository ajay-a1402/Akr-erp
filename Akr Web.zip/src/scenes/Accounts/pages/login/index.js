import React, { useEffect, useRef } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import { isLogin } from '../../utils';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import {
  Typography,
  DialogContent,
  Dialog,
  DialogContentText,
  DialogActions,
  InputAdornment,
  IconButton,
  Container,
  Box,
  Grid,
  Link,
} from '@material-ui/core';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { makeStyles } from '@material-ui/core/styles';
import { Formik, validateYupSchema, Form } from 'formik';
import { connect } from 'react-redux';
import propTypes from 'prop-types';
import * as Yup from 'yup';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import api from '../../services/api';
import { hideLoader, showLoader } from '../../../../services/loader/actions';
import { setSessionStorageItem } from '../../../../services/sessionStorage';
import { showAdvanceSnackbar } from '../../../../services/snackbarAdvance/actions';

import * as _ from 'lodash';
import { updateSession } from '../../services/api/actions';
const loginSchema = Yup.object().shape({
  user_id: Yup.string().required('Required'),
  password: Yup.string().required('Required'),
});

function Copyright() {
  return (
    <Typography variant='body2' color='textSecondary' align='center'>
      {'Copyright © '}
      <Link color='inherit' href='https://material-ui.com/'>
        ERP Dep AKR
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

function AccountsSignIn(props) {
  const classes = useStyles();
  const { UpdateSession } = props;
  let history = useHistory();
  const dispatch = useDispatch();
  const idRef = useRef(null);
  const pswdRef = useRef(null);
  const submitRef = useRef(null);
  const [open, setOpen] = React.useState(false);
  const [viewPswd, setView] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleClickShowPassword = () => setView(!viewPswd);
  const handleMouseDownPassword = () => setView(!viewPswd);
  const redirectToHomeIfLoggedIn = () => {
    if (isLogin()) {
      history.push('/accounts/home');
    }
  };
  useEffect(() => {
    idRef.current.focus();
    redirectToHomeIfLoggedIn();
  }, [props.session]);

  const handleIdKeyDown = (e) => {
    if (e.key === 'Enter') {
      pswdRef.current.focus();
    }
  };
  const handlePswdKeyDown = (e) => {
    if (e.key === 'Enter') {
      submitRef.current.focus();
    }
  };
  return (
    <Container component='main' maxWidth='xs'>
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component='h1' variant='h5'>
          Accounts Sign in
        </Typography>
        <Formik
          initialValues={{
            user_id: '',
            password: '',
          }}
          onSubmit={(values) => {
            api.AuthLogin(
              (res) => {
                dispatch(hideLoader());
                const loginResult = res.data;
                if (loginResult.status === 'success') {
                  setSessionStorageItem(
                    'accounts-Auth',
                    _.get(loginResult, 'auth_token')
                  );

                  setSessionStorageItem(
                    'UserId',
                    _.get(loginResult.data, 'EmployeeId')
                  );
                  UpdateSession({
                    details: _.get(loginResult, 'data', {}),
                    isAuthenticated: true,
                  });
                  history.replace('/accounts/home');
                }
              },
              (err) => {
                dispatch(hideLoader());
                if (err.response) {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: _.get(err.response.data, 'messege', 'Error'),
                      severity: 'error',
                      onclose: true,
                    })
                  );
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: 'Check network Connection',
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              },
              values
            );
          }}
          validationSchema={loginSchema}
        >
          {({ errors, handleChange, handleSubmit }) => (
            <>
              <TextField
                variant='outlined'
                margin='normal'
                error={errors.user_id}
                fullWidth
                inputProps={{
                  ref: idRef,
                }}
                id='user_id'
                label='user Id '
                name='user_id'
                autoComplete='userId'
                InputProps={{
                  onKeyDown: handleIdKeyDown,
                }}
                onChange={handleChange}
                // autoFocus
              />
              <TextField
                variant='outlined'
                margin='normal'
                fullWidth
                error={errors.password}
                inputProps={{
                  ref: pswdRef,
                }}
                InputProps={{
                  onKeyDown: (e) => {
                    if (e.key === 'Enter') {
                      handleSubmit();
                    }
                  },
                  endAdornment: (
                    <InputAdornment position='end'>
                      <IconButton
                        aria-label='toggle password visibility'
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {viewPswd ? <Visibility /> : <VisibilityOff />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                name='password'
                label='Password'
                type={viewPswd ? 'text' : 'password'}
                id='password'
                onChange={handleChange}
                autoComplete='password'
              />
              <Button
                type='submit'
                fullWidth
                InputProps={{
                  onKeyDown: handleSubmit,
                }}
                ref={submitRef}
                variant='contained'
                color='primary'
                className={classes.submit}
                onClick={handleSubmit}
              >
                Sign In
              </Button>
            </>
          )}
        </Formik>
        <Grid container>
          <Grid item xs>
            <Link href='#' onClick={handleClickOpen} variant='body2'>
              Forgot password?
            </Link>
          </Grid>
        </Grid>
      </div>
      <Box mt={8}>
        <Copyright />
      </Box>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Mail to erp@akrind.com
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color='primary' autoFocus>
            close
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

const mapDispatchToProps = (dispatch) => ({
  UpdateSession: (data) => dispatch(updateSession(data)),
});
const mapStateToProps = (state) => ({
  session: state.session,
});

export default connect(mapStateToProps, mapDispatchToProps)(AccountsSignIn);
AccountsSignIn.propTypes = {
  session: propTypes.object,
  login: propTypes.func,
};
