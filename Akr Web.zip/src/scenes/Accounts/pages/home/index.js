import classNames from 'classnames';
import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import * as _ from 'lodash';
import {
  Grid,
  CardContent,
  Card,
  Toolbar,
  Typography,
  Icon,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useQuery } from '../../../../com_utils';
import api from '../../services/api';
import { connect, useDispatch } from 'react-redux';
import { MODULE_PERMS, getModulePerms } from '../../utils/perms';
import NavigationBar from '../../../../com_components/navigationBar';
import CustomDrawer from '../../../../com_components/Drawer';
import { useHistory } from 'react-router';
import { hideLoader, showLoader } from '../../../../services/loader/actions';
import {
  getSessionStorageItem,
  setSessionStorageItem,
} from '../../../../services/sessionStorage';
import { showAdvanceSnackbar } from '../../../../services/snackbarAdvance/actions';
const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({
  Maincontainer: {
    paddingLeft: theme.spacing(10),
  },
  shiftContent: {
    marginLeft: drawerWidth,
  },
  cardLinks: {
    textDecoration: 'none',
  },
  Card: {
    margin: theme.spacing(0, 1, 0, 1),
  },
  cardContent: {
    textAlign: 'center',
    backgroundColor: theme.palette.grey[50],
  },
}));

const appbarOptions = [
  {
    label: 'Home',
    // icon: icon1,
    link: '/accounts/login',
  },
];
const cardOptions = [
  {
    label: 'Create Batch',
    icon: 'note_add',
    link: '/accounts/bills/newBatch',
  },
  {
    label: 'Invoice Update',
    icon: 'request_quote',
    link: '/accounts/bills/billAdd',
  },
  {
    label: 'Review Batch',
    icon: 'flaky',
    link: '/accounts/bills/billReview',
  },
];
const SpecialOptions = [
  {
    label: 'Manage Users',
    icon: 'manage_accounts',
    link: '/accounts/usermanagement',
  },
];
const MainPage = ({ session }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [drawer, setDrawer] = useState(false);
  let batch_perms = getModulePerms('PermBatch');
  let bill_perms = getModulePerms('PermBills');
  let super_user_perms = getModulePerms('SuperUser');
  let app1_perms = getModulePerms('PermApprov1');
  let app2_perms = getModulePerms('PermApprov2');
  return (
    <>
      <Toolbar />

      <div className={classNames(classes.Maincontainer)}>
        <Grid container>
          {super_user_perms && (
            <RenderCard cardOptions={MODULE_PERMS['SUPER_USER']} />
          )}
          {batch_perms && (
            <RenderCard cardOptions={MODULE_PERMS['CREATE_BATCH']} />
          )}
          {bill_perms && (
            <RenderCard cardOptions={MODULE_PERMS['CREATE_BILLS']} />
          )}
          {(app1_perms || app2_perms) && (
            <RenderCard cardOptions={MODULE_PERMS['REVIEW_BILLS']} />
          )}
        </Grid>
      </div>
    </>
  );
};
const mapStateToProps = (state) => ({
  session: state.AccountsSessionReducer,
});

const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(MainPage);
const RenderCard = ({ cardOptions }) => {
  const classes = useStyles();

  return (
    <>
      {' '}
      {cardOptions.map((option, idx) => {
        return (
          <Grid item key={idx}>
            <div className={classes.Card}>
              <Link to={option.link} className={classes.cardLinks}>
                <Card>
                  <CardContent className={classes.cardContent}>
                    <Icon>{option.icon}</Icon>
                    <Typography variant='h6'>{option.label}</Typography>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </Grid>
        );
      })}
    </>
  );
};
