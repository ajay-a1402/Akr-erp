import _ from 'lodash';
import React, {
  useState,
  useImperativeHandle,
  useEffect,
  useRef,
  forwardRef,
} from 'react';
import propTypes from 'prop-types';
import { Button, Checkbox, Icon } from '@material-ui/core';
import classnames from 'classnames';
export const withCellRenderState = (CellRenderer) => {
  // eslint-disable-next-line react/display-name
  return forwardRef((props, ref) => {
    /* eslint-disable react/prop-types */

    const [value, setValue] = useState(props.value);

    useImperativeHandle(ref, () => {
      return {
        refresh: (params) => {
          if (params.value !== value) {
            setValue(params.value);
          }
          return true;
        },
      };
    });
    return <CellRenderer {...props}></CellRenderer>;
  });
};
withCellRenderState.propTypes = {
  value: propTypes.object,
};

export const ActionCellRenderer = (props) => {
  const { value } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  const updateClassName = _.get(
    props,
    'colDef.cellRendererParams.updateClassName'
  );
  const deleteClassName = _.get(
    props,
    'colDef.cellRendererParams.deleteClassName'
  );
  const onClickUpdate = _.get(props, 'colDef.cellRendererParams.onClickUpdate');
  const onClickDelete = _.get(props, 'colDef.cellRendererParams.onClickDelete');

  return (
    <div className={containerClassName}>
      <Button
        className={updateClassName}
        onClick={() => {
          onClickUpdate(props);
        }}
      >
        Update
      </Button>
      <Button
        className={deleteClassName}
        onClick={() => {
          onClickDelete(props);
        }}
      >
        Delete
      </Button>
    </div>
  );
};

export const PermissionCellRenderer = (props) => {
  const { value } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  const hasPermStyles = _.get(props, 'colDef.cellRendererParams.hasPermStyles');
  return (
    <div className={containerClassName}>
      <Icon
        className={classnames({ [hasPermStyles]: value })}
        style={{ color: !value && 'red' }}
      >
        {value ? `task_alt` : `highlight_off`}
      </Icon>
    </div>
  );
};
