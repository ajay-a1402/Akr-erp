import { Icon, Typography } from '@material-ui/core';
import { useEffect, useState, useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AgGridCustom from '../../../../../com_components/AgGridCustom';
import CheckBoxRenderer from './customCells/checkBoxRenderer';
import API from '../../../services/api';
import { useHistory } from 'react-router-dom';
import * as _ from 'lodash';
import {
  ActionCellRenderer,
  PermissionCellRenderer,
  withCellRenderState,
} from './customCells/customCellRenderer';
import { API_ENDPOINTS } from '../../../../../constants';
import { useDispatch } from 'react-redux';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../services/loader/actions';
import { clearAllSession } from '../../../../../services/sessionStorage';
import { getModulePerms } from '../../../utils/perms';

const useStyles = makeStyles((theme) => ({
  permsCells: {
    display: 'flex',
    paddingTop: theme.spacing(1),
    justifyContent: 'center',
    '& .MuiIcon-root': {
      [theme.breakpoints.down('md')]: {
        fontSize: '18px !important',
      },
    },
  },
  updateComponent: {
    marginRight: theme.spacing(2),
    backgroundColor: theme.palette.success.main,
    [theme.breakpoints.down('md')]: {
      fontSize: '10px !important',
    },
  },
  deleteComponent: {
    backgroundColor: theme.palette.secondary.light,
    [theme.breakpoints.down('md')]: {
      fontSize: '10px !important',
    },
  },
  hasPermStyles: {
    color: 'green !important',
  },
  permsTable: {
    '& .ag-theme-material': {
      '& .ag-cell-inline-editing': {
        boxShadow: 'none',
        padding: '0px',
        height: '100 %',
      },
      '& .ag-header-cell': {
        [theme.breakpoints.down('md')]: {
          fontSize: '10px !important',
        },
      },
      '& .ag-cell': {
        [theme.breakpoints.down('md')]: {
          fontSize: '10px !important',
        },
      },
    },
  },
}));
const PermissionTable = ({ userData, setUserData }) => {
  const classes = useStyles();
  const gridref = useRef();
  const history = useHistory();
  const dispatch = useDispatch();
  const onClickUpdate = (props) => {
    dispatch(showLoader('Please wait...'));

    API.PutRequest(
      API_ENDPOINTS.UPDATE_PERMS,
      (res) => {
        dispatch(hideLoader());

        setUserData(_.get(res, 'data.data', []));
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(err.response.data, 'messege', 'Error'),
              severity: 'error',
              onclose: true,
            })
          );
          if (err.response.status === 408) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      { user: _.get(props, 'data', {}) }
    );
  };

  const onClickDelete = (props) => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to remove ${_.get(
          props,
          'data.EmployeeName',
          {}
        )} from Accounts User?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          API.DeleteRequest(
            API_ENDPOINTS.DELETE_USER,
            (res) => {
              dispatch(hideLoader());
              setUserData(res.data.data);
            },
            (err) => {
              dispatch(hideLoader());

              if (err.response) {
                if (err.response.status === 401) {
                  clearAllSession();
                  history.replace('/accounts/authfail');
                }
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Check network Connection',
                    severity: 'error',
                    onclose: true,
                  })
                );
              }
            },
            { user: _.get(props, 'data', {}) }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };
  const coldef = [
    {
      field: 'UserEnno',
      hide: true,
    },
    {
      field: 'PayrollEmpno',
      headerName: 'Id',
      headerTooltip: 'Employee Id',
      minWidth: 100,
    },
    {
      field: 'EmployeeName',
      headerName: 'Name',
      headerTooltip: 'Employee Name',
      minWidth: 100,
    },
    {
      field: 'PermBatch',
      headerName: 'Batch Create',
      headerTooltip: 'Batch Create',
      minWidth: 150,
      cellRenderer: 'permissionCellRenderer',
      editable: (props) => {
        let PermApprov1 = _.get(props.data, 'PermApprov1', 0);
        let PermApprov2 = _.get(props.data, 'PermApprov2', 0);
        let PermBills = _.get(props.data, 'PermBills', 0);
        let PermDel = _.get(props.data, 'PermDel', 0);
        let SuperUser = _.get(props.data, 'SuperUser', 0);
        if (
          PermBills ||
          PermApprov2 ||
          PermBills ||
          PermDel ||
          SuperUser ||
          PermApprov1
        )
          return false;
        else return true;
      },
      cellEditor: 'checkBoxRenderer',
      valueSetter: (params) => {
        params.data.PermBatch = params.newValue;
      },
      valueGetter: (params) => {
        return (params.data.PermBatch = _.get(params.data, 'PermBatch', 0));
      },
      cellRendererParams: {
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: 'PermBills',
      headerName: 'Edit Bills',
      cellRenderer: 'permissionCellRenderer',
      headerTooltip: 'Edit Bills',
      minWidth: 150,
      editable: (props) => {
        let PermApprov1 = _.get(props.data, 'PermApprov1', 0);
        let PermApprov2 = _.get(props.data, 'PermApprov2', 0);
        let PermBatch = _.get(props.data, 'PermBatch', 0);
        let PermDel = _.get(props.data, 'PermDel', 0);
        let SuperUser = _.get(props.data, 'SuperUser', 0);
        if (PermBatch || PermApprov2 || PermDel || SuperUser || PermApprov1)
          return false;
        else return true;
      },
      cellEditor: 'checkBoxRenderer',
      valueSetter: (params) => {
        params.data.PermBills = params.newValue;
      },
      valueGetter: (params) => {
        return (params.data.PermBills = _.get(params.data, 'PermBills', 0));
      },
      cellRendererParams: {
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: 'PermDel',
      headerName: 'Batch Delete',
      headerTooltip: 'Batch Delete',
      cellRenderer: 'permissionCellRenderer',
      cellEditor: 'checkBoxRenderer',
      minWidth: 150,
      valueSetter: (params) => {
        params.data.PermDel = params.newValue;
      },
      valueGetter: (params) => {
        return (params.data.PermDel = _.get(params.data, 'PermDel', 0));
      },
      disableClickSelection: true,
      suppressCellSelection: true,
      cellRendererParams: {
        disableClick: true,
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: 'PermApprov1',
      headerName: 'Approver 1',
      cellRenderer: 'permissionCellRenderer',
      headerTooltip: 'Approver 1',
      minWidth: 150,
      editable: (props) => {
        let PermApprov2 = _.get(props.data, 'PermApprov2', 0);
        let PermBatch = _.get(props.data, 'PermBatch', 0);
        let PermBills = _.get(props.data, 'PermBills', 0);
        let PermDel = _.get(props.data, 'PermDel', 0);
        let SuperUser = _.get(props.data, 'SuperUser', 0);
        if (PermBills || PermApprov2 || PermDel || SuperUser || PermBatch)
          return false;
        else return true;
      },
      cellEditor: 'checkBoxRenderer',
      valueSetter: (params) => {
        if (!params.data.PermApprov2) {
          params.data.PermApprov1 = params.newValue;
        } else if (params.newValue) {
          dispatch(
            showAdvanceSnackbar({
              msg: 'User cannot be multiple approver',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      valueGetter: (params) => {
        return (params.data.PermApprov1 = _.get(params.data, 'PermApprov1', 0));
      },
      cellRendererParams: {
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: 'PermApprov2',
      headerName: 'Approver 2',
      cellRenderer: 'permissionCellRenderer',
      headerTooltip: 'Approver 2',
      minWidth: 150,
      editable: (props) => {
        let PermApprov1 = _.get(props.data, 'PermApprov1', 0);
        let PermBatch = _.get(props.data, 'PermBatch', 0);
        let PermBills = _.get(props.data, 'PermBills', 0);
        let PermDel = _.get(props.data, 'PermDel', 0);
        let SuperUser = _.get(props.data, 'SuperUser', 0);
        if (PermBills || PermBatch || PermDel || SuperUser || PermApprov1)
          return false;
        else return true;
      },
      cellEditor: 'checkBoxRenderer',
      valueSetter: (params) => {
        if (!params.data.PermApprov1) {
          params.data.PermApprov2 = params.newValue;
        } else if (params.newValue) {
          dispatch(
            showAdvanceSnackbar({
              msg: 'User cannot be multiple approver',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      valueGetter: (params) => {
        return (params.data.PermApprov2 = _.get(params.data, 'PermApprov2', 0));
      },
      cellRendererParams: {
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: 'SuperUser',
      headerName: 'Super User',
      cellRenderer: 'permissionCellRenderer',
      headerTooltip: 'Super User',
      minWidth: 150,
      editable: (props) => {
        let PermApprov1 = _.get(props.data, 'PermApprov1', 0);
        let PermApprov2 = _.get(props.data, 'PermApprov2', 0);
        let PermBatch = _.get(props.data, 'PermBatch', 0);
        let PermBills = _.get(props.data, 'PermBills', 0);
        let PermDel = _.get(props.data, 'PermDel', 0);
        if (PermBills || PermApprov2 || PermDel || PermBatch || PermApprov1)
          return false;
        else return true;
      },
      cellEditor: 'checkBoxRenderer',
      valueSetter: (params) => {
        params.data.SuperUser = params.newValue;
      },
      valueGetter: (params) => {
        console.log('prams', params);
        return (params.data.SuperUser = _.get(params.data, 'SuperUser', 0));
      },
      cellRendererParams: {
        containerClass: classes.permsCells,
        hasPermStyles: classes.hasPermStyles,
      },
    },
    {
      field: '',
      cellRenderer: 'actionCellRenderer',
      minWidth: 200,
      cellRendererParams: {
        containerClass: classes.actionCell,
        updateClassName: classes.updateComponent,
        deleteClassName: classes.deleteComponent,
        onClickUpdate,
        onClickDelete,
      },
    },
  ];

  return (
    <div className={classes.permsTable}>
      <AgGridCustom
        getRef={gridref}
        rowData={userData}
        columnDefs={coldef}
        height={250}
        noDataTxt='No Users Found'
        handleCellClick={(e) => {}}
        frameworkComponents={{
          checkBoxRenderer: CheckBoxRenderer,
          actionCellRenderer: withCellRenderState(ActionCellRenderer),
          permissionCellRenderer: withCellRenderState(PermissionCellRenderer),
        }}
      />
    </div>
  );
};
export default PermissionTable;
