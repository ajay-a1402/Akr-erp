import React, { useEffect, useState } from 'react';
import { Toolbar, Typography } from '@material-ui/core';
import AgGridCustom from '../../../../com_components/AgGridCustom';
import AddUser from './addUser';
import PermissionTable from './permissionTable';
import api from '../../services/api';
import { API_ENDPOINTS } from '../../../../constants';
import { useDispatch } from 'react-redux';
import { hideLoader, showLoader } from '../../../../services/loader/actions';
import { makeStyles } from '@material-ui/core/styles';
import { showAdvanceSnackbar } from '../../../../services/snackbarAdvance/actions';
import * as _ from 'lodash';
import { clearAllSession } from '../../../../services/sessionStorage';
import { useHistory } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
  rootContainer: {
    padding: theme.spacing(0, 0, 0, 1),
  },
}));

const UserMagement = () => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const history = useHistory();
  const [userData, setUserData] = useState([]);
  useEffect(() => {
    dispatch(showLoader('Updating Users Please Wait...'));

    api.GetRequest(
      API_ENDPOINTS.GET_USERS,
      (res) => {
        dispatch(hideLoader());

        setUserData(_.get(res.data, 'data', []));
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(err.response.data, 'message', 'Error'),
              severity: 'error',
              onclose: true,
            })
          );
          if (err.response.status === 408) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      }
    );
  }, []);
  return (
    <div className={classes.rootContainer}>
      <AddUser setUserData={setUserData} />
      <PermissionTable userData={userData} setUserData={setUserData} />
    </div>
  );
};
export default UserMagement;
