import {
  Toolbar,
  DialogContent,
  Icon,
  Button,
  Dialog,
  IconButton,
  InputBase,
  DialogTitle,
  Grid,
  Typography,
  Box,
  Chip,
  DialogActions,
  useTheme,
  useMediaQuery,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import DoneIcon from '@material-ui/icons/Done';
import { makeStyles, alpha } from '@material-ui/core/styles';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useState } from 'react';
import AutocompleteWithChip from '../../../components/autoCompleteWithChip';
import * as _ from 'lodash';
import api from '../../../services/api';
import { API_ENDPOINTS } from '../../../../../constants';
import { useDispatch } from 'react-redux';
import { hideLoader, showLoader } from '../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
import { clearAllSession } from '../../../../../services/sessionStorage';
import { useHistory } from 'react-router-dom';
const useStyles = makeStyles((theme) => ({
  toolBar: {
    display: 'flex',
    justifyContent: 'flex-end',
    padding: theme.spacing(4),
  },
  autoComplete: {
    display: 'flex',
  },
  inputBase: {
    padding: 10,
    width: '100%',
    borderBottom: '1px solid #dfe2e5',
    '& input': {
      borderRadius: 4,
      backgroundColor: theme.palette.common.white,
      padding: 8,
      transition: theme.transitions.create(['border-color', 'box-shadow']),
      border: '1px solid #ced4da',
      fontSize: 14,
      '&:focus': {
        boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
        borderColor: theme.palette.primary.main,
      },
    },
  },
  dialogBox: {
    minHeight: '500px',
  },

  close: {
    opacity: 0.6,
    width: 18,
    height: 18,
  },
  iconSelected: {
    width: 17,
    height: 17,
    marginRight: 5,
    marginLeft: -2,
  },
  text: {
    flexGrow: 1,
  },
  dialogToolbar: { display: 'flex', justifyContent: 'space-between' },
  listBox: {
    overflowX: 'hidden',
    width: '100%',
    padding: theme.spacing(2, 0.5),
    '&::-webkit-scrollbar': {
      width: '0.4em',
    },
    '&::-webkit-scrollbar-track': {
      boxShadow: 'inset 0 0 6px rgba(0,0,0,0.00)',
      webkitBoxShadow: 'inset 0 0 6px rgba(0,0,0,0.00)',
    },
    '&::-webkit-scrollbar-thumb': {
      background: 'linear-gradient(180deg, #D0368A 0%, #708AD4 99%)',
      boxshadow: 'inset 2px 2px 5px 0 rgba(#fff, 0.5)',
      borderRadius: '100px',
    },
  },
}));
const AddUser = ({ setUserData }) => {
  const classes = useStyles();
  const history = useHistory();

  const [open, SetOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const [selected, setSelected] = useState([]);
  const [key, setKey] = useState('');
  const dispatch = useDispatch();
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  const [state, setState] = useState({
    loading: false,
    params: '',
  });
  const handleOpen = () => {
    SetOpen((prev) => !prev);
  };

  const onChangeKey = (e) => {
    setKey(e.target.value);
  };
  useEffect(() => {}, []);

  const handleCancel = () => {
    setSelected([]);
    SetOpen((prev) => !prev);
  };
  const handleSearch = () => {
    dispatch(showLoader('searching for user'));
    api.fetchWithParams(
      API_ENDPOINTS.SEARCH_USER,
      (res) => {
        dispatch(hideLoader());

        setOptions(_.get(res.data, 'data', []));
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(err.response.data, 'messege', 'Error'),
              severity: 'error',
              onclose: true,
            })
          );
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      { key: key }
    );
  };
  const handleAdd = () => {
    dispatch(showLoader('Adding User Please Wait'));
    api.PostRequest(
      API_ENDPOINTS.ADD_USER,
      (res) => {
        dispatch(hideLoader());

        setUserData(_.get(res, 'data.data', []));
        handleOpen();
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(err.response.data, 'message', 'Error'),
              severity: 'error',
              onclose: true,
            })
          );
          if (err.response.status === 408) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },

      {
        users: selected,
      }
    );
  };
  return (
    <div>
      <Toolbar className={classes.toolBar}>
        <Button
          variant='contained'
          color='primary'
          className={classes.button}
          fullWidth={isBelowMd && true}
          onClick={handleOpen}
          startIcon={<Icon>group_add</Icon>}
        >
          Add User
        </Button>
      </Toolbar>
      <Dialog
        open={open}
        fullWidth={true}
        maxWidth={'md'}
        fullScreen={isBelowMd}
      >
        <DialogContent dividers className={classes.dialogBox}>
          <div className={classes.dialogToolbar}>
            <Typography variant='h6'>Search Employee</Typography>
            <IconButton onClick={handleOpen} style={{ padding: 0 }}>
              <Icon>close</Icon>
            </IconButton>
          </div>
          <Grid container>
            <Grid item xs={12}>
              <Autocomplete
                multiple
                fullWidth
                className={classes.autoComplete}
                getOptionLabel={(option) =>
                  option.EmployeeName + ' ' + option.PayrollEmpno
                }
                onChange={(event, newValue) => {
                  setSelected(newValue);
                }}
                options={_.uniq([...options, ...selected]).sort((a, b) => {
                  // Display the selected labels first.
                  let ai = selected.indexOf(a);
                  ai = ai === -1 ? selected.length + options.indexOf(a) : ai;
                  let bi = selected.indexOf(b);
                  bi = bi === -1 ? selected.length + options.indexOf(b) : bi;
                  return ai - bi;
                })}
                renderOption={(option, { selected }) => {
                  return (
                    <React.Fragment>
                      <DoneIcon
                        className={classes.iconSelected}
                        style={{ visibility: selected ? 'visible' : 'hidden' }}
                      />
                      <div className={classes.text}>
                        {option.EmployeeName + ' ' + option.PayrollEmpno}
                      </div>
                      <CloseIcon
                        className={classes.close}
                        style={{ visibility: selected ? 'visible' : 'hidden' }}
                      />
                    </React.Fragment>
                  );
                }}
                renderInput={(params) => (
                  <>
                    <InputBase
                      ref={params.InputProps.ref}
                      inputProps={params.inputProps}
                      autoFocus
                      className={classes.inputBase}
                      onChange={onChangeKey}
                    />
                    <IconButton
                      aria-label='search'
                      color='primary'
                      onClick={handleSearch}
                    >
                      <Icon>search</Icon>
                    </IconButton>
                  </>
                )}
              />
            </Grid>
            <Grid item>
              <Box className={classes.listBox}>
                {_.isEmpty(selected) ? (
                  <Typography>No User Selected</Typography>
                ) : (
                  selected.map((label) => (
                    <Chip
                      key={label.PayrollEmpno}
                      label={label.EmployeeName}
                      variant='outlined'
                      className={classes.chips}
                      color='primary'
                    />
                  ))
                )}
              </Box>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button color='primary' onClick={handleAdd}>
            Add
          </Button>
          <Button color='secondary' onClick={handleCancel}>
            cancel
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
export default AddUser;
