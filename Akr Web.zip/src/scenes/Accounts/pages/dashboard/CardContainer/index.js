import React, { useEffect, Suspense } from 'react';
import propTypes from 'prop-types';
import {
  Box,
  Card,
  CardContent,
  Grid,
  Icon,
  Typography,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';

const drawerWidth = 200;
const useStyles = makeStyles((theme) => ({
  Card: {
    margin: theme.spacing(0, 1, 0, 1),
  },
  cardContent: {
    backgroundColor: theme.palette.grey[50],
    display: 'flex',
    justifyContent: 'space-between',
    flexDirection: 'column',
    justifyItems: 'center',
    minHeight: '150px',
  },
  CardValues: {
    display: 'flex',
  },
  cardIcon: {
    margin: theme.spacing(0, 1),
  },
}));

const Grids = () => {
  const classes = useStyles();

  return (
    <Grid container>
      <Grid item xs={12} md={2}>
        <Card className={classes.Card}>
          <CardContent className={classes.cardContent}>
            <Icon className={classes.cardIcon}>batch_prediction</Icon>
            <Typography variant='subtitle1'>05</Typography>
            <Typography variant='h5'> Total Batches</Typography>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={2}>
        <Card className={classes.Card}>
          <CardContent className={classes.cardContent}>
            <Icon className={classes.cardIcon}>recommend</Icon>
            <Typography variant='subtitle1'>05</Typography>

            <Typography variant='h5'>Total Approved</Typography>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={2}>
        <Card className={classes.Card}>
          <CardContent className={classes.cardContent}>
            <Icon className={classes.cardIcon}>payments</Icon>
            <Typography variant='subtitle1'>160000000 INR</Typography>
            <Typography variant='h5'>Total payments</Typography>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};
Grids.propTypes = {};
export default Grids;
