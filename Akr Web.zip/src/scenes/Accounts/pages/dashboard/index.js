import React, { useEffect, Suspense } from 'react';
import propTypes from 'prop-types';
import {
  Box,
  Card,
  CardContent,
  Grid,
  Icon,
  Typography,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import classNames from 'classnames';
import Skeleton from '@material-ui/lab/Skeleton';
const GridLazy = React.lazy(() => import('./CardContainer'));

const drawerWidth = 200;
const useStyles = makeStyles((theme) => ({
  Maincontainer: {
    padding: theme.spacing(3, 3),
  },
  shiftContent: {
    marginLeft: drawerWidth,
  },
}));
const DashBoard = () => {
  const classes = useStyles();

  return (
    <div className={classNames(classes.Maincontainer)}>
      <Suspense
        fallback={
          <>
            <Skeleton variant='rect' width={210} height={118} />
            <Box pt={0.5}>
              <Skeleton width='60%' />
              <Skeleton width='30%' />
            </Box>
          </>
        }
      >
        <GridLazy />
      </Suspense>
    </div>
  );
};

DashBoard.propTypes = {};
export default DashBoard;
