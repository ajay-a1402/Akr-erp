import { Grid, Typography } from '@material-ui/core';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import React, { useState } from 'react';
import { DatePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import * as _ from 'lodash';
import { TextField } from '@mui/material';
import { subDays, format } from 'date-fns';
import { makeStyles } from '@material-ui/core/styles';
const rows = [
  { id: 1, col1: 'Hello', col2: 'World' },
  { id: 2, col1: 'XGrid', col2: 'is Awesome' },
  { id: 3, col1: 'Material-UI', col2: 'is Amazing' },
  { id: 4, col1: 'Hello', col2: 'World' },
  { id: 5, col1: 'XGrid', col2: 'is Awesome' },
  { id: 6, col1: 'Material-UI', col2: 'is Amazing' },
];

const columns = [
  { field: 'id', hide: true },
  { field: 'col1', headerName: 'Column 1', width: 150 },
  { field: 'col2', headerName: 'Column 2', width: 150 },
];
const useStyles = makeStyles((theme) => ({
  dateField: {
    padding: theme.spacing(0, 1),
  },
}));

const ReportsMain = () => {
  const [dateRange, setDateRange] = useState({
    fromDate: subDays(new Date(), 30),
    toDate: new Date(),
  });
  const handleDate = (e, field) => {
    setDateRange((prev) => ({
      ...prev,
      [field]: e,
    }));
  };
  const classes = useStyles();
  return (
    <>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <Grid container>
          <Grid item container>
            <Grid item xs={12} md={6} className={classes.dateField}>
              <Typography>From Date:</Typography>
              <DatePicker
                value={dateRange.fromDate}
                onChange={(e) => {
                  handleDate(e, 'fromDate');
                }}
                renderInput={(params) => {
                  const value = _.get(params, 'inputProps.value');
                  const date = format(new Date(value), 'dd - MMM -yyyy');

                  return (
                    <TextField
                      {...params}
                      inputProps={{ value: date }}
                      fullWidth
                    />
                  );
                }}
              />
            </Grid>
            <Grid item xs={12} md={6} className={classes.dateField}>
              {' '}
              <Typography>To Date:</Typography>
              <DatePicker
                value={dateRange.toDate}
                onChange={(e) => {
                  handleDate(e, 'toDate');
                }}
                renderInput={(params) => {
                  const value = _.get(params, 'inputProps.value');
                  const date = format(new Date(value), 'dd - MMM -yyyy');

                  return (
                    <TextField
                      {...params}
                      inputProps={{ value: date }}
                      fullWidth
                    />
                  );
                }}
              />
            </Grid>
          </Grid>
        </Grid>

        <div style={{ height: 300, width: '100%' }}>
          <DataGrid
            rows={rows}
            columns={columns}
            components={{
              Toolbar: GridToolbar,
            }}
          />
        </div>
      </LocalizationProvider>
    </>
  );
};
export default ReportsMain;
