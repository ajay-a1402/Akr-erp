import React, { useEffect, useMemo, useCallback, useState } from 'react';
import api from '../../../../services/api';
import * as _ from 'lodash';
import AgGridCustom from '../../../../../../com_components/AgGridCustom';
import propTypes from 'prop-types';
import { batch, connect, useDispatch } from 'react-redux';
import {
  Box,
  Button,
  Typography,
  Select,
  MenuItem,
  Grid,
  useTheme,
  useMediaQuery,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import classnames from 'classnames';
import { API_ENDPOINTS, statusCode } from '../../../../../../constants';
import {
  hideLoader,
  showLoader,
} from '../../../../../../services/loader/actions';
import {
  updateBatchList,
  updateBillsInvoices,
  updateSelectedInvoice,
} from '../../../../services/api/actions';
import { clearAllSession } from '../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';

const useStyles = makeStyles((theme) => ({
  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
  toolBar: {
    display: 'flex',
    alignItems: 'center',
  },
  nameCellStyle: {
    textAlign: 'left',

    color: theme.palette.text.primary,
    '&:focus': {
      color: `${theme.palette.text.primary} !important`,
    },
  },
  heading: {
    fontWeight: 600,
  },
  vendorCodeCellStyles: {
    color: theme.palette.text.primary,
    '&:focus': {
      color: `${theme.palette.text.primary} !important`,
    },
  },
  tableAppBar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing(0, 1, 0, 0),
  },
  buttonStyles: {
    textTransform: 'capitalize',
    height: '30px',
    backgroundColor: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: '#a7ebbb',
    },
  },
  selectContainer: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
  buttonContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: theme.spacing(2),
  },
  saveButtonStyles: {
    textTransform: 'capitalize',
    height: '30px',
    marginLeft: theme.spacing(1),
    backgroundColor: theme.palette.primary.light,
    '&:hover': {
      backgroundColor: '#a7ebbb',
    },
  },
  headerCell: {
    fontSize: '12px',
    backgroundColor: theme.palette.grey[100],
    padding: `${theme.spacing(0.5, 0)} !important`,
  },
}));
const BatchTabel = (props) => {
  const [rowData, setRowData] = useState([]);
  const gridref = React.useRef();
  const {
    state,
    ShowLoader,
    HideLoader,
    UpdateInvoices,
    UpdateBatchList,
    UpdateSelectedInvoice,
  } = props;
  const [selected, setSelected] = useState({
    field: 'Above90',
    party: null,
    isSelected: false,
  });
  const dispatch = useDispatch();
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  const history = useHistory();
  const classes = useStyles();
  useEffect(() => {
    if (
      !_.isEqual(_.get(state.batch, 'PayBatchEnno', 0), 0) &&
      !_.isEmpty(state.batch)
    ) {
      api
        .fetchBatchVendors(_.get(state.batch, 'PayBatchEnno', 0))
        .then((res) => {
          setRowData(res.data.data);
        })
        .catch((err) => {
          if (err.response) {
            if (err.response.status === 401) {
              clearAllSession();
              history.replace('/accounts/authfail');
            }
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'Check network Connection',
                severity: 'error',
                onclose: true,
              })
            );
          }
        });
    }
    UpdateInvoices({ data: [], AlottedAmount: 0, vendorID: null });
    setSelected({
      field: 'Above90',
      party: null,
      isSelected: false,
    });
    UpdateSelectedInvoice([]);
    return setRowData(null);
  }, [state.batch]);

  // useMemo(() => {
  //   UpdateBatchList([]);
  // }, [state.selectedInvoice]);

  const valuegetter = (params) => {
    if (!_.isEmpty(state.selectedInvoice)) {
      return (params.data.AllotAmount = _.sumBy(
        _.filter(state.selectedInvoice, (o) => {
          return o.partyid === params.data.Partyid;
        }),
        (data) => {
          return data.AllotAmount;
        }
      ));
    } else {
      return (params.data.AllotAmount = _.get(params.data, 'AllotAmount', 0));
    }
  };
  const handleSave = () => {
    const rowdata =
      gridref.current.api.getModel().gridOptionsWrapper.gridOptions.rowData;
    UpdateBatchList(rowdata);
  };
  const colDef = [
    {
      field: 'PartyName',
      headerName: 'Party Name',
      headerTooltip: 'Party Name',
      tooltipField: 'Partyname',
      // headerCheckboxSelection: true,
      checkboxSelection: true,
      // headerCheckboxSelectionFilteredOnly: true,
      minWidth: 200,
      disableClickSelection: true,
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'vendorcode',
      headerName: 'vendor code',
      headerTooltip: 'vendor code',
      disableClickSelection: true,
      cellClass: classnames(
        classes.staticCellStyle,
        classes.vendorCodeCellStyles
      ),
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'PayBatchEnno',
      headerName: 'Pay Batch Enno',
      headerTooltip: 'Pay Batch Enno',
      disableClickSelection: true,
      cellClass: classnames(
        classes.staticCellStyle,
        classes.vendorCodeCellStyles
      ),
      hide: true,
    },
    {
      field: 'Partyid',
      headerName: 'PartyId',
      headerTooltip: 'vendor code',
      disableClickSelection: true,
      headerClass: classnames(classes.headerCell),

      cellClass: classnames(
        classes.staticCellStyle,
        classes.vendorCodeCellStyles
      ),
    },
    {
      field: 'Below30',
      headerName: '< 30',
      disableClickSelection: true,
      headerClass: classnames(classes.headerCell),
      headerTooltip: 'Payment Below 30 days',
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'Days30to60',
      headerName: '30 - 60 ',
      disableClickSelection: true,
      headerTooltip: 'Payment between 30 to 60 days',
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'Days60to90',
      headerName: '60 - 90 ',
      headerTooltip: 'Payment between 60 to 90 days',
      disableClickSelection: true,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'Above90',
      headerName: ' > 90',
      headerTooltip: 'Payment Above 90 days',
      disableClickSelection: true,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'ReqAmount',
      headerName: 'Batch Amount',
      headerTooltip: 'Batch Amount',
      disableClickSelection: true,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'PreviousBatchBalance',
      headerName: 'Previous Batch Balance',
      headerTooltip: 'Previous Batch Balance Amount',
      disableClickSelection: true,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'Alotted',
      headerName: 'Alloted',
      headerTooltip: 'Alotted Amount',
      // disableClickSelection: true,
      // editable: true,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
      valueGetter: valuegetter,
    },
    {
      field: 'AccNo',
      hide: true,
    },
    {
      field: 'AccName',
      hide: true,
    },
    {
      field: 'BankName',
      hide: true,
    },
    {
      field: 'Branch',
      hide: true,
    },
    {
      field: 'IFSCode',
      hide: true,
    },
  ];
  const handleGetInvoice = () => {
    ShowLoader('Please wait ... searching for invoice');
    api.fetchWithParams(
      API_ENDPOINTS.FETCH_VENDOR_INVOICE,
      (res) => {
        HideLoader();
        UpdateInvoices({
          data: res.data.data,
          AlottedAmount: parseFloat(selected.party.ReqAmount),
          vendorID: selected.party.Partyid,
        });
      },
      (err) => {
        HideLoader();
        if (err.response) {
          UpdateInvoices({ data: [], AlottedAmount: 0, vendorID: null });
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      { party_id: selected.party.Partyid, duration: selected.field }
    );
  };

  const handleChange = (e) => {
    setSelected((prev) => ({
      ...prev,
      field: e.target.value,
    }));
  };
  const gridOptions = {
    rowSelection: 'single',
    suppressRowClickSelection: true,
  };

  return (
    <Box>
      <Grid container>
        <Grid item xs={12} md={6} className={classes.toolBar}>
          <Typography variant='h6' className={classes.heading}>
            Batch Details
          </Typography>
        </Grid>
        <Grid item xs={12} md={3} className={classes.selectContainer}>
          {' '}
          <Select
            label='select Duriation'
            id='demo-simple-select'
            value={selected.field}
            fullWidth
            onChange={handleChange}
          >
            {selectOptions.map((item, idx) => (
              <MenuItem key={idx} value={item.value}>
                {item.label}
              </MenuItem>
            ))}
          </Select>
        </Grid>
        <Grid item container xs={12} md={3} className={classes.buttonContainer}>
          {' '}
          <Grid item>
            <Button
              onClick={handleGetInvoice}
              disabled={!selected.isSelected}
              className={classes.buttonStyles}
            >
              Get invoice
            </Button>
          </Grid>
          <Grid item>
            {' '}
            <Button onClick={handleSave} className={classes.saveButtonStyles}>
              Save All
            </Button>
          </Grid>
        </Grid>
      </Grid>
      <AgGridCustom
        getRef={gridref}
        rowData={rowData}
        columnDefs={colDef}
        noDataTxt='No bills available'
        suppressRowDeselection={true}
        height={isBelowMd ? 100 : 25}
        defaultColDef={{
          initialWidth: 100,
          sortable: true,
          resizable: true,
        }}
        handleCellClick={(e) => {
          setSelected((prev) => ({
            ...prev,
            field: e.colDef.field,
            party: e.data,
          }));
        }}
        enterMovesDown={true}
        enterMovesDownAfterEdit={true}
        onSelectionChanged={(props) => {
          let result = props.api.getSelectedRows();
          if (result.length > 0)
            setSelected((prev) => ({
              ...prev,
              party: result[0],
              isSelected: true,
            }));
          else
            setSelected((prev) => ({
              ...prev,
              party: null,
              isSelected: false,
            }));
        }}
        gridOptions={gridOptions}
      />
    </Box>
  );
};
const mapStateToProps = (state) => ({
  state: state.AccountsBillsReducer,
});
const mapDispatchToProps = (dispatch) => ({
  ShowLoader: (loaderText) => dispatch(showLoader(loaderText)),
  HideLoader: () => dispatch(hideLoader()),
  UpdateInvoices: (data) => dispatch(updateBillsInvoices(data)),
  UpdateBatchList: (data) => dispatch(updateBatchList(data)),
  UpdateSelectedInvoice: (data) => {
    dispatch(updateSelectedInvoice(data));
  },
});
const selectOptions = [
  {
    value: 'Below30',
    label: 'Below 30',
  },
  {
    value: 'Days30to60',
    label: 'Days 30 to 60',
  },
  {
    value: 'Days60to90',
    label: 'Days 60 to 90',
  },
  {
    value: 'Above90',
    label: 'Above 90',
  },
];
BatchTabel.propTypes = {};

export default connect(mapStateToProps, mapDispatchToProps)(BatchTabel);
