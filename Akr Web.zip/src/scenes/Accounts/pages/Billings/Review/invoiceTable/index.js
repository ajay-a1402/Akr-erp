import React, {
  useEffect,
  useMemo,
  useCallback,
  useImperativeHandle,
  useState,
} from 'react';
import api from '../../../../services/api';
import * as _ from 'lodash';
import AgGridCustom from '../../../../../../com_components/AgGridCustom';
import propTypes from 'prop-types';
import {
  Box,
  Typography,
  Button,
  Grid,
  useTheme,
  useMediaQuery,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import classnames from 'classnames';
import moment from 'moment';
import { convertGmtToLocalTime } from '../../../../../../com_utils';
import { isApprovar, isGuest, isMember } from '../../../../utils';

import { API_ENDPOINTS, statusCode } from '../../../../../../constants';
import { clearAllSession } from '../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
const useStyles = makeStyles((theme) => ({
  invoiceContainer: {
    // padding: theme.spacing(0, 0, 5, 0),
  },
  invoiceToolBar: {
    display: 'flex',
    alignItems: 'center',
  },
  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
  nameCellStyle: {
    textAlign: 'left',
    '& .ag-header-cell-label': {
      /* Necessary to allow for text to grow vertically */
    },
  },
  headerCell: {
    fontSize: '12px',
    backgroundColor: theme.palette.grey[100],
    padding: `${theme.spacing(0.5, 0)} !important`,
  },
  heading: {
    fontWeight: 600,
    padding: theme.spacing(2, 0),
  },

  batchNoHeader: {
    paddingLeft: `${theme.spacing(0)} !important`,
  },
  dateCellContent: {
    height: '100%',
    display: 'flex',
    // '&:focus': {},
  },
  actionContainer: {
    display: 'flex',
    justifyContent: 'flex-end',
    padding: theme.spacing(1, 2),
  },
  approveButton: {
    backgroundColor: theme.palette.success.light,
  },
}));
const ReviewInvoiceTabel = (props) => {
  const [rowData, setRowData] = useState([]);
  const history = useHistory();
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  const { reviewState } = props;
  const classes = useStyles();

  useEffect(() => {
    if (reviewState.party) {
      api.fetchWithParams(
        API_ENDPOINTS.FETCH_BATCH_INVOICE,
        (res) => {
          setRowData(res.data.data);
        },
        (err) => {
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        },
        { PayAllotSubEnno: reviewState.party.PayAllotSubEnno }
      );
      setRowData([]);
    }
  }, [reviewState.party]);
  const colDef = [
    {
      field: 'Bno',
      headerName: 'B NO',
      headerTooltip: 'Batch number',
      tooltipField: 'Bno',
      headerClass: classnames(classes.batchNoHeader, classes.headerCell),
      headerCheckboxSelection: true,
      checkboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      minWidth: 120,
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },

    {
      field: 'Billgroupno',
      headerName: 'Bill Group',
      headerTooltip: 'Bill Group No',
      tooltipField: 'Billgroupno',
      minWidth: 120,
      headerClass: classnames(classes.headerCell),
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },
    {
      field: 'PartyName',
      headerName: 'Party Name',
      headerTooltip: 'Party Name',
      tooltipField: 'Partyname',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },
    {
      field: 'BDate',
      headerName: 'Date',
      headerTooltip: 'Bill Date',
      cellClass: [classes.staticCellStyle],
      cellRenderer: 'dateCellRenderer',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      cellRendererParams: {
        containerClass: classes.dateCellContent,
      },
    },
    {
      field: 'PartyId',
      headerName: 'vendor code',
      headerTooltip: 'vendor code',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BatchAmount',
      headerName: 'Batch Amount',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      headerTooltip: 'Batch Amount',
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BillAmount',
      headerName: 'Bill Amount',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      headerTooltip: 'Bill Amount',
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BillBalance',
      headerClass: classnames(classes.headerCell),
      headerName: 'Bill Balance',
      headerTooltip: 'Bill Balance',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BillPaidBalance',
      headerName: 'Bill Paid Balance',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      headerTooltip: 'Bill Paid Balance',
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'PayAmount',
      headerName: 'Allot Amount',
      headerTooltip: 'Allot Amount',
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      cellEditor: 'numericCellEditor',
      cellClass: classes.staticCellStyle,
      hide: isGuest(),
    },
  ];
  return (
    <Grid container className={classes.invoiceContainer}>
      <Grid item container className={classes.invoiceToolBar} xs={12}>
        <Grid item xs={12} md={6}>
          <Typography variant='h6' className={classes.heading}>
            Invoice Details
          </Typography>
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography>
            Alloted Amount : {_.get(reviewState.party, 'AllotAmount', 0)}
          </Typography>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <AgGridCustom
          rowData={rowData}
          columnDefs={colDef}
          noDataTxt='No bills available'
          suppressRowClickSelection={true}
          rowSelection={'multiple'}
          height={isBelowMd ? 100 : 25}
          frameworkComponents={{
            dateCellRenderer: withCellRenderState(dateCellRenderer),
          }}
          defaultColDef={{
            initialWidth: 100,
            sortable: true,
            resizable: true,
          }}
          handleCellClick={(e) => {}}
          enterMovesDown={true}
          enterMovesDownAfterEdit={true}
        />
      </Grid>
    </Grid>
  );
};
ReviewInvoiceTabel.propTypes = {};
export default ReviewInvoiceTabel;

export const withCellRenderState = (CellRenderer) => {
  // eslint-disable-next-line react/display-name
  return React.forwardRef((props, ref) => {
    /* eslint-disable react/prop-types */

    const [value, setValue] = useState(props.value);

    useImperativeHandle(ref, () => {
      return {
        refresh: (params) => {
          if (params.value !== value) {
            setValue(params.value);
          }
          return true;
        },
      };
    });
    return <CellRenderer {...props}></CellRenderer>;
  });
};
withCellRenderState.propTypes = {
  value: propTypes.object,
};
export const dateCellRenderer = (props) => {
  const { value, data } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );

  return (
    <div className={containerClassName}>
      <span>
        {data
          ? moment(convertGmtToLocalTime(data.BDate)).format('DD-MM-YYYY')
          : ''}
      </span>
    </div>
  );
};
dateCellRenderer.propTypes = {
  value: propTypes.any,
};
