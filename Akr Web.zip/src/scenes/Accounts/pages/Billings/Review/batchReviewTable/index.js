import React, {
  useEffect,
  useMemo,
  //   useImperativeHandle,
  useState,
  //   useRef,
} from 'react';
import api from '../../../../services/api';
import * as _ from 'lodash';
import AgGridCustom from '../../../../../../com_components/AgGridCustom';
import propTypes from 'prop-types';
import { connect, useDispatch } from 'react-redux';
import {
  Box,
  //   Button,
  Typography,
  Grid,
  //   Icon,
  //   IconButton,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import classnames from 'classnames';
import { API_ENDPOINTS, statusCode } from '../../../../../../constants';
import {
  hideLoader,
  showLoader,
} from '../../../../../../services/loader/actions';
import {
  updateBatchList,
  updateReviewInvoices,
} from '../../../../services/api/actions';
import { clearAllSession } from '../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';

const useStyles = makeStyles((theme) => ({
  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
    fontSize: '12px !important',
  },
  nameCellStyle: {
    textAlign: 'left',

    color: theme.palette.text.primary,
    '&:focus': {
      color: `${theme.palette.text.primary} !important`,
    },
  },
  headerCell: {
    fontSize: '12px !important',
    backgroundColor: theme.palette.grey[100],
    padding: `${theme.spacing(0.5, 0)} !important`,
  },
  heading: {
    fontWeight: 600,
    padding: theme.spacing(2, 0),
  },
  vendorCodeCellStyles: {
    color: theme.palette.text.primary,
    '&:focus': {
      color: `${theme.palette.text.primary} !important`,
    },
  },
  tableAppBar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing(0, 1, 0, 0),
  },
  buttonStyles: {
    textTransform: 'capitalize',
    height: '30px',
    backgroundColor: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: '#a7ebbb',
    },
  },
  selectContainer: {
    display: 'flex',
    alignItems: 'center',
  },
  buttonContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveButtonStyles: {
    textTransform: 'capitalize',
    height: '30px',
    marginLeft: theme.spacing(1),
    backgroundColor: theme.palette.primary.light,
    '&:hover': {
      backgroundColor: '#a7ebbb',
    },
  },
  actionCell: {
    display: 'flex',
    flexDirection: 'column',
  },
  iconButtons: {
    marginLeft: theme.spacing(3),
  },
  approveIcon: {
    color: theme.palette.success.main,
  },
  rejectIcon: {
    color: theme.palette.warning.main,
  },
}));
const BatchReviewTabel = (props) => {
  const [rowData, setRowData] = useState([]);
  const gridref = React.useRef();
  const history = useHistory();
  const { reviewState, setReviewState } = props;
  const dispatch = useDispatch();

  const classes = useStyles();
  useEffect(() => {
    api
      .fetchBatchVendors(_.get(reviewState.selectedBatch, 'PayBatchEnno', 0))
      .then((res) => {
        setRowData(res.data.data);
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/Authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      });

    return setRowData(null);
  }, [reviewState.selectedBatch]);

  const colDef = useMemo(() => {
    return [
      {
        field: 'PartyName',
        headerName: 'Party Name',
        headerTooltip: 'Party Name',
        tooltipField: 'Partyname',
        // headerCheckboxSelection: true,
        checkboxSelection: true,
        // headerCheckboxSelectionFilteredOnly: true,
        minWidth: 200,
        disableClickSelection: true,
        headerClass: classnames(classes.headerCell),
        cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
      },
      {
        field: 'vendorcode',
        headerName: 'vendor code',
        headerTooltip: 'vendor code',
        minWidth: 150,
        disableClickSelection: true,
        headerClass: classnames(classes.headerCell),
        cellClass: classnames(
          classes.staticCellStyle,
          classes.vendorCodeCellStyles
        ),
      },
      {
        field: 'PayBatchEnno',
        headerName: 'Pay Batch Enno',
        headerTooltip: 'Pay Batch Enno',
        headerClass: classnames(classes.headerCell),
        disableClickSelection: true,
        minWidth: 100,
        cellClass: classnames(
          classes.staticCellStyle,
          classes.vendorCodeCellStyles
        ),
        hide: true,
      },
      {
        field: 'Partyid',
        headerName: 'PartyId',
        headerTooltip: 'vendor code',
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        disableClickSelection: true,
        cellClass: classnames(
          classes.staticCellStyle,
          classes.vendorCodeCellStyles
        ),
      },
      {
        field: 'Below30',
        headerName: '< 30',
        minWidth: 100,
        disableClickSelection: true,
        headerClass: classnames(classes.headerCell),
        headerTooltip: 'Payment Below 30 days',
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'Days30to60',
        headerName: '30 - 60',
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        disableClickSelection: true,
        headerTooltip: 'Payment between 30 to 60 days',
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'Days60to90',
        headerName: '60 - 90 ',
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        headerTooltip: 'Payment between 60 to 90 days',
        disableClickSelection: true,
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'Above90',
        headerName: ' > 90',
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        headerTooltip: 'Payment Above 90 days',
        disableClickSelection: true,
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'ReqAmount',
        headerName: 'Batch Amount',
        headerTooltip: 'Batch Amount',
        minWidth: 150,
        headerClass: classnames(classes.headerCell),
        disableClickSelection: true,
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'PreviousBatchBalance',
        headerName: 'Previous Batch Balance',
        headerTooltip: 'Previous Batch Balance Amount',
        disableClickSelection: true,
        minWidth: 150,
        headerClass: classnames(classes.headerCell),
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'AllotAmount',
        headerName: 'Alloted',
        minWidth: 150,
        headerTooltip: 'Alotted Amount',
        // disableClickSelection: true,
        // editable: true,
        headerClass: classnames(classes.headerCell),
        cellClass: classes.staticCellStyle,
      },
      //   {
      //     field: 'app1flag',
      //     headerClass: classes.tableHeader,

      //     headerName: '1st Approve',
      //     headerTooltip: 'Previous Batch Balance Amount',
      //     disableClickSelection: true,
      //     cellClass: classes.staticCellStyle,
      //     cellRenderer: 'StatueCellRenderer',
      //   },
      //   {
      //     field: 'app2flag',
      //     headerName: '2nd Approve',
      //     headerClass: classes.tableHeader,

      //     headerTooltip: 'Previous Batch Balance Amount',
      //     disableClickSelection: true,
      //     cellClass: classes.staticCellStyle,
      //     cellRenderer: 'StatueCellRenderer',
      //   },
      //   {
      //     field: '',
      //     headerName: 'Action',
      //     disableClickSelection: true,
      //     headerClass: classes.tableHeader,
      //     //   cellClass: classes.staticCellStyle,
      //     cellRenderer: 'ActionCellRenderer',
      //     cellRenderParams: {
      //       containerClass: classes.actionCell,
      //       approveAction,
      //       rejectAction,
      //     },
      //   },
      {
        field: 'AccNo',
        hide: true,
      },
      {
        field: 'AccName',
        hide: true,
      },
      {
        field: 'BankName',
        // hide: true,
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'Branch',
        // hide: true,
        minWidth: 100,
        headerClass: classnames(classes.headerCell),
        cellClass: classes.staticCellStyle,
      },
      {
        field: 'IFSCode',
        hide: true,
      },
    ].filter(Boolean);
  }, []);

  const gridOptions = {
    rowSelection: 'single',
    suppressRowClickSelection: true,
  };
  // console.log('ref', gridref);

  // if (gridref !== undefined) {
  //   console.log('ref', gridref.api);
  // }

  return (
    <Box>
      <Grid container>
        <Grid item xs={8}>
          <Typography variant='h6' className={classes.heading}>
            Batch Details
          </Typography>
        </Grid>
      </Grid>
      <AgGridCustom
        getRef={gridref}
        rowData={rowData}
        columnDefs={colDef}
        noDataTxt='No bills available'
        suppressRowDeselection={true}
        height={25}
        defaultColDef={{
          initialWidth: 100,
          sortable: true,
          resizable: true,
        }}
        handleCellClick={(e) => {
          setReviewState((prev) => ({
            ...prev,
            field: e.colDef.field,
            party: e.data,
          }));
        }}
        enterMovesDown={true}
        // frameworkComponents={{
        //   StatueCellRenderer: withCellRenderState(StatueCellRenderer),
        //   ActionCellRenderer: withCellRenderState(ActionCellRenderer),
        // }}
        enterMovesDownAfterEdit={true}
        onSelectionChanged={(props) => {
          let result = props.api.getSelectedRows();
          if (result.length > 0)
            setReviewState((prev) => ({
              ...prev,
              party: result[0],
              isSelected: true,
            }));
          else
            setReviewState((prev) => ({
              ...prev,
              party: null,
              isSelected: false,
            }));
        }}
        gridOptions={gridOptions}
      />
    </Box>
  );
};
const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => ({
  ShowLoader: (loaderText) => dispatch(showLoader(loaderText)),
  HideLoader: () => dispatch(hideLoader()),
  UpdateReviewInvoices: (data) => dispatch(updateReviewInvoices(data)),
  UpdateBatchList: (data) => dispatch(updateBatchList(data)),
});

BatchReviewTabel.propTypes = {};
// export const withCellRenderState = (CellRenderer) => {
//   // eslint-disable-next-line react/display-name
//   return React.forwardRef((props, ref) => {
//     /* eslint-disable react/prop-types */

//     const [value, setValue] = useState(props.value);

//     useImperativeHandle(ref, () => {
//       return {
//         refresh: (params) => {
//           if (params.value !== value) {
//             setValue(params.value);
//           }
//           return true;
//         },
//       };
//     });
//     return <CellRenderer {...props}></CellRenderer>;
//   });
// };
// withCellRenderState.propTypes = {
//   value: propTypes.object,
// };

// const StatueCellRenderer = (props) => {
//   const { value, data } = props;
//   const classes = useStyles();
//   const containerClassName = _.get(
//     props,
//     'colDef.cellRendererParams.containerClass'
//   );

//   return (
//     <div className={containerClassName}>
//       <span>
//         {_.isEqual(value, 1) ? (
//           <Icon fontSize='small' className={classes.approveIcon}>
//             check_circle_outline
//           </Icon>
//         ) : (
//           <Icon fontSize='small' className={classes.rejectIcon}>
//             highlight_off
//           </Icon>
//         )}
//       </span>
//     </div>
//   );
// };

// const ActionCellRenderer = (props) => {
//   const classes = useStyles();
//   const { value, data } = props;
//   const containerClassName = _.get(
//     props,
//     'colDef.cellRendererParams.containerClass'
//   );

//   const approveAction = _.get(props, 'colDef.cellRenderParams.approveAction');
//   const rejectAction = _.get(props, 'colDef.cellRenderParams.rejectAction');
//   return (
//     <div className={containerClassName}>
//       <IconButton
//         size='small'
//         onClick={(e) => {
//           props.node.selected && approveAction(e);
//         }}
//         className={classnames(classes.iconButtons, classes.approveIcon)}
//       >
//         <Icon>check</Icon>
//       </IconButton>
//       <IconButton
//         size='small'
//         onClick={(e) => {
//           props.node.selected && rejectAction(e);
//         }}
//         className={classnames(classes.iconButtons, classes.rejectIcon)}
//       >
//         <Icon>close</Icon>
//       </IconButton>
//     </div>
//   );
// };
// ActionCellRenderer.propTypes = {
//   value: propTypes.any,
// };
// StatueCellRenderer.propTypes = {
//   value: propTypes.any,
// };
export default connect(mapStateToProps, mapDispatchToProps)(BatchReviewTabel);
