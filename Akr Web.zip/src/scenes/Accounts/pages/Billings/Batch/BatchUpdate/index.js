import { Box, Container, Icon, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useEffect, useState } from 'react';
import AgGridCustom from '../../../../../../com_components/AgGridCustom';
import { connect, useDispatch } from 'react-redux';
import {
  clearAllSession,
  getSessionStorageItem,
} from '../../../../../../services/sessionStorage';
import Api from '../../../../services/api';
import { useHistory } from 'react-router';
import classnames from 'classnames';
import {
  withCellRenderState,
  dateCellRenderer,
  approveCellRenderer,
  deleteCellRenderer,
} from './customCells';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';
import { API_ENDPOINTS } from '../../../../../../constants';

const useStyles = makeStyles((theme) => ({
  Text: {
    display: 'flex',
    height: '50Vh',
    justifyContent: 'center',
    alignItems: 'center',
  },
  rootContainer: {
    padding: theme.spacing(1),
  },
  subContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  Icon: {
    fontSize: '100px',
  },
  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
  batchNoHeader: {
    paddingLeft: `${theme.spacing(0)} !important`,
  },
  tableHeader: {
    '& .ag-cell-label-container': {
      '& .ag-header-cell-label': {
        justifyContent: 'center !important',
      },
    },
  },
  approveCell: {
    margin: theme.spacing(1, 0, 0, 0),
  },
}));
const UpdateBatch = () => {
  const classes = useStyles();
  const history = useHistory();
  const [rowData, SetRowData] = useState([]);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(showLoader('Fetching Batches Please wait...'));
    Api.GetRequest(
      API_ENDPOINTS.FETCH_REVIEW_BATCHES,
      (res) => {
        dispatch(hideLoader());
        SetRowData(res.data.data);
      },
      (err) => {
        dispatch(hideLoader());

        if (err.response) {
          if (err.response.status === 401) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      }
    );
  }, []);

  const onClickDelete = (e) => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to delete this Batch No: ${e.PayBatchEnno} ?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          Api.DeleteRequest(
            API_ENDPOINTS.DELETE_PAYBATCH,
            (res) => {
              dispatch(hideLoader());
              SetRowData(res.data.data);
              dispatch(
                showAdvanceSnackbar({
                  msg: 'Batch deleted..!',
                  severity: 'success',
                  onclose: true,
                })
              );
            },
            (err) => {
              dispatch(hideLoader());

              if (err.response) {
                if (err.response.status === 408) {
                  clearAllSession();
                  history.replace('/accounts/authfail');
                }
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Check network Connection',
                    severity: 'error',
                    onclose: true,
                  })
                );
              }
            },
            { PayBatchEnno: e.PayBatchEnno }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };
  const colDef = [
    {
      field: 'S.no',
      valueGetter: 'node.rowIndex',
      headerClass: classnames(classes.tableHeader),
      cellClass: classes.staticCellStyle,
      minWidth: 100,
    },
    {
      field: 'PayBatchEnno',
      headerName: 'EnNo',
      headerTooltip: 'Entry No',
      headerClass: classnames(classes.tableHeader),
      cellClass: classes.staticCellStyle,
      minWidth: 150,
    },
    {
      field: 'EmployeeName',
      headerName: 'Entry By',
      headerTooltip: 'Created By',
      headerClass: classnames(classes.tableHeader),
      cellClass: classes.staticCellStyle,
      minWidth: 150,
    },
    {
      field: 'Entrydate',
      headerName: 'Created On',
      headerTooltip: 'Created By',
      headerClass: classnames(classes.tableHeader),
      cellRenderer: 'dateCellRenderer',
      cellClass: classes.staticCellStyle,
      minWidth: 150,
    },
    {
      field: 'FundAvailable',
      headerName: 'Avail Fund',
      headerTooltip: 'Avail Fund',
      headerClass: classnames(classes.tableHeader),
      minWidth: 150,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'app1flag',
      headerName: 'Approve 1',
      headerTooltip: 'Approve 1',
      headerClass: classnames(classes.tableHeader),
      cellRenderer: 'approveCellRenderer',
      minWidth: 150,
      cellRendererParams: {
        containerClass: classes.approveCell,
      },
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'app2flag',
      headerName: 'Aprrove 2',
      headerClass: classnames(classes.tableHeader),
      minWidth: 150,
      headerTooltip: 'Aprrove 2',
      cellRenderer: 'approveCellRenderer',
      cellClass: classes.staticCellStyle,
      cellRendererParams: {
        containerClass: classes.approveCell,
      },
    },
    {
      field: '',
      minWidth: 100,
      cellRenderer: 'deleteCellRenderer',
      cellClass: classes.staticCellStyle,
      cellRendererParams: {
        // containerClass: classes.approveCell,
        onClickDelete,
      },
    },
  ];
  return (
    <div className={classes.rootContainer}>
      <AgGridCustom
        rowData={rowData}
        columnDefs={colDef}
        noDataTxt='No bills available'
        handleCellClick={() => {}}
        height={250}
        defaultColDef={{
          initialWidth: 40,
          sortable: true,
          resizable: true,
        }}
        frameworkComponents={{
          dateCellRenderer: withCellRenderState(dateCellRenderer),
          approveCellRenderer: withCellRenderState(approveCellRenderer),
          deleteCellRenderer: withCellRenderState(deleteCellRenderer),
        }}
      />
    </div>
  );
};

export default UpdateBatch;
