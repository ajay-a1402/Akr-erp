import { Box, Grid, Toolbar, Typography } from '@material-ui/core';
import classNames from 'classnames';
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import BatchCreate from './BatchCreation';
import ScrollableTabsButtonAuto from '../../../components/TabBar';
import UpdateBatch from './BatchUpdate';
const useStyles = makeStyles((theme) => ({
  rootContainer: {
    paddingLeft: theme.spacing(1),
  },
}));

const BatchTabs = [
  {
    id: 'createBatch',
    label: 'Create Batch',
    tabPanel: BatchCreate,
  },
  {
    id: 'BatchDetails',
    label: 'Batch Details',
    tabPanel: UpdateBatch,
  },
];
const Batch = () => {
  const classes = useStyles();
  return (
    <>
      <ScrollableTabsButtonAuto
        options={BatchTabs}
        defaultTabId={BatchTabs[0].id}
      />
    </>
  );
};

export default Batch;
