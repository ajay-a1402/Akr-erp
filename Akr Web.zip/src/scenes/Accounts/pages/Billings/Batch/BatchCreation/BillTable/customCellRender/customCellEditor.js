// import React, {
//   forwardRef,
//   useEffect,
//   useImperativeHandle,
//   useRef,
//   useState,
// } from 'react';
// import { TextField } from '@material-ui/core';
// const KEY_BACKSPACE = 8;
// const KEY_DELETE = 46;
// const KEY_ENTER = 13;
// const KEY_TAB = 9;
// // eslint-disable-next-line react/display-name
// export default forwardRef((props, ref) => {
//   const getInitialValue = (props) => {
//     let startValue = props.value;

//     const keyPressBackspaceOrDelete =
//       props.keyPress === KEY_BACKSPACE || props.keyPress === KEY_DELETE;
//     if (keyPressBackspaceOrDelete) {
//       startValue = '';
//     } else if (props.charPress) {
//       startValue = props.charPress;
//     }

//     if (startValue !== null && startValue !== undefined) {
//       return startValue;
//     }

//     return '';
//   };
//   const getCharCodeFromEvent = (event) => {
//     event = event || window.event;
//     return typeof event.which === 'undefined' ? event.keyCode : event.which;
//   };

//   const isCharNumeric = (charStr) => {
//     return !!/\d/.test(charStr);
//   };
//   const isKeyPressedNumeric = (event) => {
//     const charCode = getCharCodeFromEvent(event);
//     const charStr = event.key ? event.key : String.fromCharCode(charCode);
//     return isCharNumeric(charStr);
//   };

//   const deleteOrBackspace = (event) => {
//     return [KEY_DELETE, KEY_BACKSPACE].indexOf(event.keyCode) > -1;
//   };

//   const finishedEditingPressed = (event) => {
//     const charCode = getCharCodeFromEvent(event);
//     return charCode === KEY_ENTER || charCode === KEY_TAB;
//   };
//   const isLeftOrRight = (event) => {
//     return [37, 39].indexOf(event.keyCode) > -1;
//   };
//   const onKeyDown = (event) => {
//     if (isLeftOrRight(event) || deleteOrBackspace(event)) {
//       event.stopPropagation();
//       return;
//     }

//     if (!finishedEditingPressed(event) && !isKeyPressedNumeric(event)) {
//       if (event.preventDefault) event.preventDefault();
//     }
//   };
//   const [value, setValue] = useState(getInitialValue(props));
//   const refInput = useRef(null);

//   useEffect(() => {
//     refInput.current.focus();
//     // return;
//   }, []);

//   useImperativeHandle(ref, () => {
//     return {
//       getValue() {
//         return value;
//       },

//       myCustomFunction() {
//         return {
//           rowIndex: props.rowIndex,
//           colId: props.column.getId(),
//         };
//       },
//     };
//   });

//   return (
//     <TextField
//       value={value}
//       ref={refInput}
//       onKeyDown={onKeyDown}
//       onChange={(event) => setValue(event.target.value)}
//       placeholder='Enter Requirement Value'
//       variant='outlined'
//     />
//   );
// });

import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState
} from 'react';
import { TextField } from '@material-ui/core';
const KEY_BACKSPACE = 8;
const KEY_DELETE = 46;
const KEY_ENTER = 13;
const KEY_TAB = 9;
// eslint-disable-next-line react/display-name
export default forwardRef((props, ref) => {
  const getInitialValue = (props) => {
    let startValue = props.value;

    const keyPressBackspaceOrDelete =
      props.keyPress === KEY_BACKSPACE || props.keyPress === KEY_DELETE;
    if (keyPressBackspaceOrDelete) {
      startValue = '';
    } else if (props.charPress) {
      startValue = props.charPress;
    }

    if (startValue !== null && startValue !== undefined) {
      return startValue;
    }

    return '';
  };
  const getCharCodeFromEvent = (event) => {
    event = event || window.event;
    return typeof event.which === 'undefined' ? event.keyCode : event.which;
  };
  var regExp = new RegExp('[0-9.,]+');

  const isCharNumeric = (charStr) => {
   // console.log(charStr);
    return regExp.test(charStr);
  };
  const isKeyPressedNumeric = (event) => {
    const charCode = getCharCodeFromEvent(event);
    const charStr = event.key ? event.key : String.fromCharCode(charCode);
    return isCharNumeric(charStr);
  };

  const deleteOrBackspace = (event) => {
    return [KEY_DELETE, KEY_BACKSPACE].indexOf(event.keyCode) > -1;
  };

  const finishedEditingPressed = (event) => {
    const charCode = getCharCodeFromEvent(event);
    return charCode === KEY_ENTER || charCode === KEY_TAB;
  };
  const isLeftOrRight = (event) => {
    return [37, 39].indexOf(event.keyCode) > -1;
  };
  const onKeyDown = (event) => {
    if (isLeftOrRight(event) || deleteOrBackspace(event)) {
      event.stopPropagation();
      return;
    }

    if (!finishedEditingPressed(event) && !isKeyPressedNumeric(event)) {
      if (event.preventDefault) event.preventDefault();
    }
  };
  const [value, setValue] = useState(getInitialValue(props));
  const refInput = useRef(null);

  useEffect(() => {
    refInput.current.focus();
    // return;
  }, []);

  useImperativeHandle(ref, () => {
    return {
      getValue() {
        return parseFloat(value);
      },

      myCustomFunction() {
        return {
          rowIndex: props.rowIndex,
          colId: props.column.getId(),
        };
      },
    };
  });

  return (
    <TextField
      value={value}
      ref={refInput}
      onKeyDown={(e) => {
        if (
          (e.keyCode >= 96 && e.keyCode <= 105) ||
          e.keyCode == 8 ||
          e.keyCode == 110 ||
          (e.keyCode > 36 && e.keyCode <= 40)
        ) {
          return;
        } else {
          if (e.preventDefault) e.preventDefault();
        }
      }}
      onChange={(event) => setValue(event.target.value)}
      placeholder='Alot Amount'
      variant='outlined'
    />
  );
});
