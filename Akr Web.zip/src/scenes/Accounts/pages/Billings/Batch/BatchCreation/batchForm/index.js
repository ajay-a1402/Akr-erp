import react, { useEffect, useState, useRef, useMemo } from 'react';
import propTypes from 'prop-types';

import {
  Box,
  Button,
  Grid,
  Icon,
  TextField,
  Typography,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import * as _ from 'lodash';
import { connect } from 'react-redux';
import AutocompleteWithChip from '../../../../../components/autoCompleteWithChip';
import { API_ENDPOINTS, statusCode } from '../../../../../../../constants';
import * as BillActions from '../../../../../services/api/actions';
import {
  clearAllSession,
  getSessionStorageItem,
} from '../../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import api from '../../../../../services/api/index';
import { useDispatch } from 'react-redux';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../../../services/snackbarAdvance/actions';
const useStyles = makeStyles((theme) => ({
  rootContainer: {
    marginBottom: theme.spacing(4),
  },
  batchContainer: {
    display: 'flex',
  },
  subHeading: {
    padding: theme.spacing(2),
  },
  ButtonWrapper: {
    paddingLeft: theme.spacing(2),
  },
}));
const BillForm = (props) => {
  const {
    updatevendor,
    updateBatchAmount,
    accountsState,
    updateBatchDetails,
    CreatBatchSuccess,
    UpdateSelecteBatch,
    tableRef,
  } = props;
  const classes = useStyles();
  const [options, setOptions] = useState([]);
  const [selected, setSelected] = useState([]);
  const [state, setState] = useState({
    loading: false,
    params: '',
    BatchAmount: 0,
    isComplete: false,
  });
  const dispatch = useDispatch();
  const history = useHistory();
  useEffect(() => {
    if (!_.isEmpty(state.params))
      api.fetchWithParams(
        API_ENDPOINTS.FETCH_VENDOR,

        (res) => {
          setOptions(res.data.data);
        },
        (err) => {
          if (err.response) {
            if (err.response.status === 400) {
              clearAllSession();
              history.replace('/accounts/authfail');
            }
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'Check network Connection',
                severity: 'error',
                onclose: true,
              })
            );
          }
        },
        { search: state.params }
      );
  }, [state.params]);
  useEffect(() => {
    return () => {
      setOptions([]);
      updatevendor([]);
      updateBatchAmount(0);
      setState({
        loading: false,
        params: '',
        BatchAmount: 0,
        isComplete: false,
      });
    };
  }, []);
  //update prams value to load table data in vendor table ref: BillTable folder
  useEffect(() => {
    let Vendor = [];
    _.map(selected, (vendor) => {
      Vendor.push(vendor.Id);
    });
    // redux action to update vendor in table
    updatevendor([...Vendor]);
  }, [selected]);

  //checking state for enable disable update button
  useEffect(() => {
    if (
      accountsState.selectedVendors.length > 0 &&
      !_.isEqual(accountsState.batchAmount, 0)
    ) {
      setState((prev) => ({ ...prev, isComplete: true }));
    } else {
      setState((prev) => ({ ...prev, isComplete: false }));
    }
  }, [accountsState]);
  const onClickUpdate = () => {
    let userId = getSessionStorageItem('UserId');
    let batchAmount = accountsState.batchAmount;

    let result = tableRef.current.api.getSelectedRows();
    var mapped = _.map(
      result,
      _.partialRight(_.pick, ['Partyid', 'requirement'])
    );
    let filterResult = _.filter(mapped, (o) => {
      return o.requirement > 0;
    });
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to this Batch?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          api.createBatch(
            (res) => {
              dispatch(hideLoader());
              dispatch(
                showAdvanceSnackbar({
                  msg: 'Batch Created sucessfully',
                  severity: 'success',
                  onclose: true,
                })
              );
              dispatch(CreatBatchSuccess());
              setSelected([]);
              setState({
                loading: false,
                params: '',
                BatchAmount: 0,
                isComplete: false,
              });
            },
            (err) => {
              dispatch(hideLoader());
              if (err.response) {
                if (err.response.status === statusCode.badRequest) {
                  clearAllSession();
                  history.replace('/accounts/authfail');
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: _.get(err.response.data, 'messege', err),
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Check network Connection',
                    severity: 'error',
                    onclose: true,
                  })
                );
              }
            },
            {
              userId: userId,
              batchAmount: batchAmount,
              selectedVendors: filterResult,
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };

  const deleteSelected = (chipToDelete) => {
    setSelected((prev) => prev.filter((data) => data.Id !== chipToDelete.Id));
    UpdateSelecteBatch(() =>
      accountsState.selectedVendors.filter(
        (data) => data.Partyid !== chipToDelete.Id
      )
    );
  };
  /* set pending values */
  const updateSelected = (pendingValue) => {
    setSelected(pendingValue);
  };
  const handleChange = (e) => {
    // const re = /^[0-9\b]+$/;

    // if value is not blank, then test the regex

    // if (e.target.value === '' || re.test(e.target.value)) {
    setState((prev) => ({ ...prev, BatchAmount: e.target.value }));
    // }
  };
  return (
    <div className={classes.rootContainer}>
      <Grid container>
        <Grid item md={6} xs={12}>
          <AutocompleteWithChip
            label='Select Vendors'
            description='Selected vendors will added to the bill'
            icon='add_business'
            options={options}
            loading={state.loading}
            setState={setState}
            deleteSelected={deleteSelected}
            updateSelected={updateSelected}
            selected={selected}
            noSelectedText='No vendor Selected'
            SectionHeight={150}
          />
        </Grid>
        <Grid container item md={6} spacing={2} xs={12}>
          <Grid container spacing={2} item xs={12}>
            <Grid container item xs={12} md={7}>
              <Grid item className={classes.batchContainer} xs={12} md={5}>
                <Typography className={classes.subHeading}>
                  BATCH AMOUNT :
                </Typography>
              </Grid>
              <Grid item xs={12} md={7}>
                <TextField
                  variant='outlined'
                  value={state.BatchAmount}
                  onChange={handleChange}
                  fullWidth
                  onKeyDown={(e) => {
                    if (
                      (e.keyCode >= 96 && e.keyCode <= 105) ||
                      e.keyCode == 8 ||
                      e.keyCode == 110 ||
                      (e.keyCode > 36 && e.keyCode <= 40)
                    ) {
                      return;
                    } else {
                      if (e.preventDefault) e.preventDefault();
                    }
                  }}
                  onBlur={(e) => {
                    if (_.isEmpty(e.target.value)) {
                      updateBatchAmount(parseInt(0));
                    } else {
                      updateBatchAmount(parseInt(e.target.value));
                    }
                  }}
                />
              </Grid>
            </Grid>
            <Grid item md={4} xs={12}>
              <Button
                size='large'
                variant='contained'
                color='primary'
                fullWidth
                disabled={!state.isComplete}
                onClick={onClickUpdate}
                startIcon={<Icon>cloud_upload</Icon>}
              >
                Update Batch
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};

BillForm.propTypes = {
  updatevendor: propTypes.func,
  updateBatchAmount: propTypes.func,
  accountsState: propTypes.object,
  updateBatchDetails: propTypes.func,
  UpdateSelecteBatch: propTypes.func,
};
const mapStateToProps = (state) => {
  return { accountsState: state.AccountsBatchReducer };
};
const mapDispatchToProps = (dispatch) => ({
  updatevendor: (vendors) => dispatch(BillActions.updatevendor(vendors)),
  updateBatchAmount: (value) => dispatch(BillActions.updateBatchAmount(value)),
  updateBatchDetails: (value) =>
    dispatch(BillActions.updateBatchDetails(value)),
  UpdateSelecteBatch: (value) =>
    dispatch(BillActions.updateBatchselected(value)),
  CreatBatchSuccess: () => dispatch(BillActions.createBatchSuccess),
});
export default connect(mapStateToProps, mapDispatchToProps)(BillForm);
