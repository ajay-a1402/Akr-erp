import React, { useEffect, useState, useRef } from 'react';
import propTypes from 'prop-types';
import { Box, withWidth, Typography, Snackbar, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import * as _ from 'lodash';
import Api from '../../../../../services/api';
import AgGridCustom from '../../../../../../../com_components/AgGridCustom';
import classnames from 'classnames';
import { connect, useDispatch } from 'react-redux';
import { API_ENDPOINTS, statusCode } from '../../../../../../../constants';
import customCellEditor from './customCellRender/customCellEditor';
import * as BillActions from '../../../../../services/api/actions';
import { showAdvanceSnackbar } from '../../../../../../../services/snackbarAdvance/actions';
import { clearAllSession } from '../../../../../../../services/sessionStorage';
import { isValidSting } from '../../../../../../../com_utils';
import { Alert } from '@material-ui/lab';
const useStyles = makeStyles((theme) => ({
  TableRoot: {
    '& .ag-cell-label-container': {
      /* Necessary to allow for text to grow vertically */
      height: '100%',
    },
    '& .ag-header-cell-label': {
      /* Necessary to allow for text to grow vertically */
      height: '100%',
      padding: '0 !important',
    },
    '& .ag-header-cell-label .ag-header-cell-text': {
      wordWrap: 'break-word',
    },
    padding: theme.spacing(0, 1),
    marginTop: theme.spacing(1),
  },
  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
  nameHeader: {
    paddingLeft: '0px !important',
  },
  nameCellStyle: {
    textAlign: 'left',
    '& .ag-header-cell-label': {
      /* Necessary to allow for text to grow vertically */
    },
  },
  TableAppBar: {
    display: 'flex',
    width: '100%',
    justifyContent: 'space-between',
    padding: theme.spacing(0, 2),
    alignItems: 'center',
  },
  tableHeading: {
    margin: theme.spacing(2, 0),
  },
  balAmountContainer: {
    backgroundColor: theme.palette.grey[200],
    padding: theme.spacing(1),
    width: '250px',
  },
  balAmountContainerError: {
    backgroundColor: theme.palette.error.main,
  },
  balAmountContainerWarning: {
    backgroundColor: theme.palette.warning.main,
  },
  resultContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  totalContainer: {
    marginRight: theme.spacing(5),
    padding: theme.spacing(1),
    width: '250px',
  },
  headerCell: {
    fontSize: '12px',
    backgroundColor: theme.palette.grey[100],
    padding: `${theme.spacing(0.5, 0.5)} !important`,
  },
}));
const BillTable = (props) => {
  const { width, billDetails, UpdateBatchselected, tableRef } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useDispatch();
  const [rowData, SetRowData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [rowEdited, setEditer] = useState({});
  const [Amount, setAmount] = useState({
    totalAmount: 0,
    BatchAmountRemain: 0,
  });
  const [SnackBarState, setSnackBar] = useState({
    severity: 'success',
    messege: '',
    state: false,
  });
  const handleClose = () => {
    setSnackBar({ severity: 'success', messege: '', state: false });
  };
  useEffect(() => {
    setEditer({});
    if (!_.isEmpty(billDetails?.vendorId)) {
      Api.fetchWithParams(
        API_ENDPOINTS.FETCH_VENDOR_BILLS,
        (res) => {
          SetRowData(res.data.data);
          setLoading(false);
        },
        (err) => {
          setLoading(false);
          if (err.response) {
            if (err.response.status === statusCode.badRequest) {
              clearAllSession();
              history.replace('/accounts/authfail');
            }
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'Check network Connection',
                severity: 'error',
                onclose: true,
              })
            );
          }
        },
        { search: _.join(billDetails.vendorId) }
      );
    } else {
      SetRowData([]);
      setAmount({
        totalAmount: 0,
        BatchAmountRemain: 0,
      });
    }
    // eslint-disable-next-line react/prop-types
  }, [billDetails.vendorId]);

  useEffect(() => {
    if (!_.isEmpty(rowEdited)) {
      let total = _.reduce(rowEdited, (result, value) => {
        return parseInt(result) + parseInt(value);
      });
      setAmount((prev) => ({ ...prev, totalAmount: total }));
    }
  }, [rowEdited]);

  useEffect(() => {
    setAmount((prev) => ({
      ...prev,
      BatchAmountRemain: _.get(billDetails, 'batchAmount', 0),
    }));

    // eslint-disable-next-line react/prop-types
  }, [billDetails.batchAmount]);
  useEffect(() => {
    return () => {
      UpdateBatchselected([]);
      setAmount({
        totalAmount: 0,
        BatchAmountRemain: 0,
      });
    };
  }, []);
  const valuegetter = (params) => {
    if (
      Amount.totalAmount <= billDetails.batchAmount &&
      params.newValue <= Amount.BatchAmountRemain - Amount.totalAmount
    ) {
      return (params.data.requirement = _.get(
        rowEdited,
        params.data.Partyid,
        0
      ));
    } else {
      return (params.data.requirement = _.get(
        rowEdited,
        params.data.Partyid,
        0
      ));
    }
  };

  /* get value from editable field in table and update values to the edited value array */
  const valueSetter = (params) => {
    // check wheather the input value exceed the bill balance of the selected vendor
    if (params.data.BillBalance >= parseFloat(params.newValue)) {
      /*check wheather total amount is lesser than batch amount 
      and input value should below the balance remain */
      isValidSting(params.newValue)
        ? setEditer((prev) => ({
            ...prev,
            [params.data.Partyid]: parseFloat(params.newValue),
          }))
        : setEditer((prev) => ({
            ...prev,
            [params.data.Partyid]: 0,
          }));
    } else {
      // dispatch(
      //   showAdvanceSnackbar({
      //     msg: 'Batch amount Exceed',
      //     severity: 'error',
      //     onclose: true,
      //   })
      // );
      setSnackBar({
        severity: 'error',
        messege: 'Batch amount Exceed',
        state: true,
      });
    }
  };

  const getTotalValue = (collection) => {
    return _.reduce(
      collection,
      (acc, value) => {
        return acc + parseFloat(value.requirement);
      },
      0
    );
  };
  const colDefs = [
    {
      field: 'Partyname',
      headerName: 'Party Name',
      headerClass: classnames(classes.nameHeader, classes.headerCell),
      headerTooltip: 'Party Name',
      tooltipField: 'Partyname',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      minWidth: 200,
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },
    {
      field: 'BillBalance',
      headerName: 'Bill Balance',
      headerTooltip: 'Bill Balance',
      minWidth: 120,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'BillPaidBalance',
      headerName: 'Bill Paid',
      headerTooltip: 'Bill Paid',
      minWidth: 120,
      cellClass: classes.staticCellStyle,
      headerClass: classnames(classes.headerCell),
    },
    {
      field: 'PreviousBatchBalance',
      headerName: 'Previous Batch Balance',
      headerTooltip: 'Previous Batch Balance',
      minWidth: 150,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'Below30',
      headerName: '> 30 days',
      headerTooltip: 'Payment Below 30 days',
      minWidth: 150,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'Days30to60',
      minWidth: 150,
      headerName: '30 To 60 days',
      headerTooltip: 'Payment between 30 to 60 days',
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'Days60to90',
      minWidth: 150,
      headerName: '60 to 90 days',
      headerTooltip: 'Payment between 60 to 90 days',
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'Above90',
      headerName: ' > 90 days',
      headerTooltip: 'Payment Above 90 days',
      cellEditor: 'customCellEditor',
      minWidth: 150,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'requirement',
      headerName: 'Party Requirement',
      headerTooltip: 'Party Requirement',
      minWidth: 200,
      editable: (params) => {
        return params.node.selected === true;
      },
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
      cellEditor: 'customCellEditor',
      valueSetter: valueSetter,
      valueGetter: valuegetter,
      onCellValueChanged: (props) => {
        let result = props.api.getSelectedRows();
        var mapped = _.map(
          result,
          _.partialRight(_.pick, ['Partyid', 'requirement'])
        );
        let filterResult = _.filter(mapped, (o) => {
          return o.requirement > 0;
        });
        UpdateBatchselected(filterResult);
      },
    },
  ];
  return (
    <div>
      <Grid container>
        <Grid item className={classes.TableAppBar}>
          <Typography variant='h5' className={classes.tableHeading}>
            {' '}
            Table
          </Typography>
        </Grid>
        <Grid item container spacing={1} xs={12}>
          <Grid item xs={12} md={6}>
            {/* className={classes.totalContainer} */}
            <Typography>
              Selected Total :{' '}
              <span>{getTotalValue(billDetails.selectedVendors)}</span>
            </Typography>
          </Grid>
          <Grid
            item
            xs={12}
            md={6}
            className={classnames(classes.balAmountContainer, {
              [classes.balAmountContainerError]:
                Amount.BatchAmountRemain - Amount.totalAmount < 0,
            })}
          >
            <Typography>
              Bal Amount :{' '}
              <span>
                {(Amount.BatchAmountRemain - Amount.totalAmount).toFixed(2)}
              </span>
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <div className={classnames(classes.TableRoot)}>
        <AgGridCustom
          getRef={tableRef}
          loading={loading}
          columnDefs={colDefs}
          rowData={rowData}
          height={500}
          defaultColDef={{
            initialWidth: 100,
            sortable: true,
            resizable: true,
          }}
          frameworkComponents={{ customCellEditor: customCellEditor }}
          rowHeight={_.isEqual(width, 'xs') ? 60 : 70}
          handleCellClick={() => {}}
          noDataTxt='No bills available'
          suppressRowClickSelection={true}
          rowSelection={'multiple'}
          enterMovesDown={true}
          enterMovesDownAfterEdit={true}
        />
      </div>
      <Snackbar open={SnackBarState.state} autoHideDuration={6000}>
        <Alert onClose={handleClose} severity={SnackBarState.severity}>
          {SnackBarState.messege}
        </Alert>
      </Snackbar>
    </div>
  );
};
BillTable.propTypes = {
  width: propTypes.string,
  billDetails: propTypes.object,
  updateBatchAmount: propTypes.func,
  updateBatchselected: propTypes.func,
};
const mapStateToProps = (state) => {
  return {
    billDetails: state.AccountsBatchReducer,
  };
};
const mapDispatchToProps = (dispatch) => ({
  UpdateBatchAmount: (value) => dispatch(BillActions.updateBatchAmount(value)),
  UpdateBatchselected: (value) =>
    dispatch(BillActions.updateBatchselected(value)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withWidth()(BillTable));
