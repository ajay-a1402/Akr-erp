import { Box, Grid, Toolbar, Typography } from '@material-ui/core';
import classNames from 'classnames';
import BillForm from './batchForm';
import BillTable from './BillTable';
import { makeStyles } from '@material-ui/core/styles';
import { useRef } from 'react';

const useStyles = makeStyles((theme) => ({
  rootContainer: {
    paddingLeft: theme.spacing(1),
  },
}));

const BatchCreate = () => {
  const classes = useStyles();
const tableRef = useRef()
  return (
    <Box className={classes.rootContainer}>
      <Grid container>
        <Grid item xs={12}>
          <BillForm tableRef={tableRef}/>
        </Grid>
        <Grid item xs={12}>
          <BillTable tableRef={tableRef}/>
        </Grid>
      </Grid>
      
    </Box>
  );
};
export default BatchCreate;
