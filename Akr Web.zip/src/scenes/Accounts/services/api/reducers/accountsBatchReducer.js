import { ACTION_TYPES } from '../../../../../constants';
const defaultState = {
  vendorId: null,
  batchAmount: 0,
  selectedVendors: [],
};

const AccountsBatchReducer = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.UPDATE_BILL_PARAMS: {
      return {
        ...state,
        vendorId: action.payload,
      };
    }
    case ACTION_TYPES.UPDATE_BATCH_AMOUNT: {
      return {
        ...state,
        batchAmount: action.payload,
      };
    }
    case ACTION_TYPES.UPDATE_BATCH_SELECTED: {
      return {
        ...state,
        selectedVendors: action.payload,
      };
    }
    case ACTION_TYPES.CREATE_BATCH_SUCCESS: {
      return {
        ...state,
        vendorId: null,
        batchAmount: 0,
        selectedVendors: [],
      };
    }
    default:
      return state;
  }
};
export default AccountsBatchReducer;
