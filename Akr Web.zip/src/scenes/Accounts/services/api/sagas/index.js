import { put, call, takeLatest } from 'redux-saga/effects';
import { SAGA_ACTION_TYPES, ACTION_TYPES } from '../../../../../constants';
import api from '../index';
import _ from 'lodash';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
import { clearAllSession } from '../../../../../services/sessionStorage';
export function* accountsBatchSaga(action) {
  try {
    yield put({
      type: ACTION_TYPES.SHOW_LOADER,
      data: { loaderTxt: 'Updating please Wait ...' },
    });
    const res = yield call(api.createBatch, { ...action.payload });
    yield put({
      type: ACTION_TYPES.HIDE_LOADER,
    });
    yield put(
      showAdvanceSnackbar({
        msg: _.get(res.data, 'messege'),
        severity: 'success',
        onclose: true,
      })
    );
  } catch (error) {
    yield put({
      type: ACTION_TYPES.HIDE_LOADER,
    });
    if (error.code === 'ECONNABORTED') {
      yield put(
        showAdvanceSnackbar({
          msg: `Response timeout ! check connection`,
          severity: 'error',
          onclose: true,
        })
      );
    } else {
      yield put(
        showAdvanceSnackbar({
          msg: _.get(error.response.data, 'messege', error),
          severity: 'error',
          onclose: true,
        })
      );
    }
  }
}
export function* accountsBillSaga(action) {
  try {
    yield put({
      type: ACTION_TYPES.SHOW_LOADER,
      data: { loaderTxt: 'Updating bills please Wait ...' },
    });
    const res = yield call(api.updateBatchWithBills(action.payload));
    yield put({
      type: ACTION_TYPES.HIDE_LOADER,
    });
    yield put(
      showAdvanceSnackbar({
        msg: _.get(res.data, 'messege'),
        severity: 'success',
        onclose: true,
      })
    );
  } catch (error) {
    yield put({
      type: ACTION_TYPES.HIDE_LOADER,
    });
    if (error.code === 'ECONNABORTED') {
      yield put(
        showAdvanceSnackbar({
          msg: `Response timeout ! check connection`,
          severity: 'error',
          onclose: true,
        })
      );
      if (error.response.status === 401) {
        clearAllSession();
        window.location.reload();
      }
    } else {
      yield put(
        showAdvanceSnackbar({
          msg: _.get(error.response.data, 'messege', error),
          severity: 'error',
          onclose: true,
        })
      );
    }
  }
}
export function* AccountsWatcher() {
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_UPDATE_BATCH, accountsBatchSaga);
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_BATCH_WITH_BILLS, accountsBillSaga);
}
