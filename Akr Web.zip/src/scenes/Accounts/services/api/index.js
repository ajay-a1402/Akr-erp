/* eslint-disable no-undef */
import Axios from 'axios';
import { API_ENDPOINTS } from '../../../../constants';
import { getSessionStorageItem } from '../../../../services/sessionStorage';
export default {
  fetchWithParams: (EndPoint, sucessCallback, errorCallback, params) => {
    Axios.get(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
      params: { ...params },
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  GetRequest: (EndPoint, sucessCallback, errorCallback) => {
    Axios.get(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  PostRequest: (EndPoint, sucessCallback, errorCallback, values) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`,
      values,
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  DeleteRequest: (EndPoint, sucessCallback, errorCallback, values) => {
    Axios.delete(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      data: { ...values },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  PutRequest: (EndPoint, sucessCallback, errorCallback, values) => {
    Axios.put(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, values, {
      headers: {
        Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  createBatch: (sucessCallback, errorCallback, payload) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.UPDATE_BATCHES}`,
      { ...payload },
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,

          'Content-Type': 'application/json',
        },
        timeout: 120000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },

  fetchBatchDetails: () => {
    return Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_BATCH_DETAILS}`,
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'Content-Type': 'application/json',
        },
        timeout: 120000,
      }
    );
  },

  fetchBankDetails: () => {
    return Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_BANK_DETAILS}`,
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'Content-Type': 'application/json',
        },
        timeout: 120000,
      }
    );
  },

  fetchBatchVendors: (batchenno) => {
    return Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.FETCH_BATCH_VENDORS}`,
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'content-Type': 'application/json',
        },
        params: { batch_enno: batchenno },
        timeout: 120000,
      }
    );
  },

  //updata Batch with bills
  updateBatchWithBills: (sucessCallback, errorCallback, payload) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.UPDATE_BILLS}`,
      { ...payload },
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'content-Type': 'application/json',
        },
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },

  updateBatchApproveStatus: (sucessCallback, errorCallback, values) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.UPDATE_APPROVE_STATUS}`,
      { ...values },
      {
        headers: {
          Authorization: `Bearer ${getSessionStorageItem('accounts-Auth')}`,
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  AuthLogin: (sucessCallback, errorCallback, values) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.AUTH_LOGIN_ACCOUNTS}`,
      { ...values },
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
};
