import { data } from 'browserslist';
import { SAGA_ACTION_TYPES, ACTION_TYPES } from '../../../../../constants';

export const updatevendor = (value) => {
  return {
    type: ACTION_TYPES.UPDATE_BILL_PARAMS,
    payload: value,
  };
};

export const updateAvailAmount = (value) => {
  return {
    type: ACTION_TYPES.UPDATE_BILLS_AVAIL_AMOUNT,
    payload: value,
  };
};

export const updateBatchAmount = (value) => {
  return {
    type: ACTION_TYPES.UPDATE_BATCH_AMOUNT,
    payload: value,
  };
};

export const updateBatchselected = (value) => {
  return {
    type: ACTION_TYPES.UPDATE_BATCH_SELECTED,
    payload: value,
  };
};

export const updateBatchDetails = (data) => {
  return {
    type: SAGA_ACTION_TYPES.SAGA_UPDATE_BATCH,
    payload: data,
  };
};

export const ChangeBatch = (data) => {
  return {
    type: ACTION_TYPES.CHANGE_BATCH,
    payload: data,
  };
};

// action for Bills page invoice list
export const updateBillsInvoices = (data) => {
  return {
    type: ACTION_TYPES.UPDATE_BILLS_INVOICE_LIST,
    payload: data,
  };
};

// action for review page invoice list
export const updateReviewInvoices = (data) => {
  return {
    type: ACTION_TYPES.UPDATE_REVIEW_INVOICE_LIST,
    payload: data,
  };
};

export const updateSelectedInvoice = (data) => {
  return {
    type: ACTION_TYPES.UPDATE_SELECTED_INVOICE,
    payload: data,
  };
};

export const updateBatchList = (data) => {
  return {
    type: ACTION_TYPES.UPDATE_BATCH_LIST,
    payload: data,
  };
};

export const updateBillsToServer = (data) => {
  return {
    type: SAGA_ACTION_TYPES.SAGA_BATCH_WITH_BILLS,
    payload: data,
  };
};

export const createBatchSuccess = () => {
  return {
    type: ACTION_TYPES.CREATE_BATCH_SUCCESS,
  };
};

export const updateSession = (data) => {
  return {
    type: ACTION_TYPES.UPDATE_ACCOUNTS_SESSION,
    payload: data,
  };
};
