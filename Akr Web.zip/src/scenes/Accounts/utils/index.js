import { getSessionStorageItem } from '../../../services/sessionStorage';

export const isLogin = () => {
  if (getSessionStorageItem('accounts-Auth')) {
    return true;
  }
  return false;
};
export const isGuest = () => {
  return false;
};
export const isMember = () => {
  return true;
};
export const isApprovar = () => {
  return false;
};
