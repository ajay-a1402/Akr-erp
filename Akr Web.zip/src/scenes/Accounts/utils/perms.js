//import { isMember } from '.';
import { useSelector } from 'react-redux';
import * as _ from 'lodash';
//import { useMemo } from 'react';
export const MODULE_PERMS = {
  SUPER_USER: [
    {
      label: 'Manage Users',
      icon: 'manage_accounts',
      link: '/accounts/usermanagement',
    },
  ],
  CREATE_BATCH: [
    {
      label: 'Create Batch',
      icon: 'note_add',
      link: '/accounts/bills/newBatch',
    },
  ],
  CREATE_BILLS: [
    {
      label: 'Invoice Update',
      icon: 'request_quote',
      link: '/accounts/bills/billAdd',
    },
  ],
  REVIEW_BILLS: [
    {
      label: 'Review Batch',
      icon: 'flaky',
      link: '/accounts/bills/billReview',
    },
  ],
};

export const getModulePerms = (module) => {
  const userDetails = useSelector((state) =>
    _.get(state.AccountsSessionReducer, 'userDetails', {})
  );
  const PermsState = () => {
    if (!_.isEmpty(userDetails)) {
      return _.isEqual(_.get(userDetails, module, 0), 1);
    } else {
      return false;
    }
};
return PermsState()
}
