import React, { useState } from 'react';
import {
  Grid,
  CardContent,
  Card,
  Typography,
  Toolbar,
  Box,
  Icon,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
//import { People, AvTimer as AvTimerIcon } from '@material-ui/icons';
import classNames from 'classnames';
import NavigationBar from '../../com_components/navigationBar';
import CustomDrawer from '../../com_components/Drawer';
import { Link } from 'react-router-dom';
const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({
  cardContent: {
    textAlign: 'center',
    backgroundColor: theme.palette.grey[400],
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    width: theme.spacing(25),
    [theme.breakpoints.down('md')]: {
      width: theme.spacing(15),
    },
    height: theme.spacing(15),
  },
  shiftContent: {
    marginLeft: drawerWidth,
  },
  cardLinks: {
    textDecoration: 'none',
  },
  Maincontainer: {
    paddingLeft: theme.spacing(10),

    [theme.breakpoints.down('md')]: {
      paddingLeft: theme.spacing(1),
    },
  },
}));
const Mainpage = () => {
  const classes = useStyles();
  const [drawer, setDrawer] = useState(false);
  const appbarOptions = [
    {
      label: 'Home',
      // icon: icon1,
      link: '/',
    },
  ];
  const drawerOptions = [
    {
      label: 'Slots Booking',
      icon: 'access_time',
      link: '/slotBooking/dashboard',
    },
    {
      label: 'User Management',
      icon: 'people',
      link: '/employeDetails/login',
    },
    {
      label: 'Accounts',
      icon: 'account_balance',
      link: '/accounts/home',
    },
  ];
  const GridOptions = [
    {
      label: 'Slots Booking',
      icon: 'access_time',
      link: '/slotBooking/dashboard',
    },
    {
      label: 'User Management',
      icon: 'people',
      link: '/employeDetails/login',
    },
    {
      label: 'Accounts',
      icon: 'account_balance',
      link: '/accounts/home',
    },
  ];
  return (
    <>
      <NavigationBar
        setDrawer={setDrawer}
        options={appbarOptions}
        session={{}}
      />{' '}
      <Toolbar />
      <Box
        className={classNames(classes.Maincontainer, {
          [classes.shiftContent]: drawer,
        })}
      >
        <Grid container spacing={2}>
          {GridOptions.map((option, idx) => (
            <Grid item key={idx}>
              <Link to={option.link} className={classes.cardLinks}>
                <Card>
                  <CardContent className={classes.cardContent}>
                    <Icon>{option.icon}</Icon>
                    <Typography variant='h6'>{option.label}</Typography>
                  </CardContent>
                </Card>
              </Link>
            </Grid>
          ))}
        </Grid>
      </Box>
      <CustomDrawer
        drawer={{ state: drawer, width: drawerWidth }}
        options={drawerOptions}
      />
    </>
  );
};

export default Mainpage;
Mainpage.propTypes = {};
