/* eslint-disable no-undef */
import Axios from 'axios';
import { API_ENDPOINTS } from '../../../../../constants';
export default {
  getEmp: (payload) => {
    return Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.GET_EMP}`,
      { ...payload },
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    );
  },
  saveSign: (payload, successCallback, errorCallback) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.SAVE_SIGN}`,
      { ...payload },
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        successCallback && successCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  getHrSign: (payload, successCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.GET_HR_SIGN}`,
      {
        headers: {
          Authorization: `Bearer ${payload.token}`,
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        params: { hr_id: payload.hr_id },
      }
    )
      .then((resp) => {
        successCallback && successCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
};
