import { ACTION_TYPES, SAGA_ACTION_TYPES } from '../../../../../constants';

export const userlogin = (userId, dataBase, password) => ({
  type: SAGA_ACTION_TYPES.SAGA_USER_LOGIN,
  payload: { userId: userId, dataBase: dataBase, password: password },
});
export const userlogout = () => ({
  type: SAGA_ACTION_TYPES.SAGA_USER_LOGOUT,
});
export const unauthError = () => ({
  type: ACTION_TYPES.USER_UNAUTH_ERROR,
});
