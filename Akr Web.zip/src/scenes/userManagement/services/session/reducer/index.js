import { ACTION_TYPES } from '../../../../../constants';
import * as localStorage from '../../../../../services/localStorage';

function addAuthDetailsToLocalStorage(authToken, userId, userName, section) {
  localStorage.setLocalStorageItem('spr_user_authToken', authToken);
  localStorage.setLocalStorageItem('spr_userId', userId);
  localStorage.setLocalStorageItem('spr_userName', userName);
  localStorage.setLocalStorageItem('spr_section', section);
}

function getDefaultState() {
  //FETCH ALL SESSION PROPERTIES FROM LOCAL STORAGE TO AFFECT STORE
  return {
    auth_token: localStorage.getLocalStorageItem('spr_user_authToken'),
    userId: localStorage.getLocalStorageItem('spr_userId'),
    isAuthenticated: !!localStorage.getLocalStorageItem('spr_user_authToken'),
    userName: localStorage.getLocalStorageItem('spr_userName'),
  };
}

const userSession = (state = getDefaultState(), action) => {
  switch (action.type) {
    case ACTION_TYPES.USER_LOGIN_SUCCESS: {
      addAuthDetailsToLocalStorage(
        action.payload.auth_token,
        action.payload.user_details.aEmpno,
        action.payload.user_details.EmployeeName,
        action.payload.user_section
      );
      return {
        ...state,
        auth_token: action.payload.auth_token,
        isAuthenticated: true,
        loading: false,
        spr_section: action.payload.user_section,
        userId: action.payload.user_details.aEmpno,
        userName: action.payload.user_details.EmployeeName,
        userDetails: action.payload.user_details,
      };
    }
    case ACTION_TYPES.USER_AUTH_LOGOUT: {
      localStorage.removeLocalStorageItem('spr_user_authToken');
      localStorage.removeLocalStorageItem('spr_userName');
      localStorage.removeLocalStorageItem('spr_userId');
      localStorage.removeLocalStorageItem('spr_section');
      return {
        ...state,
        auth_token: '',
        isAuthenticated: false,
        userId: '',
        userName: '',
      };
    }

    case ACTION_TYPES.USER_UNAUTH_ERROR: {
      //REMOVE EVERYTHING IN LOCAL STORAGE
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        authToken: '',
        error: { message: 'Session Timeout! Please signin again' },
        showLogOutError: false,
        userId: '',
        userName: '',
      };
    }
    case ACTION_TYPES.USER_SESSION_TIMEOUT: {
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        authToken: '',
        error: { message: 'Session Timeout! Please signin again' },
        showLogOutError: false,
        userId: '',
        userName: '',
      };
    }
    default:
      return state;
  }
};
export default userSession;
