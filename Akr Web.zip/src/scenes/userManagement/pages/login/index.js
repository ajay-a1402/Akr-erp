import React, { useEffect } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import {
  Typography,
  DialogContent,
  Dialog,
  DialogContentText,
  DialogActions,
  InputAdornment,
  IconButton,
  Container,
  Box,
  Grid,
  Link,
  MenuItem,
} from '@material-ui/core';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { makeStyles } from '@material-ui/core/styles';
import { Formik } from 'formik';
import { connect } from 'react-redux';
import * as Yup from 'yup';
import propTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import { userlogin } from '../../services/session/actions';
import { isMasterUserLogin } from '../../../../com_utils';
function Copyright() {
  return (
    <Typography variant='body2' color='textSecondary' align='center'>
      {'Copyright © '}
      <Link color='inherit' href='https://material-ui.com/'>
        ERP Dep AKR
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));
const validateSchema = Yup.object().shape({
  user_id: Yup.string().required('Required'),
  database: Yup.string().required('required'),
  password: Yup.string().required('Required'),
});
function SignIn(props) {
  const classes = useStyles();
  let history = useHistory();
  const [open, setOpen] = React.useState(false);
  const [viewPswd, setView] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleClickShowPassword = () => setView(!viewPswd);
  const handleMouseDownPassword = () => setView(!viewPswd);
  const redirectToHomeIfLoggedIn = () => {
    if (isMasterUserLogin()) {
      history.push('/employeDetails/main');
    }
  };
  useEffect(() => {
    redirectToHomeIfLoggedIn();
  }, [props.userSession]);
  return (
    <Container component='main' maxWidth='xs'>
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component='h1' variant='h5'>
          Sign in
        </Typography>
        <Formik
          initialValues={{
            user_id: '',
            database: '',
            password: '',
          }}
          onSubmit={(value) => {
            props.userlogin(value.user_id, value.database, value.password);
          }}
          validationSchema={validateSchema}
        >
          {({
            values,
            errors,
            handleChange,
            handleSubmit,

            /* and other goodies */
          }) => (
            <>
              <TextField
                variant='outlined'
                margin='normal'
                required
                fullWidth
                id='user_id'
                label='user Id '
                name='user_id'
                helperText={errors.user_id}
                autoComplete='email'
                onChange={handleChange}
                autoFocus
                error={Boolean(errors.user_id)}
              />
              <TextField
                fullWidth
                variant='outlined'
                margin='normal'
                select
                value={values.database}
                helperText={errors.database}
                name='database'
                label='database'
                onChange={handleChange}
                error={Boolean(errors.database)}
              >
                <MenuItem value='payroll'>payroll</MenuItem>
                <MenuItem value='payroll5'>payroll5</MenuItem>
                <MenuItem value='veeraCloth'>VeeraCloth</MenuItem>
              </TextField>
              <TextField
                variant='outlined'
                margin='normal'
                required
                fullWidth
                error={Boolean(errors.password)}
                helperText={errors.password}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      <IconButton
                        aria-label='toggle password visibility'
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {viewPswd ? <Visibility /> : <VisibilityOff />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                name='password'
                label='Password'
                type={viewPswd ? 'text' : 'password'}
                id='password'
                onChange={handleChange}
                autoComplete='password'
              />
              <Button
                type='submit'
                fullWidth
                variant='contained'
                color='primary'
                className={classes.submit}
                onClick={handleSubmit}
              >
                Sign In
              </Button>
            </>
          )}
        </Formik>
        <Grid container>
          <Grid item xs>
            <Link href='#' onClick={handleClickOpen} variant='body2'>
              Forgot password?
            </Link>
          </Grid>
        </Grid>
      </div>
      <Box mt={8}>
        <Copyright />
      </Box>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Mail to erp@akrind.com
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color='primary' autoFocus>
            close
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

const mapDispatchToProps = (dispatch) => ({
  userlogin: (username, dataBase, password) =>
    dispatch(userlogin(username, dataBase, password)),
});
const mapStateToProps = (state) => ({
  userSession: state.userSession,
});

export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
SignIn.propTypes = {
  userSession: propTypes.object,
  userlogin: propTypes.func,
};
