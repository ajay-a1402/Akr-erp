import React, { useState } from 'react';
import { Switch, Route, useRouteMatch } from 'react-router-dom';
import { Box, Toolbar } from '@material-ui/core';
import { connect } from 'react-redux';
import PrivateRoute from '../components/privateRoutes';
import EmployeDetails from './employesDetails';
import SignIn from './login';
import NavigationBar from '../../../com_components/navigationBar';
import CustomDrawer from '../../../com_components/Drawer';
import { ROLE_MODULES } from '../../../constants/module';
import { userlogout } from '../services/session/actions';
import { makeStyles } from '@material-ui/core/styles';
import propTypes from 'prop-types';
import classnames from 'classnames';
const drawerWidth = 190;
const useStyles = makeStyles((theme) => ({
  shiftContent: {
    marginLeft: drawerWidth,
  },
  mainContainer: {
    padding: theme.spacing(0, 2),
    marginLeft: theme.spacing(7) + 1,
  },
}));

const EmployeeAdmin = ({ logout, session }) => {
  const classes = useStyles();
  let { path } = useRouteMatch();
  const [drawer, setDrawer] = useState(false);

  const appbarOptions = [
    {
      label: 'Home',
      // icon: icon1,
      link: '/',
    },
  ];
  const drawerOptions = [
    // {
    //   label: 'Slots Booking',
    //   icon: 'access_time',
    //   link: '/slotBooking/dashboard',
    // },
  ];
  return (
    <div>
      <NavigationBar
        setDrawer={setDrawer}
        options={appbarOptions}
        logout={logout}
        session={session}
      />{' '}
      <Toolbar />
      <Box
        className={classnames(classes.mainContainer, {
          [classes.shiftContent]: drawer,
        })}
      >
        <Switch>
          <Route path={`/employeDetails/login`} component={SignIn} />
          <PrivateRoute
            exact
            path={path}
            component={userManagementMain}
            moduleName={ROLE_MODULES.USER_MANAGEMENT}
          />
        </Switch>
      </Box>
      <CustomDrawer
        drawer={{ state: drawer, width: drawerWidth }}
        options={drawerOptions}
      />
    </div>
  );
};
const userManagementMain = () => {
  return (
    <Switch>
      <Route exact path='/employeDetails/main' component={EmployeDetails} />
    </Switch>
  );
};
const mapDispatchToProps = (dispatch) => ({
  logout: () => dispatch(userlogout()),
});
const mapStateToProps = (state) => {
  return {
    session: state.userSession,
    empDetails: state.userManagementReducer,
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(EmployeeAdmin);
EmployeeAdmin.propTypes = {
  session: propTypes.object,
  empDetails: propTypes.object,
  logout: propTypes.func,
};
