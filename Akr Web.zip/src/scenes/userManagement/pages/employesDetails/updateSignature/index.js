import React, { useState } from 'react';
import {
  Button,
  Checkbox,
  FormControlLabel,
  Grid,
  TextField,
  Typography,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import propTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import * as _ from 'lodash';

import SignatureContainer from './SignaturePad';
import Api from '../../../../../services/apiServices';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
import {
  ACTION_TYPES,
  API_ENDPOINTS,
  statusCode,
} from '../../../../../constants';
import { getLocalStorageItem } from '../../../../../services/localStorage';
const useStyles = makeStyles((theme) => ({
  mainWrapper: {
    padding: `${theme.spacing(1)}px ${theme.spacing(4)}px ${theme.spacing(
      0
    )}px ${theme.spacing(4)}px`,
  },
  contentBox: {
    display: 'flex',
    paddingTop: theme.spacing(5),
    '& .Mui-disabled': {
      color: theme.palette.almostBlack[600],
    },
  },
  fieldLable: {
    width: '150px',
  },

  empTextfiled: {
    marginLeft: theme.spacing(1),
  },
  saveButton: {
    width: theme.spacing(25),
    float: 'right',
  },
}));
const UpdateSignature = ({ empDetails }) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [state, setState] = useState({
    isHr: false,
    trimmedDataURL: null,
    trimmedDataURL_hr: null,
  });

  const handleCheckbox = (e) => {
    setState((prev) => ({
      ...prev,
      isHr: e.target.checked,
    }));
  };
  const handleSaveSign = () => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to add this Signature to Employee Id : ${empDetails.AEmpno}?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          Api.PostRequest(
            API_ENDPOINTS.SAVE_SIGN,
            getLocalStorageItem('spr_user_authToken'),
            () => {
              dispatch(hideLoader());
              setState((prev) => ({
                ...prev,
                isHr: false,
                trimmedDataURL: null,
                trimmedDataURL_hr: null,
              }));
              dispatch(
                showAdvanceSnackbar({
                  msg: 'Sign SucessFully added',
                  severity: 'success',
                  onclose: true,
                })
              );
            },
            (err) => {
              if (err.code === 'ECONNABORTED') {
                dispatch(
                  showAdvanceSnackbar({
                    msg: `Response timeout ! check connection`,
                    severity: 'error',
                    onclose: true,
                  })
                );
                dispatch(hideLoader());
              } else {
                dispatch(hideLoader());
                if (err?.response.status === statusCode.Unauthorized) {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: `${err.response.data.messege}`,
                      severity: 'error',
                      onclose: true,
                    })
                  );
                  localStorage.removeItem('spr_user_authToken');
                  setState((prev) => ({
                    ...prev,
                    isHr: false,
                    trimmedDataURL: null,
                    trimmedDataURL_hr: null,
                  }));
                  dispatch({ type: ACTION_TYPES.USER_UNAUTH_ERROR });
                  dispatch({ type: ACTION_TYPES.GET_EMP_FAILURE });
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: 'Something went wrong. Please try again!',
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              }
            },
            {
              empId: empDetails.AEmpno,
              trimmedData: state.trimmedDataURL,
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };

  return (
    <>
      <Grid container>
        <Grid item container md={5} style={{ display: 'flex' }}>
          <Grid item sm={12}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={state.isHr}
                  onChange={handleCheckbox}
                  color='primary'
                />
              }
              label='Is HR'
            />
          </Grid>

          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Name</Typography>
            <TextField
              disabled
              fullWidth
              value={_.get(empDetails, 'EmployeeName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>

          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Department</Typography>
            <TextField
              multiline
              disabled
              fullWidth
              value={_.get(empDetails, 'DepartmentName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>

          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Designation</Typography>
            <TextField
              disabled
              multiline
              fullWidth
              value={_.get(empDetails, 'Designationname', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>
          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Unit</Typography>
            <TextField
              disabled
              multiline
              fullWidth
              value={_.get(empDetails, 'UnitName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>
        </Grid>
        <Grid item md={7}>
          <SignatureContainer setState={setState} state={state} />
        </Grid>
        <Grid item xs={12}>
          <Button
            variant='contained'
            color='primary'
            className={classes.saveButton}
            disabled={
              !_.isEmpty(state.trimmedDataURL) &&
              !_.isEmpty(empDetails.AEmpno) &&
              (state.isHr || !_.isEmpty(state.trimmedDataURL_hr))
                ? false
                : true
            }
            onClick={handleSaveSign}
          >
            save
          </Button>
        </Grid>
      </Grid>
    </>
  );
};
UpdateSignature.propTypes = {
  empDetails: propTypes.object,
};
export default UpdateSignature;
