import React, { useState } from 'react';
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Divider,
  Grid,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';

import { connect } from 'react-redux';
import _ from 'lodash';
import { getEmp } from '../../services/api/actions';
import api from '../../services/api/userProfile';
import { useDispatch } from 'react-redux';
import { ACTION_TYPES } from '../../../../constants';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../services/snackbarAdvance/actions';
import propTypes from 'prop-types';
import SignatureContainer from './Signature';
const useStyles = makeStyles((theme) => ({
  mainWrapper: {
    padding: `${theme.spacing(1)}px ${theme.spacing(4)}px ${theme.spacing(
      0
    )}px ${theme.spacing(4)}px`,
  },
  contentBox: {
    display: 'flex',
    paddingTop: theme.spacing(5),
    '& .Mui-disabled': {
      color: theme.palette.almostBlack[600],
    },
  },
  fieldLable: {
    width: '150px',
  },

  empTextfiled: {
    marginLeft: theme.spacing(1),
  },
}));

const EmployeDetails = ({ getEmp, session, empDetails }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [state, setState] = useState({
    formError: false,
    userId: '',
    isHr: false,
    trimmedDataURL: null,
    trimmedDataURL_hr: null,
  });

  const handleChange = (e) => {
    setState((prev) => ({
      ...prev,
      userId: e.target.value,
    }));
  };

  const handleGet = () => {
    if (!_.isEmpty(state.userId)) {
      setState((prev) => ({
        ...prev,
        formError: false,
      }));
      getEmp(state.userId, session.auth_token);
    } else {
      setState((prev) => ({
        ...prev,
        formError: true,
      }));
    }
  };

  const handleSaveSign = () => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to add this Signature to Employee Id : ${empDetails.emp_id}?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          api.saveSign(
            {
              empId: empDetails.emp_id,
              trimmedData: state.trimmedDataURL,
              token: session.auth_token,
              hr_id: session.userId,
            },
            () => {
              dispatch(hideLoader());
              dispatch(
                showAdvanceSnackbar({
                  msg: 'Sign SucessFully added',
                  severity: 'success',
                  onclose: true,
                })
              );
            },
            (err) => {
              if (err.code === 'ECONNABORTED') {
                dispatch(
                  showAdvanceSnackbar({
                    msg: `Response timeout ! check connection`,
                    severity: 'error',
                    onclose: true,
                  })
                );
                dispatch(hideLoader());
              } else {
                dispatch(hideLoader());
                if (err?.response.status === 401) {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: `${err.response.data.messege}`,
                      severity: 'error',
                      onclose: true,
                    })
                  );
                  localStorage.removeItem('spr_user_authToken');
                  setState((prev) => ({
                    ...prev,
                    formError: false,
                    userId: '',
                    trimmedDataURL: null,
                    trimmedDataURL_hr: null,
                  }));
                  dispatch({ type: ACTION_TYPES.USER_UNAUTH_ERROR });
                  dispatch({ type: ACTION_TYPES.GET_EMP_FAILURE });
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: 'Something went wrong. Please try again!',
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              }
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };
  const handleCheckbox = (e) => {
    setState((prev) => ({
      ...prev,
      isHr: e.target.checked,
    }));
  };
  return (
    <Box className={classes.mainWrapper}>
      <Grid container spacing={2}>
        <Grid item container spacing={2}>
          <Grid item className={classes.contentBox} xs={12} md={4}>
            <Box
              style={{
                display: 'flex',
                justifyContent: 'center',
                textAlign: 'center',
              }}
            >
              <Typography className={classes.fieldLable}>
                Employee No:
              </Typography>
              <TextField
                variant='outlined'
                fullWidth
                onChange={handleChange}
                className={classes.empTextfiled}
                error={state.formError}
                helperText={state.formError && 'Required'}
              />
            </Box>
          </Grid>
          <Grid item xs={12} md={2}>
            <Button variant='contained' fullWidth onClick={handleGet}>
              Get Details
            </Button>
          </Grid>
          <Grid item xs={12} md={2}>
            <Button
              variant='contained'
              fullWidth
              color='primary'
              disabled={
                !_.isEmpty(state.trimmedDataURL) &&
                !_.isEmpty(empDetails.emp_id) &&
                (state.isHr || !_.isEmpty(state.trimmedDataURL_hr))
                  ? false
                  : true
              }
              onClick={handleSaveSign}
            >
              save
            </Button>
          </Grid>
        </Grid>
        <Grid item container xs={12}>
          <Divider style={{ width: 'inherit' }} />
          <Grid item container md={5} style={{ display: 'flex' }}>
            <Grid item sm={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={state.isHr}
                    onChange={handleCheckbox}
                    color='primary'
                  />
                }
                label='Is HR'
              />
            </Grid>
            <Grid item sm={12} className={classes.contentBox}>
              <Typography className={classes.fieldLable}>Name</Typography>
              <TextField
                disabled
                fullWidth
                value={_.get(empDetails, 'emp_name', '')}
                InputProps={{ disableUnderline: true }}
              />
            </Grid>

            <Grid item sm={12} className={classes.contentBox}>
              <Typography className={classes.fieldLable}>Department</Typography>
              <TextField
                multiline
                disabled
                fullWidth
                value={_.get(empDetails, 'emp_dep', '')}
                InputProps={{ disableUnderline: true }}
              />
            </Grid>

            <Grid item sm={12} className={classes.contentBox}>
              <Typography className={classes.fieldLable}>
                Designation
              </Typography>
              <TextField
                disabled
                multiline
                fullWidth
                value={_.get(empDetails, 'emp_des', '')}
                InputProps={{ disableUnderline: true }}
              />
            </Grid>
            <Grid item sm={12} className={classes.contentBox}>
              <Typography className={classes.fieldLable}>Unit</Typography>
              <TextField
                disabled
                multiline
                fullWidth
                value={_.get(empDetails, 'emp_unit', '')}
                InputProps={{ disableUnderline: true }}
              />
            </Grid>
          </Grid>
          <Grid item md={7}>
            <SignatureContainer setState={setState} state={state} />
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};
const mapDispatchToProps = (dispatch) => ({
  getEmp: (userId, Token) => dispatch(getEmp(userId, Token)),
});
const mapStateToProps = (state) => {
  return {
    session: state.userSession,
    empDetails: state.userManagementReducer,
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(EmployeDetails);
EmployeDetails.propTypes = {
  getEmp: propTypes.func,
  getHrSign: propTypes.func,
  session: propTypes.object,
  empDetails: propTypes.object,
};
