export const isMasterUserLogin = () => {
  if (localStorage.getItem('spr_user_authToken')) {
    return true;
  }
  return false;
};
