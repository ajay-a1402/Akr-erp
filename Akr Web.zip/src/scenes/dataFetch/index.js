import React, {
  useEffect,
  useState,
  
  createRef,
} from 'react';
import { Typography, Box } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import api from '../../services/apiServices';
//import AgGridCustom from '../../com_components/AgGridCustom';
//import { API_ENDPOINTS } from '../../constants';
import * as _ from 'lodash';
//import FullCalendar from '@fullcalendar/react'; // must go before plugins
//import dayGridPlugin from '@fullcalendar/daygrid'; // a plugin!
import {withResizeDetector } from 'react-resize-detector';
import { Calendar, momentLocalizer, Views } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';

import moment from 'moment';

//import globalize from 'globalize';

//import { ViewState } from '@devexpress/dx-react-scheduler';

import {
  Scheduler,
  MonthView,
  Toolbar,
  DateNavigator,
  Appointments,
  TodayButton,
  WeekView,
  ViewSwitcher,
} from '@devexpress/dx-react-scheduler-material-ui';

// must manually import the stylesheets for each plugin
// import '@fullcalendar/core/main.css';
// import '@fullcalendar/daygrid/main.css';
// import '@fullcalendar/timegrid/main.css';
const useStyles = makeStyles((theme) => ({
  calanderContainer: {
    // maxHeight: '100vH',
    // '& .fc-daygrid-event': {
    //   whiteSpace: 'pre-line !important',
    // },
  },
  eventTiles: {
    wordWrap: 'break-word',
  },
  eventContainer: {
    backgroundColor: theme.palette.grey[200],
  },
}));
let allViews = Object.keys(Views).map((k) => Views[k]);
const localizer = momentLocalizer(moment);
function DataFetch(props) {
  const [rowdata, setRowData] = useState([]);
  const [state, setState] = useState(props);
  const calendarEl = createRef();
  const classes = useStyles();
  const { width, height } = props;

  useEffect(() => {
    api.GetRequest(
      '/getdata/cal_data',
      (res) => {
        console.log(res);
        setRowData(res.data.data);
      },
      (err) => {
        console.log(err);
      }
    );
  }, []);
  const eventContentRenderer = (arg) => {
    console.log('arg', arg);
    return (
      <Box className={classes.eventContainer}>
        <Typography className={classes.eventTiles}>
          {_.get(arg, 'event._def.title')}
        </Typography>
        <Typography>
          {_.get(arg, 'event._def.extendedProps.description')}
        </Typography>
      </Box>
    );
  };
  return (
    <div>
      <Box className={classes.calanderContainer}>
        {/* <FullCalendar
          ref={calendarEl}
          class
          height={height}
          defaultView='dayGridMonth'
          events={rowdata}
          plugins={[dayGridPlugin]}
          eventContent={eventContentRenderer}
          // ref={CalendarRef}
          initialView='dayGridMonth'
        /> */}
        <Calendar
          style={{ height: '100Vh' }}
          showMultiDayTimes
          localizer={localizer}
          events={rowdata}
          views={allViews}
          step={60}
        />
      </Box>
    </div>
  );
}
export default withResizeDetector(DataFetch);
