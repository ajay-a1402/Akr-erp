import UserManagementControl from '../../controller/userManagement/managementController';
import UserManagementSession from '../../controller/userManagement/sessionController';
export class UserRoutes {
  public userManagementSession: UserManagementSession =
    new UserManagementSession();
  public userManagementControl: UserManagementControl =
    new UserManagementControl();
  public PayrollRoutes(app): void {
    app.route('/api/Spruser/login').post(this.userManagementSession.login);

    app
      .route('/api/Spruser/getUser')
      .post(this.userManagementControl.getUserDetails);
    app
      .route('/api/Spruser/saveSign')
      .post(this.userManagementControl.saveSignature);

    app
      .route('/api/Spruser/getHrSign')
      .get(this.userManagementControl.getHrSignature);
  }
}
