// import UserManagementControl from '../../controller/userManagement/managementController';
// import UserManagementSession from '../../controller/userManagement/sessionController';
import userManagementRoutes from "../../controller/humanResource/userManagement/EmployeeProfile/routes";
import hrSessionRoutes from "../../controller/humanResource/sessionController/routes";
import { CommonBusinessService } from "../../utils/business";
export class HrRoutes {
  public commonBusinessService: CommonBusinessService =
    new CommonBusinessService();
  public HrRoutes(app): void {
    app.use(
      "/api/hr/userManagent",
      this.commonBusinessService.auth,
      userManagementRoutes
    );
    app.use("/api/hr/session", hrSessionRoutes);
  }
}
