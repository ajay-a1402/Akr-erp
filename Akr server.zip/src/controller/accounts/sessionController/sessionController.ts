import { config } from '../../../config/config.json';
import { Request, Response } from 'express';
import DB from '../../../database/sql_db/db_connection_factory';
import logger from '../../../utils/logger/logger';
import { CommonBusinessService } from '../../../utils/business';
import * as moment from 'moment';
import * as bcrypt from 'bcryptjs';
import * as _ from 'lodash';
export default class AccountsSessionController {
  public async AuthLogin(req: Request, res: Response) {
    try {
      const user_id = req.body.user_id;
      const password = req.body.password;
      var salt = bcrypt.genSaltSync(9);
      // var hash = bcrypt.hashSync('B4c0//', salt);
      let commonBussiness = new CommonBusinessService();

      let connection = new DB();
      const getUser = `select a.PermApprov1,a.PermApprov2,a.PermBatch,a.pswd,a.PermBills,a.PermDel,a.SuperUser,b.EmployeeId,b.EmployeeName from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  PayrollEmpno='${user_id}' and a.sts=1`;
      let result = await connection.ERP_db(getUser);
      if (result.recordset.length > 0) {
        if (bcrypt.compareSync(password, result.recordset[0].pswd)) {
          let token = commonBussiness.generateAuthToken({
            UserId: result.recordset[0].EmployeeId,
            UserName: result.recordset[0].EmployeeName,
          });

          res.status(config.statusCode.successful).json({
            messege: 'Login Success',
            status: 'success',
            data: _.omit(result.recordset[0], ['pswd']),
            auth_token: token,
          });
        } else {
          res.status(config.statusCode.Forbidden).json({
            status: 'fail',
            messege: 'Wrong Password',
          });
        }
      } else {
        res.status(config.statusCode.Forbidden).json({
          status: 'fail',
          messege: 'Invalid User Id',
        });
      }
    } catch (err) {
      console.log('Accounts-login-error:', err);
      logger.error(`Accounts-login-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async GetUser(req: MutatedRequest, res: Response) {
    try {
      let userId = req.user.foo.UserId;

      let connection = new DB();

      const getUser = `select a.PermApprov1,a.PermApprov2,a.PermBatch,a.PermBills,a.PermDel,a.SuperUser,b.EmployeeCode,b.EmployeeName from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  b.EmployeeId='${userId}' and a.sts=1`;
      let result = await connection.ERP_db(getUser);

      if (result.recordset.length > 0) {
        res.status(config.statusCode.successful).json({
          messege: 'Success',
          status: 'success',
          data: result.recordset[0],
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'No user found',
          status: 'success',
          data: [],
        });
      }
    } catch (err) {
      console.log('Accounts-getUser-error:', err);
      logger.error(`Accounts-getUser-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
interface MutatedRequest extends Request {
  user: any;
}
