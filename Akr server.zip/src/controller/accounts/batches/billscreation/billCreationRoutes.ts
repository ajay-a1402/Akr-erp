import BillCreationController from './billCreation';
import { Router } from 'express';

class BillCreationRoutes {
  private billCreationController = new BillCreationController();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get(
      '/getbatchDetails',
      this.billCreationController.getBatchdetails
    );

    this.router.get(
      '/getBankDetails',
      this.billCreationController.getBankDetails
    );

    this.router.get(
      '/getbatchedVendors',
      this.billCreationController.getbatchvendors
    );

    this.router.get(
      '/getbatchedVendors',
      this.billCreationController.getbatchvendors
    );

    this.router.get(
      '/getinvoice',
      this.billCreationController.getInvoiceDetails
    );

    this.router.post(
      '/updateBillDetails',
      this.billCreationController.updateBillDetails
    );
    this.router.post(
      '/createAllotment',
      this.billCreationController.createAllotment
    );
    this.router.post(
      '/UpdateAllotment',
      this.billCreationController.UpdateAllotment
    );
  }
}

const billCreationRoutes = new BillCreationRoutes();
billCreationRoutes.init();
export default billCreationRoutes.router;
