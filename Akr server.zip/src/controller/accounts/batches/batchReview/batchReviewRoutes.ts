import BatchReviewController from './batchReviewController';
import { Router } from 'express';

class BatchReviewRoutes {
  private batchReviewController = new BatchReviewController();
  router: Router;
  constructor() {
    this.router = Router();
    this.init();
  }
  init() {
    this.router.get(
      '/getBatchInvoice',
      this.batchReviewController.getBatchInvoiceDetails
    );
    this.router.get('/getBatches', this.batchReviewController.getBatchdetails);
    this.router.post(
      '/updateApproveStatus',
      this.batchReviewController.updateApprove
    );
  }
}

const batchReviewRoutes = new BatchReviewRoutes();
batchReviewRoutes.init();
export default batchReviewRoutes.router;
