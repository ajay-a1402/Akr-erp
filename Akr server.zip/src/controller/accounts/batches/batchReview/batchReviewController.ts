import { Request, Response } from 'express';
import { config } from '../../../../config/config.json';
import DB from '../../../../database/sql_db/db_connection_factory';
import logger from '../../../../utils/logger/logger';
import moment = require('moment');
import * as _ from 'lodash';
import { CommonBusinessService } from '../../../../utils/business';
interface MutatedRequest extends Request {
  user: any;
}
const staticQuery = {
  fetchBatchesQuery:
    'select A.*,B.EmployeeName,c.FundAvailable,d.OurAccName,d.OurBankName ,c.app1flag,c.app2flag from TablePayBatchMain A inner join MasterEmployee B on A.UserId = B.EmployeeId left join TablePayAllotMain c on c.PayBatchEnno = a.PayBatchEnno inner join MasterOurPayBank d on d.Bankid=c.OurBankId where a.delFlag=0',
};
export default class BatchReviewController {
  public async getBatchdetails(req: Request, res: Response) {
    try {
      let connection = new DB();

      const getBatchesQuery = staticQuery.fetchBatchesQuery;

      let result = await connection.ERP_db(getBatchesQuery);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: 'sucessfully fetched',
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'no records found',
          data: [],
        });
      }
    } catch (err) {
      console.log('Accounts-vendorList-error:', err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async getBatchInvoiceDetails(req: Request, res: Response) {
    try {
      let connection = new DB();
      let PayAllotSubEnno = req.query.PayAllotSubEnno;
      const getInvoiceQuery = `select * from TablePayAllotSubBill A inner join ForPayBillBalSum b on b.Bno=a.Bno and b.Billgroupno=a.BillGroupno  inner join masterpartySub c on b.partyid = c.PartyId where a.PayAllotSubEnno=${PayAllotSubEnno}`;
      let result = await connection.ERP_db(getInvoiceQuery);
      if (result.rowsAffected[0] > 0) {
        res.status(config.statusCode.successful).json({
          data: result.recordset,
          messege: 'sucessfully fetched',
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'no records found',
        });
      }
    } catch (err) {
      console.log('Accounts-review-InvoiceList-error:', err);
      logger.error(`Accounts-review-InvoiceList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async updateApprove(req: MutatedRequest, res: Response) {
    try {
      let connection = new DB();
      let PayBatchEnno = req.body.PayBatchEnno;
      let userId = req.user.foo.UserId;
      let status = req.body.status;
      let statusApproveQuery: string = '';
      const getUser = `select PermApprov1,PermApprov2 from TableAccWebUserMain  where  EmployeeId='${userId}'`;
      let getUserResult = await connection.ERP_db(getUser);
      if (getUserResult.recordset.length > 0) {
        if (_.get(getUserResult.recordset[0], 'PermApprov1', 0)) {
          statusApproveQuery = ` update TablePayAllotMain set app1by =${userId},app1dt=GETDATE() ,app1flag=${status} where PayBatchEnno=${PayBatchEnno}`;
        } else if (_.get(getUserResult.recordset[0], 'PermApprov2', 0)) {
          statusApproveQuery = ` update TablePayAllotMain set app2by =${userId},app2dt=GETDATE() ,app2flag=${status} where PayBatchEnno=${PayBatchEnno}`;
        } else {
          res.status(config.statusCode.successful).json({
            data: [],
            status: 'fail',
            messege: 'user does not have permission',
          });
        }
        let statusUpdateResult = await connection.ERP_db(statusApproveQuery);
        if (statusUpdateResult.rowsAffected[0] > 0) {
          const getBatchesQuery = staticQuery.fetchBatchesQuery;
          let getBatchResult = await connection.ERP_db(getBatchesQuery);
          if (getBatchResult.rowsAffected[0] > 0) {
            res.status(config.statusCode.successful).json({
              data: getBatchResult.recordset,
              messege: 'sucessfully fetched',
            });
          } else {
            res.status(config.statusCode.successful).json({
              messege: 'no records found',
              data: [],
            });
          }
        } else {
          res.status(config.statusCode.successful).json({
            messege: 'Status update failed',
          });
        }
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'Status update failed',
        });
      }
    } catch (err) {
      console.log('Accounts-review-Approve-error:', err);
      logger.error(`Accounts-review-Approve-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
