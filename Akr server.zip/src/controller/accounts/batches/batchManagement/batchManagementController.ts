import { Request, Response } from 'express';
import * as jwt from 'jsonwebtoken';
import * as _ from 'lodash';

import DB from '../../../../database/sql_db/db_connection_factory';
import { ENV } from '../../../../config/config.json';
import { config } from '../../../../config/config.json';
import { CommonBusinessService } from '../../../../utils/business';
import logger from '../../../../utils/logger/logger';
import { createImage, getImageData } from '../../../../utils/saveimage';
import * as fs from 'fs';
import commonValidationService from '../../../../utils/validations';

export default class BatchManagementContoller {
  public async getVendorList(req: Request, res: Response) {
    let KEY = req.query.search;
    try {
      let connection = new DB();

      let getVendorQuery = `select A.Partyid as Id,B.PartyName as Label from ForPayBillBalSumSlabWise  A inner join masterpartySub B on A.partyid = B.PartyId where PartyName like '%${KEY}%'`;

      let result: any = await connection.ERP_db(getVendorQuery);
      if (result.rowsAffected > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: 'sucessfully fetched' });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: '', messege: 'No records found' });
      }
    } catch (err) {
      console.log('Accounts-vendorList-error:', err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async getVendorsWithPayments(req: Request, res: Response) {
    let KEY_ARRAY: any = req.query.search;
    try {
      let connection = new DB();

      let commonBusinessService = new CommonBusinessService();

      let getVendorBillQuery = `Select A.Partyid,A.BillAmount,A.BillBalance,A.BillPaidBalance,A.PreviousBatchBalance,A.Below30,A.Days30to60,A.Days60to90,A.Above90
      ,B.Partyname,B.AccNo,B.AccName,B.BankName,B.Branch,B.IFSCode from ForPayBillBalSumSlabWise A inner join masterpartySub B on A.Partyid=B.Partyid where A.Partyid in (${KEY_ARRAY})`;

      let result: any = await connection.ERP_db(getVendorBillQuery);
      if (result.rowsAffected > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: 'sucessfully fetched' });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: '', messege: 'No records found' });
      }
    } catch (err) {
      console.log('Accounts-paymentList-error:', err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async createPayBatch(req: Request, res: Response) {
    try {
      let connection = new DB();
      let userId = req.body.userId;
      let BatchAmount: Number = req.body.batchAmount;
      let selectedVendors = req.body.selectedVendors;
      const isValidUser = commonValidationService.checkValue(userId);
      if (isValidUser) {
        let insertBatchQuery = `exec stp_updatebills @userId=${userId} ,@batchAmount=${BatchAmount}`;
        let result: any = await connection.ERP_db(insertBatchQuery);
        if (result.rowsAffected[0] > 0) {
          if (result.recordset[0].PayBatchEnno) {
            let values = _.reduce(
              selectedVendors,
              (o, a) => {
                let ini = [];
                ini.push(result.recordset[0].PayBatchEnno);
                ini.push(a.Partyid);
                ini.push(a.requirement);
                o.push(ini);
                return o;
              },
              []
            );
            let updateBatchQuery = `INSERT INTO TablePayBatchSub(PayBatchEnno,Partyid,ReqAmount) VALUES ${values

              .map((i) => '(' + i + ')')
              .join()}`;

            let updateResult: any = await connection.ERP_db(updateBatchQuery);
            if (updateResult.rowsAffected[0] > 0) {
              res.status(config.statusCode.successful).json({
                messege: 'sucessfully Updated',
              });
            } else {
              res.status(config.statusCode.badRequest).json({
                messege: 'Update Failed',
              });
            }
          }
        } else {
          res
            .status(config.statusCode.empty)
            .json({ data: '', messege: 'No records found' });
        }
      } else {
        res
          .status(config.statusCode.badRequest)
          .json({ messege: 'Invalid Fields' });
      }
    } catch (err) {
      console.log('Accounts-updatePaymentDetails-error:', err);
      logger.error(`Accounts-updatePaymentDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async deletePayBatch(req: MutatedRequest, res: Response) {
    try {
      let connection = new DB();
      let PayBatchEnno = req.body.PayBatchEnno;
      let userId = req.user.foo.UserId;
      const deleteBatchQuery = `update TablePayBatchMain set delFlag=1 ,delby=${userId} where PayBatchEnno=${PayBatchEnno}`;
      let deleteResult: any = await connection.ERP_db(deleteBatchQuery);
      if (deleteResult.rowsAffected[0] > 0) {
        const getBatchesQuery = `select A.*,B.EmployeeName,c.FundAvailable,c.OurBankName,c.OurAccName ,c.app1flag,c.app2flag from TablePayBatchMain A inner join MasterEmployee B on A.UserId = B.EmployeeId left join TablePayAllotMain c on c.PayBatchEnno = a.PayBatchEnno where a.delFlag=0 `;
        let getBatchResult: any = await connection.ERP_db(getBatchesQuery);
        if (getBatchResult.rowsAffected[0] > 0) {
          res.status(config.statusCode.successful).json({
            data: getBatchResult.recordset,
            messege: 'sucessfully deleted',
          });
        } else {
          res.status(config.statusCode.empty).json({
            messege: 'no records found',
            data: [],
          });
        }
      } else {
        res
          .status(config.statusCode.empty)
          .json({ data: '', messege: 'No batches to delete' });
      }
    } catch (err) {
      console.log('Accounts-Batch-del-error:', err);
      logger.error(`Accounts-vendorList-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
interface MutatedRequest extends Request {
  user: any;
}
