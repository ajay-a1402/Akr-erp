import { Request, Response } from 'express';
import { config } from '../../../../config/config.json';
import logger from '../../../../utils/logger/logger';
import * as _ from 'lodash';
import * as bcrypt from 'bcryptjs';
import DB from '../../../../database/sql_db/db_connection_factory';
export default class UsersContoller {
  public async searchUser(req: Request, res: Response) {
    try {
      let KEY = req.query.key;
      let connection = new DB();

      let searchUSerQuery = `select PayrollEmpno,EmployeeName,EmployeeId from MasterEmployee where (EmployeeName like '%${KEY}%' or PayrollEmpno like '%${KEY}%') and PayrollEmpno !='' and EmpStatus ='LIVE' and EmployeeId Not in (select EmployeeId from TableAccWebUserMain)`;
      let result = await connection.ERP_db(searchUSerQuery);
      if (result.recordset.length > 0) {
        res.status(config.statusCode.successful).json({
          messege: 'Success',
          status: 'success',
          data: result.recordset,
        });
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'No user found',
          status: 'success',
          data: [],
        });
      }
    } catch (err) {
      console.error('Accounts-search-user-error:', err);
      logger.error(`Accounts-search-user-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async addUser(req: Request, res: Response) {
    try {
      let connection = new DB();
      var salt = bcrypt.genSaltSync(9);

      const users = _.get(req.body, 'users', []);
      if (users.length > 0) {
        await Promise.all(
          req.body.users.map(async (user) => {
            var hash = bcrypt.hashSync(`${user.PayrollEmpno}`, salt);
            let addUserQuery = `Insert into TableAccWebUserMain (EmployeeId,PermBatch,PermBills,PermApprov1,PermApprov2,PermDel,sts,SuperUser,pswd) values(${user.EmployeeId},0,0,0,0,0,1,0,'${hash}')`;
            const host = await connection.ERP_db(addUserQuery);
          })
        )
          .then(async () => {
            const getUser = `select a.UserEnno,a.PermApprov1,a.PermApprov2,a.PermBatch,a.PermBills,a.PermDel,a.SuperUser,b.PayrollEmpno,b.EmployeeName from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  a.sts=1`;
            const result = await connection.ERP_db(getUser);
            if (result.recordset.length > 0) {
              res.status(config.statusCode.successful).json({
                status: 'success',
                messege: 'successfully added',
                data: result.recordset,
              });
            } else {
              res.status(config.statusCode.empty).json({
                status: 'fail',
                messege: 'User not found',
              });
            }
          })
          .catch((err) => {
            console.error('Accounts-user-Add-error', err);
            logger.error(`Accounts-user-Add-error : ${err.stack}`);
            res.status(config.statusCode.internalServer).json({
              messege: 'Internal server Error',
              status: 'failure',
            });
          });
      } else {
        res.status(config.statusCode.successful).json({
          messege: 'No users to add',
        });
      }
    } catch (err) {
      console.error('Accounts-Add-user-error:', err);
      logger.error(`Accounts-add-user-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async delUser(req: Request, res: Response) {
    try {
      let connection = new DB();
      const user: User = req.body.user;
      let delUSerQuery = `update TableAccWebUserMain set sts=0 where UserEnno=${user.UserEnno}`;
      let result = await connection.ERP_db(delUSerQuery);
      if (result.rowsAffected > 0) {
        const getUser = `select a.UserEnno,a.PermApprov1,a.PermApprov2,a.PermBatch,a.PermBills,a.PermDel,a.SuperUser,b.PayrollEmpno,b.EmployeeName from TableAccWebUserMain a inner join MasterEmployee b on a.EmployeeId = b.EmployeeId where  a.sts=1`;
        let userResult = await connection.ERP_db(getUser);
        if (userResult.recordset.length > 0) {
          res.status(config.statusCode.successful).json({
            status: 'success',
            messege: 'successfully user deleted!',
            data: userResult.recordset,
          });
        } else {
          res.status(config.statusCode.empty).json({
            status: 'fail',
            messege: 'Users not found',
          });
        }
      } else {
        res.status(config.statusCode.empty).json({
          status: 'fail',
          messege: 'User not found',
        });
      }
    } catch (err) {
      console.log('Accounts-del-user-error:', err);
      logger.error(`Accounts-del-user-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
interface User {
  UserEnno: number;
  PermApprov1: number;
  PermApprov2: number;
  PermBatch: number;
  PermBills: number;
  PermDel: number;
  SuperUser: number;
  EmployeeCode: number;
  EmployeeName: string;
}
