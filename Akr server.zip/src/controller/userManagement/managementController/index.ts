import { Request, Response } from 'express';
import * as jwt from 'jsonwebtoken';
import DB from '../../../database/sql_db/db_connection_factory';
import { ENV } from '../../../config/config.json';
import { config } from '../../../config/config.json';
import { CommonBusinessService } from '../../../utils/business';
import logger from '../../../utils/logger/logger';
import { createImage, getImageData } from '../../../utils/saveimage';
import * as fs from 'fs';
export default class UserManagementControl {
  public async getUserDetails(req: Request, res: Response) {
    let user_db = req.body.USR_DB;
    let emp_id = req.body.EMP_ID;
    let user_token = req.body.token;
    let commonBusinessService = new CommonBusinessService();

    try {
      let connection = new DB();
      let token_data = await commonBusinessService.verifyAuthToken(user_token);
      let getUserQuery = '';
      if (token_data) {
        if (token_data.user_db === 'veeraCloth') {
          getUserQuery = `select EmployeeName,DepartmentName,Designationname ,Empno as AEmpno,UnitName  from masteremployee A 
          inner join MasterDepartment B on a.DepartmentId=b.DepartmentID  
          inner join masterdesignation C on a.DesignationId=c.Designationid 
          inner join MasterUnit D on a.UnitId=D.UnitID  where Empno=${emp_id} AND A.delflag=0`;
        } else {
          getUserQuery = `select EmployeeName,DepartmentName,Designationname ,AEmpno,UnitName  from masteremployee A 
                                  inner join MasterDepartment B on a.DepartmentId=b.DepartmentID  
                                  inner join masterdesignation C on a.DesignationId=c.Designationid 
                                  inner join MasterUnit D on a.UnitId=D.UnitID  where AEmpno=${emp_id} AND A.delflag=0`;
        }
        const result = await connection.user_db(
          getUserQuery,
          token_data.user_db
        );
        if (result.rowsAffected[0] > 0) {
          res.status(config.statusCode.successful).json({
            data: {
              user: result.recordsets[0],
            },
            messege: 'Sucessfully fetched',
          });
        } else {
          res.status(config.statusCode.successful).json({
            data: {},
            messege: 'No User Found',
          });
        }
      } else {
        res.status(config.statusCode.Unauthorized).json({
          messege: 'Session time out',
        });
      }
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async saveSignature(req: Request, res: Response) {
    let commonBusinessService = new CommonBusinessService();
    let user_token = req.body.token;
    let emp_id = req.body.empId;
    let hr_id = req.body.hr_id;
    let user_sign = req.body.trimmedData;
    try {
      let connection = new DB();
      let token_data = await commonBusinessService.verifyAuthToken(user_token);
      if (token_data) {
        createImage(user_sign, emp_id).then(async (img_data: any) => {
          const insertSignQuery = `exec stp_addSignature '${emp_id}',0x${img_data},'${hr_id}'`;
          await connection.user_db_procedure(
            insertSignQuery,
            token_data.user_db,
            (data) => {
              if (data.rowsAffected.length > 0) {
                res
                  .status(config.statusCode.successful)
                  .json({ messege: 'Signature updated' });
              }
            }
          );
        });
      } else {
        res.status(config.statusCode.Unauthorized).json({
          messege: 'Session time out',
        });
      }
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }

  public async getHrSignature(req: Request, res: Response) {
    let commonBusinessService = new CommonBusinessService();
    let user_token = req.header('authorization');
    const bearer = user_token.split(' ');
    const bearerToken = bearer[1];
    let token = bearerToken;
    let hr_id = req.query.hr_id;
    try {
      let connection = new DB();
      let token_data = await commonBusinessService.verifyAuthToken(token);
      let getHrSignQuery = '';
      if (token_data) {
        if (token_data.user_db === 'veeraCloth') {
          getHrSignQuery = `select EmpSign from TableSignatureMain where Empno=${hr_id} And delFlag=0`;
        } else {
          getHrSignQuery = `select EmpSign from TableSignatureMain where AEmpno=${hr_id} And delFlag=0`;
        }
        const result = await connection.user_db(
          getHrSignQuery,
          token_data.user_db
        );
        if (result.rowsAffected[0] > 0) {
          let imageUrl = getImageData(result.recordsets[0]);
          res.status(config.statusCode.successful).json({
            data: {
              hr_image: imageUrl,
            },
            messege: 'Sucessfully fetched',
          });
        } else {
          res.status(config.statusCode.successful).json({
            data: {},
            messege: 'No record Found',
          });
        }
      } else {
        res.status(config.statusCode.Unauthorized).json({
          messege: 'Session time out',
        });
      }
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
