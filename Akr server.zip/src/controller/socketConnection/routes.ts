// import UserManagementControl from "./controller";
// import { Router } from "express";

// class UserMangementRoutes {
//   private userManagementController = new UserManagementControl();
//   router: Router;
//   constructor() {
//     this.router = Router();
//     this.init();
//   }
//   init() {
//     this.router.get("/getUser", this.userManagementController.getUserDetails);
//     this.router.post("/saveSign", this.userManagementController.saveSignature);
//     this.router.post("/saveImg", this.userManagementController.saveEmpImg);
//     this.router.get("/getHrSign", this.userManagementController.getHrSignature);
//   }
// }

// const userMangementRoutes = new UserMangementRoutes();
// userMangementRoutes.init();
// export default userMangementRoutes.router;
