import { Request, Response } from 'express';
import * as sql from 'mssql';
import { ENV } from '../../../config/config.json';
import { config } from '../../../config/config.json';
import { CommonBusinessService } from '../../../utils/business';
import DB from '../../../database/sql_db/db_connection_factory';
import logger from '../../../utils/logger/logger';
import * as _ from 'lodash';
export default class UserManagementSession {
  public async login(req: Request, res: Response) {
    let user_db = req.body.USR_DB;
    let user_id = req.body.USER_ID;
    let user_pswd = req.body.USR_PSWD;
    let commonBussiness = new CommonBusinessService();

    const sqlConfig = {
      user: ENV.DB_PAYROLL_USER,
      password: ENV.DB_PAYROLL_PASS,
      database: user_db,
      server: ENV.DB_PAYROLL_HOST,
      options: {
        trustedConnection: true,
        encrypt: true,
        enableArithAbort: true,
        trustServerCertificate: true,
      },
    };
    try {
      let connection = new DB();
      let getUserQuery = ``;
      if (user_db === 'veeraCloth') {
        getUserQuery = `select a.*,b.Empid,b.EmployeeName,b.Empno as aEmpno,b.Empno from MasterUser a inner join MasterEmployee b on a.UserCode= b.Empno Where b.Empno=${user_id} AND a.Category='C' `;
      } else if (user_db === 'payroll') {
        getUserQuery = `select a.*,b.Empid,b.aEmpno,b.EmployeeName,b.Empno from MasterUser a inner join MasterEmployee b on a.UserCode= b.AEmpno Where b.AEmpno=${user_id} AND a.Category='C'`;
      } else {
        getUserQuery = `select a.*,b.Empid,b.aEmpno,b.EmployeeName,b.Empno from MasterUser a inner join MasterEmployee b on a.UserCode= b.AEmpno Where b.AEmpno=${user_id} AND a.Category='C' `;
      }
      const result = await connection.user_db(getUserQuery, user_db);
      if (result.rowsAffected[0] === 0) {
        res.status(config.statusCode.successful).json({
          data: {},
          messege: 'invalid user Id',
        });
      } else {
        if (result.recordset[0].PassWord === user_pswd) {
          let token = commonBussiness.generateAuthToken({
            user_id: user_id,
            user_db: user_db,
          });

          res.status(config.statusCode.successful).json({
            messege: 'Sucessfully logged-in',
            data: {
              userDetails: _.omit(result.recordset[0], [
                'PassWord',
                'Category',
                'Admin',
                'delflag',
              ]),
              auth_token: token,
              section: user_db,
            },
          });
        } else {
          res.status(config.statusCode.successful).json({
            messege: 'incorrect password',
          });
        }
      }
    } catch (err) {
      console.log('error:', err);
      logger.error(`getDetails-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async logOut(req: Request, res: Response) {}
}
