import { Request, Response } from 'express';
import * as jwt from 'jsonwebtoken';
import * as _ from 'lodash';
import DB from '../../database/sql_db/db_connection_factory';
import { ENV } from '../../config/config.json';
import { config } from '../../config/config.json';
import logger from '../../utils/logger/logger';

export default class DataFetchContoller {
  public async getData(req: Request, res: Response) {
    let KEY = req.query.search;
    try {
      let connection = new DB();

      //   let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let result: any = await connection.ERP_db(getDataQuery);
      console.log('result', result);
      if (result.rowsAffected.length > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: 'sucessfully fetched' });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: '', messege: 'No records found' });
      }
    } catch (err) {
      console.log('Fetch-data-error:', err);
      logger.error(`Fetch-data-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
  public async getCalanderData(req: Request, res: Response) {
    try {
      let connection = new DB();

      //   let getDataQuery = `select * from ForTablePrdMultidatereport`;
      let getDataQuery = `select CAST(Expiry AS date) as start,CONCAT(Unit,' - ',Points) as title from forCheckListsubHR where Close_Enno is null`;
      let result: any = await connection.ERP_db(getDataQuery);

      if (result.rowsAffected.length > 0) {
        res
          .status(config.statusCode.successful)
          .json({ data: result.recordset, messege: 'sucessfully fetched' });
      } else {
        res
          .status(config.statusCode.successful)
          .json({ data: '', messege: 'No records found' });
      }
    } catch (err) {
      console.log('Fetch-cal-data-error:', err);
      logger.error(`Fetch-cal-data-error : ${err.stack}`);
      res
        .status(config.statusCode.internalServer)
        .json({ messege: 'Internal server Error' });
    }
  }
}
interface MutatedRequest extends Request {
  user: any;
}
