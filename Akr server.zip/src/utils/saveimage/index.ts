import * as fs from 'fs';
import * as path from 'path';
import { ENV } from '../../config/config.json';
import { Buffer } from 'buffer';
let dir = ENV.LOG_DIR;

if (!dir) dir = path.resolve('logs');

// create directory if it is not present
if (!fs.existsSync(dir)) {
  // Create the directory if it does not exist
  fs.mkdirSync(dir);
}
export const createImage = async (trimmedUrl, emp_id: String) => {
  let base64String = trimmedUrl.replace(/^data:image\/\w+;base64,/, '');
  //convert to binary
  var buf = Buffer.from(base64String, 'base64');
  fs.writeFileSync(dir + `/${emp_id}.jpg`, buf);

  var readStream = fs.createReadStream(dir + `/${emp_id}.jpg`);
  return new Promise((resolve, reject) => {
    const data = [];

    readStream.on('data', (chunk) => {
      data.push(chunk.toString('hex'));
    });

    readStream.on('end', () => {
      fs.unlink(`${dir}/${emp_id}.jpg`, function (err) {
        if (err) return console.log(err);
      });
      resolve(data.join(''));
    });

    readStream.on('error', (err) => {
      reject(err);
    });
  });
};
export const getImageData = (buffer) => {
  let buf = Buffer.from(buffer[0].EmpSign, 'binary');
  var base64data = buf.toString('base64');
  return `data:image/jpg;base64,${base64data}`;
};
