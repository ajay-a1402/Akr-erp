import * as jwt from 'jsonwebtoken';
import * as moment from 'moment';
import { config, ENV } from '../../config/config.json';
class CommonValidationService {
  public checkValue(value: any) {
    if (value === undefined || value === null || value === '') return false;
    else return true;
  }
}
const commonValidationService = new CommonValidationService();

export default commonValidationService;
