import * as jwt from 'jsonwebtoken';
import * as moment from 'moment';
import { config, ENV } from '../../config/config.json';
class CommonBusinessService {
  public generateAuthToken(key: any) {
    const token = jwt.sign({ foo: key }, ENV.LOGIN_SECRET_KEY, {
      expiresIn: '2h',
    });
    return token;
  }
  public verifyAuthToken(token: any) {
    try {
      const data = jwt.verify(token, ENV.LOGIN_SECRET_KEY);
      return data.foo;
    } catch (err) {
      console.log(err.messege);
      return false;
    }
  }

  public auth(req, res, next) {
    try {
      const user_token = req.header('authorization');
      const bearer = user_token.split(' ');
      const bearerToken = bearer[1];
      if (!bearerToken) {
        return res
          .status(config.statusCode.Unauthorized)
          .send('Access denied.');
      } else {
        const decoded = jwt.verify(bearerToken, ENV.LOGIN_SECRET_KEY);
        req.user = decoded;
        next();
      }
    } catch (err) {
            res
        .status(config.statusCode.timeOut)
        .send({ message: 'Time out session expired' });
    }
  }

  public convertUTCtoGmt(dateString) {
    try {
      let t =
        !!dateString &&
        moment(dateString, 'YYYY-MM-DD HH:mm:ss Z')
          .utc()
          .format('ddd, DD MMM YYYY HH:mm:ss [GMT]');
      return t;
    } catch (err) {
      console.log(err.messege);
      return false;
    }
  }
}

export { CommonBusinessService };
