import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as compression from 'compression';
import path = require('path');
import * as cors from 'cors';
import * as swaggerUi from 'swagger-ui-express';
import { AppRoutes } from './routes/slotBookingRoutes/index';
import { UserRoutes } from './routes/usersManagement';
import { AccountsRoutes } from './routes/AccountsManagement';
import { WishRoutes } from './routes/WishesRoutes';
import dataFetchRoutes from './controller/dataFetch/dataFetchRoutes';
import * as fs from 'fs';
import { CommonBusinessService } from 'utils/business';
export class App {
  public routesprev: AppRoutes = new AppRoutes();
  public userRoutesprev: UserRoutes = new UserRoutes();
  public accountsRoutesPrev: AccountsRoutes = new AccountsRoutes();
  public wishRoutesPrev: WishRoutes = new WishRoutes();
  public app: express.Application;
  /* Swagger files start */
  private swaggerFile: any = process.cwd() + '/swagger/swagger.json';
  private swaggerData: any = fs.readFileSync(this.swaggerFile, 'utf8');
  private customCss: any = fs.readFileSync(
    process.cwd() + '/swagger/swagger.css',
    'utf8'
  );
  private swaggerDocument = JSON.parse(this.swaggerData);
  /* Swagger files end */
  private config(): void {
    this.app.use(bodyParser.json());
    this.app.use(cors());
    this.app.use(compression());
    this.app.use(bodyParser.urlencoded({ extended: false }));
    this.app.use(express.static(path.join(__dirname, 'public')));
    this.app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Expose-Headers', 'x-total-count');
      res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH');
      res.header('Access-Control-Allow-Headers', 'Content-Type,authorization');
      next();
    });
    this.app.use(
      '/api/docs',
      swaggerUi.serve,
      swaggerUi.setup(this.swaggerDocument, null, null, this.customCss)
    );
    this.app.use('/getdata', dataFetchRoutes);
  }
  constructor() {
    this.app = express();
    this.config();
    this.routesprev.SlotRoutes(this.app);
    this.userRoutesprev.PayrollRoutes(this.app);
    this.accountsRoutesPrev.AccountsRoutes(this.app);
    this.wishRoutesPrev.WishRoutes(this.app);
  }
}
