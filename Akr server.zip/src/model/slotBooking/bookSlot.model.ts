export interface bookSlotDetail {
  colour: string;
  Process: string;
  Qty: number;
  Date: string;
  vessel: string;
}
