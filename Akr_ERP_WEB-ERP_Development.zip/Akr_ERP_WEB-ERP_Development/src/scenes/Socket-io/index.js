import { Box, Typography } from "@material-ui/core";
import { useEffect, useState } from "react";
import socketClient from "socket.io-client";
import { getSessionStorageItem } from "../../services/sessionStorage";
const ChatBox = () => {
  const [connectUsers, setConnectUsers] = useState([]);
  const socketConfig = () => {
    // eslint-disable-next-line no-undef
    var socket = socketClient(process.env.REACT_APP_BACKEND_API_PROXY, {
      extraHeaders: {
        Authorization: `Bearer ${getSessionStorageItem("accounts-Auth")}`,
      },
    });
    socket.emit("messege:new", { msg: "hi" });
    socket.on("user-connected", (args) => {
      console.log(args);
      setConnectUsers((prev) => {
        let newarray = prev;
        newarray.push(args);
        return newarray;
      });
    });
  };
  useEffect(() => {
    socketConfig();
  }, []);
  return (
    <Box>
      <Typography>Chat Screen</Typography>
    </Box>
  );
};
export default ChatBox;
