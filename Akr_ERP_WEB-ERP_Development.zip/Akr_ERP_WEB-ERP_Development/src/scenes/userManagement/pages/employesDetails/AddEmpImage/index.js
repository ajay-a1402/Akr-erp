import React, { useCallback, useEffect, useState } from 'react';
import {
  Button,
  Grid,
  Icon,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import * as _ from 'lodash';
import Webcam from 'react-webcam';
import propTypes from 'prop-types';

import Api from '../../../../../services/apiServices';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
import { ACTION_TYPES, API_ENDPOINTS } from '../../../../../constants';
import { getLocalStorageItem } from '../../../../../services/localStorage';

const useStyles = makeStyles((theme) => ({
  mainWrapper: {
    padding: `${theme.spacing(1)}px ${theme.spacing(4)}px ${theme.spacing(
      0
    )}px ${theme.spacing(4)}px`,
    [theme.breakpoints.down('md')]: {
      padding: theme.spacing(2),
    },
  },
  contentBox: {
    display: 'flex',
    paddingTop: theme.spacing(5),
    '& .Mui-disabled': {
      color: theme.palette.almostBlack[600],
    },
  },
  fieldLable: {
    width: '150px',
  },
  ButtonWrapper: {
    display: 'flex',

    justifyContent: 'center',
    [theme.breakpoints.down('md')]: {
      margin: theme.spacing(1),
    },
  },
  captureButton: {},
  empTextfiled: {
    marginLeft: theme.spacing(1),
  },
  saveButton: {
    [theme.breakpoints.up('md')]: {
      width: theme.spacing(25),
    },
    float: 'right',
  },
}));
const UpdateImage = ({ empDetails }) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const webcamRef = React.useRef(null);
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  const [imageData, setImage] = useState(null);
  const [state, setState] = useState({
    trimmedDataURL: null,
  });
  useEffect(() => {
    if (empDetails) {
      setImage(_.get(empDetails, 'EmpImg', ''));
    }
  }, [empDetails]);

  const handleSaveImage = () => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to add this image to Employee Id : ${empDetails.emp_id}?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          Api.PostRequest(
            API_ENDPOINTS.SAVE_EMP_IMG,
            getLocalStorageItem('spr_user_authToken'),
            () => {
              dispatch(hideLoader());
              setState((prev) => ({
                ...prev,
                isHr: false,
              }));
              setImage(null);
              dispatch(
                showAdvanceSnackbar({
                  msg: 'Sign SucessFully added',
                  severity: 'success',
                  onclose: true,
                })
              );
            },
            (err) => {
              if (err.code === 'ECONNABORTED') {
                dispatch(
                  showAdvanceSnackbar({
                    msg: `Response timeout ! check connection`,
                    severity: 'error',
                    onclose: true,
                  })
                );
                dispatch(hideLoader());
              } else {
                dispatch(hideLoader());
                if (err?.response.status === 401) {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: `${err.response.data.messege}`,
                      severity: 'error',
                      onclose: true,
                    })
                  );
                  localStorage.removeItem('spr_user_authToken');
                  setState((prev) => ({
                    ...prev,
                    isHr: false,
                  }));
                  setImage(null);
                  dispatch({ type: ACTION_TYPES.USER_UNAUTH_ERROR });
                  dispatch({ type: ACTION_TYPES.GET_EMP_FAILURE });
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: 'Something went wrong. Please try again!',
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              }
            },
            {
              empId: empDetails.AEmpno,
              trimmedData: imageData,
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };

  const videoConstraints = {
    width: 720,
    height: 720,
    facingMode: 'Selfie',
  };
  const capture = useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot({
      width: 750,
      height: 750,
    });
    setImage(imageSrc);
  }, [webcamRef, setImage]);
  return (
    <>
      <Grid container>
        <Grid item container md={5} style={{ display: 'flex' }}>
          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Name</Typography>
            <TextField
              disabled
              fullWidth
              value={_.get(empDetails, 'EmployeeName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>

          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Department</Typography>
            <TextField
              multiline
              disabled
              fullWidth
              value={_.get(empDetails, 'DepartmentName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>

          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Designation</Typography>
            <TextField
              disabled
              multiline
              fullWidth
              value={_.get(empDetails, 'Designationname', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>
          <Grid item sm={12} className={classes.contentBox}>
            <Typography className={classes.fieldLable}>Unit</Typography>
            <TextField
              disabled
              multiline
              fullWidth
              value={_.get(empDetails, 'UnitName', '')}
              InputProps={{ disableUnderline: true }}
            />
          </Grid>
        </Grid>
        <Grid item container md={7}>
          <Grid item xs={12} className={classes.ButtonWrapper}>
            <>
              <Button
                className={classes.captureButton}
                onClick={capture}
                color='secondary'
                fullWidth={isBelowMd && true}
                startIcon={<Icon>add_a_photo</Icon>}
              >
                Capture
              </Button>
            </>
          </Grid>
          <Grid item xs={12} container>
            <Grid item>
              <Webcam
                audio={false}
                height={isBelowMd ? 300 : 400}
                ref={webcamRef}
                screenshotFormat='image/jpg'
                width={isBelowMd ? 300 : 400}
                videoConstraints={videoConstraints}
              />
            </Grid>
            <Grid item>
              {
                <img
                  src={imageData}
                  height={isBelowMd ? 300 : 400}
                  width={isBelowMd ? 300 : 400}
                />
              }
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Button
            variant='contained'
            color='primary'
            fullWidth={isBelowMd && true}
            className={classes.saveButton}
            disabled={
              !_.isEmpty(imageData) &&
              !_.isEmpty(empDetails.AEmpno) &&
              (state.isHr || !_.isEmpty(imageData))
                ? false
                : true
            }
            onClick={handleSaveImage}
          >
            save
          </Button>
        </Grid>
      </Grid>
    </>
  );
};

UpdateImage.propTypes = {
  empDetails: propTypes.object,
};
export default UpdateImage;
