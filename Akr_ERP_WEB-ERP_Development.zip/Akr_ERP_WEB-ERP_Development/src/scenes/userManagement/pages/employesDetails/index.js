/* eslint-disable no-undef */
import React, { useState } from 'react';
import {
  Box,
  Button,
  Divider,
  Grid,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';

import { connect } from 'react-redux';
import _ from 'lodash';
import { getEmp } from '../../services/api/actions';
import Api from '../../../../services/apiServices';
import { useDispatch } from 'react-redux';
import { API_ENDPOINTS, statusCode } from '../../../../constants';
import { hideLoader, showLoader } from '../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../services/snackbarAdvance/actions';
import propTypes from 'prop-types';
import ScrollableTabsButtonAuto from '../../../../com_components/TabBar';
import UpdateSignature from './updateSignature';
import {
  getLocalStorageItem,
  removeLocalStorageItem,
} from '../../../../services/localStorage';
import UpdateImage from './AddEmpImage';
import { useHistory } from 'react-router-dom';
const useStyles = makeStyles((theme) => ({
  mainWrapper: {
    padding: `${theme.spacing(1)}px ${theme.spacing(4)}px ${theme.spacing(
      0
    )}px ${theme.spacing(4)}px`,
  },
  contentBox: {
    display: 'flex',
    paddingTop: theme.spacing(5),
    '& .Mui-disabled': {
      color: theme.palette.almostBlack[600],
    },
  },
  fieldLable: {
    width: '150px',
  },

  empTextfiled: {
    marginLeft: theme.spacing(1),
  },
}));

const EmployeDetails = ({ session }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const [state, setState] = useState({
    formError: false,
    userId: '',
    empDetails: {},
  });
  const handleChange = (e) => {
    setState((prev) => ({
      ...prev,
      userId: e.target.value,
    }));
  };
  const clearLocalStorage = () => {
    removeLocalStorageItem('spr_user_details');
    removeLocalStorageItem('spr_user_authToken');
    removeLocalStorageItem('spr_section');
    removeLocalStorageItem('spr_userId');
  };
  const handleGet = () => {
    dispatch(showLoader('Fetching User details Please Wait...'));
    if (!_.isEmpty(state.userId)) {
      setState((prev) => ({
        ...prev,
        formError: false,
      }));
      Api.fetchWithParams(
        API_ENDPOINTS.GET_EMP,
        getLocalStorageItem('spr_user_authToken'),
        (res) => {
          dispatch(hideLoader());
          if (res.status !== 204) {
            setState((prev) => ({
              ...prev,
              empDetails: res.data.data[0],
            }));
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'No user Found',
                severity: 'warning',
                onclose: true,
              })
            );
          }
        },
        (err) => {
          dispatch(hideLoader());
          if (err.response) {
            if (err.response.status === statusCode.Unauthorized) {
              clearLocalStorage();
              history.replace('/employeDetails/login');
            } else {
              dispatch(
                showAdvanceSnackbar({
                  msg: _.get(err.response.data, 'messege', err),
                  severity: 'error',
                  onclose: true,
                })
              );
            }
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: 'Check network Connection',
                severity: 'error',
                onclose: true,
              })
            );
          }
        },
        { key: state.userId }
      );
    } else {
      setState((prev) => ({
        ...prev,
        formError: true,
      }));
    }
  };

  const taboptions = [
    {
      id: 'updateSign',
      label: 'UpdateSign',
      tabPanel: UpdateSignature,
    },
    {
      id: 'updateImage',
      label: 'update Image',
      tabPanel: UpdateImage,
    },
  ];
  return (
    <Box className={classes.mainWrapper}>
      <Grid container spacing={2}>
        <Grid item container spacing={2}>
          <Grid item container className={classes.contentBox} xs={12} md={4}>
            <Grid item xs={12} md={4}>
              <Typography className={classes.fieldLable}>
                Employee No:
              </Typography>
            </Grid>
            <Grid item xs={12} md={8}>
              <TextField
                variant='outlined'
                fullWidth
                onChange={handleChange}
                className={classes.empTextfiled}
                error={!state.userId}
                onKeyDown={(e) => {
                  if (
                    (e.keyCode >= 96 && e.keyCode <= 105) ||
                    e.keyCode == 8 ||
                    e.keyCode == 110 ||
                    (e.keyCode > 36 && e.keyCode <= 40)
                  ) {
                    return;
                  } else {
                    if (e.preventDefault) e.preventDefault();
                  }
                }}
                helperText={!state.userId && 'Required'}
              />
            </Grid>
          </Grid>
          <Grid item xs={12} md={2}>
            <Button
              variant='contained'
              fullWidth
              onClick={handleGet}
              disabled={!state.userId}
            >
              Get Details
            </Button>
          </Grid>
        </Grid>
        <Grid item container xs={12}>
          <Divider style={{ width: 'inherit' }} />
          <ScrollableTabsButtonAuto
            options={taboptions}
            defaultTabId={taboptions[0].id}
            empDetails={state.empDetails}
            session={session}
          />
        </Grid>
      </Grid>
    </Box>
  );
};
const mapDispatchToProps = (dispatch) => ({
  getEmp: (userId, Token) => dispatch(getEmp(userId, Token)),
});
const mapStateToProps = (state) => {
  return {
    session: state.userSession,
    empDetails: state.userManagementReducer,
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(EmployeDetails);

EmployeDetails.propTypes = {
  getEmp: propTypes.func,
  getHrSign: propTypes.func,
  session: propTypes.object,
  empDetails: propTypes.object,
};
