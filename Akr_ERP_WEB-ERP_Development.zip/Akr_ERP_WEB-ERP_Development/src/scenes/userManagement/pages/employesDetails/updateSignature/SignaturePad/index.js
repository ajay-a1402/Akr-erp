import React from "react";
import propTypes from "prop-types";
import {
  Grid,
  Button,
  Box,
  makeStyles,
  Dialog,
  DialogActions,
  DialogContent,
  IconButton,
  Typography,
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import SignaturePad from "react-signature-pad-wrapper";
import { connect } from "react-redux";
import api from "../../../../services/api/userProfile";
import { useDispatch } from "react-redux";
import { hideLoader } from "../../../../../../services/loader/actions";
import { showAdvanceSnackbar } from "../../../../../../services/snackbarAdvance/actions";
import { ACTION_TYPES } from "../../../../../../constants";

const useStyles = makeStyles((theme) => ({
  signatureBox: {
    display: "flex",
    justifyContent: "center",
    alignContent: "center",
    padding: theme.spacing(1),
    height: "100%",
    width: "100%",
    // border: 'solid',
    boxShadow: "7px 9px 0.5rem rgba(0,0,0,0.5)",
  },
  signatureContainer: {
    padding: theme.spacing(2),
  },
  Pad: {
    borderStyle: "groove",
  },
  sigPad: {
    width: "100%",
    height: "100%",
    backgroundColor: "grey",
  },
  sigImage: {
    backgroundSize: "200px 50px",
    width: "250px",
    backgroundColor: " white",
  },
  signButton: {
    marginRight: theme.spacing(2),
  },
}));
const SignatureContainer = ({ setState, state, session }) => {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch();
  let signpad = React.useRef({});

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const clear = () => {
    signpad.clear();
  };
  const trim = () => {
    setState((prev) => ({
      ...prev,
      trimmedDataURL: signpad.toDataURL("image/png"),
    }));
    setOpen(false);
  };
  const handleClickRemove = () => {
    setState((prev) => ({ ...prev, trimmedDataURL: "" }));
  };
  const handleRmHrSign = () => {
    setState((prev) => ({
      ...prev,
      trimmedDataURL_hr: null,
    }));
  };
  const handleGetHrSign = () => {
    api.getHrSign(
      { token: session.auth_token, hr_id: session.userId },
      (res) => {
        if (res.data.messege === "Sucessfully fetched") {
          setState((prev) => ({
            ...prev,
            trimmedDataURL_hr: res.data.data.hr_image,
          }));
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: `Hr sign not available`,
              severity: "warn",
              onclose: true,
            })
          );
        }
      },
      (err) => {
        if (err.code === "ECONNABORTED") {
          dispatch(
            showAdvanceSnackbar({
              msg: `Response timeout ! check connection`,
              severity: "error",
              onclose: true,
            })
          );
          dispatch(hideLoader());
        } else {
          dispatch(hideLoader());
          if (err?.response.status === 401) {
            dispatch(
              showAdvanceSnackbar({
                msg: `${err.response.data.messege}`,
                severity: "error",
                onclose: true,
              })
            );
            localStorage.removeItem("spr_user_authToken");
            setState((prev) => ({
              ...prev,
              formError: false,
              userId: "",
              isHr: false,
              trimmedDataURL: null,
              trimmedDataURL_hr: null,
            }));
            dispatch({ type: ACTION_TYPES.USER_UNAUTH_ERROR });
            dispatch({ type: ACTION_TYPES.GET_EMP_FAILURE });
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: "Something went wrong. Please try again!",
                severity: "error",
                onclose: true,
              })
            );
          }
        }
      }
    );
  };
  return (
    <div>
      <Grid container spacing={2} className={classes.signatureContainer}>
        <Grid item container md={6}>
          <Grid item xs={12}>
            <Button
              size="small"
              variant="contained"
              onClick={handleClickOpen}
              className={classes.signButton}
            >
              Add Sign
            </Button>
            <Button
              variant="contained"
              size="small"
              onClick={handleClickRemove}
              className={classes.signButton}
            >
              Remove Sign
            </Button>
          </Grid>
          <Grid item>
            <Box className={classes.signatureBox}>
              {state.trimmedDataURL ? (
                <img className={classes.sigImage} src={state.trimmedDataURL} />
              ) : null}
            </Box>
          </Grid>
        </Grid>
        <Grid item md={6} container>
          {!state.isHr && (
            <>
              <Grid item xs={6}>
                <Button
                  size="small"
                  variant="contained"
                  onClick={handleGetHrSign}
                  className={classes.signButton}
                >
                  Add Hr Sign
                </Button>
              </Grid>
              <Grid item xs={6}>
                <Button
                  size="small"
                  variant="contained"
                  onClick={handleRmHrSign}
                  className={classes.signButton}
                >
                  Remove Hr Sign
                </Button>
              </Grid>
              <Grid item>
                <Box className={classes.signatureBox}>
                  {state.trimmedDataURL_hr ? (
                    <img
                      className={classes.sigImage}
                      src={state.trimmedDataURL_hr}
                    />
                  ) : null}
                </Box>
              </Grid>
            </>
          )}
        </Grid>
      </Grid>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogContent className={classes.dialogBox}>
          <Box
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Typography> Insert Signature</Typography>
            <IconButton
              aria-label="close"
              onClick={handleClose}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>{" "}
          <div className={classes.Pad}>
            <SignaturePad
              // width={500}
              options={{
                minWidth: 1,
                maxWidth: 2.5,
                backgroundColor: "#ffff",
              }}
              redrawOnResize
              ref={(ref) => {
                signpad = ref;
              }}
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={clear}>Clear</Button>
          <Button onClick={trim}>Trim</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    session: state.userSession,
    empDetails: state.userManagementReducer,
  };
};
export default connect(mapStateToProps)(SignatureContainer);
SignatureContainer.propTypes = {
  setState: propTypes.func,
  state: propTypes.object,
  session: propTypes.object,
};
