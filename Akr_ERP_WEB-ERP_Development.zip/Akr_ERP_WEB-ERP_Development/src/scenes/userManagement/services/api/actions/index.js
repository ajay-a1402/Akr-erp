import { SAGA_ACTION_TYPES } from '../../../../../constants';

export const getEmp = (empId, Token) => {
  return {
    type: SAGA_ACTION_TYPES.SAGA_FETCH_EMP,
    payload: { EMP_ID: empId, token: Token },
  };
};
