import { ACTION_TYPES } from '../../../../../constants';
const defaultState = {
  emp_name: '',
  emp_des: '',
  emp_dep: '',
  emp_id: '',
  loading: '',
};

const userManagementReducer = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.GET_EMP_SUCCESS: {
      return {
        ...state,
        emp_name: action.payload.EmployeeName,
        emp_des: action.payload.Designationname,
        emp_dep: action.payload.DepartmentName,
        emp_id: action.payload.AEmpno,
        emp_unit: action.payload.UnitName,
        loading: false,
      };
    }
    case ACTION_TYPES.GET_EMP_PENDING: {
      return {
        ...state,
        loading: true,
      };
    }

    case ACTION_TYPES.GET_EMP_FAILURE: {
      return {
        ...state,
        loading: false,
        emp_name: '',
        emp_des: '',
        emp_dep: '',
        emp_unit: '',
        emp_id: '',
      };
    }
    default:
      return state;
  }
};
export default userManagementReducer;
