/* eslint-disable no-undef */
import Axios from "axios";
import { getLocalStorageItem } from "../../../../../services/localStorage";
import { API_ENDPOINTS } from "../../../../../constants";
export default {
  getEmp: (successCallback, errorCallback, params) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.GET_EMP}`,
      {
        headers: {
          Authorization: `Bearer ${getLocalStorageItem("spr_user_authToken")}`,
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        params: { search: params.search },
      }
    )
      .then((resp) => {
        successCallback && successCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  saveSign: (payload, successCallback, errorCallback) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.SAVE_SIGN}`,
      { ...payload },
      {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        successCallback && successCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  getHrSign: (payload, successCallback, errorCallback) => {
    Axios.get(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.GET_HR_SIGN}`,
      {
        headers: {
          Authorization: `Bearer ${payload.token}`,
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        params: { hr_id: payload.hr_id },
      }
    )
      .then((resp) => {
        successCallback && successCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
};
