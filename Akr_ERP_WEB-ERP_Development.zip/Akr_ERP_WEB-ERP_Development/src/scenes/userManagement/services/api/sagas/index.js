import { put, call, takeLatest } from 'redux-saga/effects';
import { SAGA_ACTION_TYPES, ACTION_TYPES } from '../../../../../constants';
import api from '../userProfile/index';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';

export function* getUserSaga(action) {
  try {
    yield put({
      type: ACTION_TYPES.SHOW_LOADER,
      data: { loaderTxt: 'please Wait' },
    });
    const res = yield call(api.getEmp, { ...action.payload });

    if (res.status === 200) {
      yield put({ type: ACTION_TYPES.HIDE_LOADER });
      if (res.data.messege === 'Sucessfully fetched') {
        yield put({
          type: ACTION_TYPES.GET_EMP_SUCCESS,
          payload: res.data.data.user[0],
        });
      } else if (res.data.messege === 'No User Found') {
        yield put({ type: ACTION_TYPES.GET_EMP_FAILURE });
        yield put(
          showAdvanceSnackbar({
            msg: `${res.data.messege}`,
            severity: 'warn',
            onclose: true,
          })
        );
      }
    } else {
      yield put({ type: ACTION_TYPES.HIDE_LOADER });

      yield put({ type: ACTION_TYPES.GET_EMP_FAILURE });
      yield put(
        showAdvanceSnackbar({
          msg: `${res.data.messege}`,
          severity: 'error',
          onclose: true,
        })
      );
    }
  } catch (error) {
    yield put({ type: ACTION_TYPES.HIDE_LOADER });
    if (error?.response.status === 401) {
      yield put(
        showAdvanceSnackbar({
          msg: `${error.response.data.messege}`,
          severity: 'error',
          onclose: true,
        })
      );
      localStorage.removeItem('spr_user_authToken');
      yield put({ type: ACTION_TYPES.USER_UNAUTH_ERROR });
    } else {
      yield put(
        showAdvanceSnackbar({
          msg: `${error.response.data.messege}`,
          severity: 'error',
          onclose: true,
        })
      );
    }
    yield put({ type: ACTION_TYPES.GET_EMP_FAILURE });
  }
}

export function* userManagementWatcher() {
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_FETCH_EMP, getUserSaga);
}
