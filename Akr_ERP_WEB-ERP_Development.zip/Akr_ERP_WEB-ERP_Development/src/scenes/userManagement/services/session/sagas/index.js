import api from "../api";
import { put, call, takeLatest } from "redux-saga/effects";
import { ACTION_TYPES, SAGA_ACTION_TYPES } from "../../../../../constants";
import { showAdvanceSnackbar } from "../../../../../services/snackbarAdvance/actions";

export function* userloginSaga(action) {
  try {
    const res = yield call(api.userlogin, { ...action.payload });
    if (res.data.messege === "invalid user Id") {
      yield put(
        showAdvanceSnackbar({
          msg: res.data.messege,
          severity: "error",
          onclose: true,
        })
      );
    }
    if (res.data.messege === "incorrect password") {
      yield put(
        showAdvanceSnackbar({
          msg: res.data.messege,
          severity: "error",
          onclose: true,
        })
      );
    }
    if (res.data.messege === "Internal server Error") {
      yield put(
        showAdvanceSnackbar({
          msg: `${res.data.messege} Try again later `,
          severity: "error",
          onclose: true,
        })
      );
    }
    if (res.data.messege === "Sucessfully logged-in") {
      yield put({
        type: ACTION_TYPES.USER_LOGIN_SUCCESS,
        payload: {
          auth_token: res.data.data.auth_token,
          user_details: res.data.data.userDetails,
          user_section: res.data.data.section,
        },
      });
    }
  } catch (error) {
    yield put(
      showAdvanceSnackbar({
        msg: `${error} ,Try again later `,
        severity: "error",
        onclose: true,
      })
    );
    yield put({ type: ACTION_TYPES.USER_LOGIN_ERROR, error });
  }
}
export function* userLogoutSaga() {
  yield put({
    type: ACTION_TYPES.USER_AUTH_LOGOUT,
  });
  yield put({
    type: ACTION_TYPES.GET_EMP_FAILURE,
  });
}

export function* UserloginWatcher() {
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_USER_LOGIN, userloginSaga);
  yield takeLatest(SAGA_ACTION_TYPES.SAGA_USER_LOGOUT, userLogoutSaga);
}
