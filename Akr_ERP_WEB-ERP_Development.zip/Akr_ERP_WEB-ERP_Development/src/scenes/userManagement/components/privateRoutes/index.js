import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import propTypes from 'prop-types';
import { connect, useSelector } from 'react-redux';
import { isMasterUserLogin } from '../../utils';
import _ from 'lodash';
import { CircularProgress } from '@material-ui/core';

const PrivateRoute = ({ component: Component, ...rest }) => {
  const { moduleName } = rest;
  const currentSession = useSelector((state) =>
    _.get(state, 'userSession', {})
  );
  // const currentUser = useMemo(() => _.get(currentSession, 'user', {}), [currentSession])

  // const getModuleNameFromPath = (modulePath) => {
  //   return _.get(moduleMapper, modulePath, '');
  // };

  const checkPermAndRenderScreen = (props) => {
    // const { isFetchingUser, userDetails } = currentUser;
    const { isLoading } = currentSession;
    if (isLoading)
      return (
        <div
          style={{
            width: '100vw',
            height: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <CircularProgress></CircularProgress>
        </div>
      );
    else {
      // const pageMode = _.get(
      //   props,
      //   'match.params.action',
      //   PERMISSION_TYPE.VIEW
      // );
      // const finalModuleName =
      //   moduleName ||
      //   getModuleNameFromPath(_.get(props, 'match.params.module'));
      // const userPermissions = _.get(userDetails, 'module_permissions', []);
      // const isAccessGranted = isModuleAccessGranted(
      //   finalModuleName,
      // );
      // return isAccessGranted ? (
      //   <Component {...{ ...props, moduleName }} />
      // ) : (
      //   <PageNotAllowed isGoBack={true} />
      // );
      return <Component {...{ ...props, moduleName }} />;
    }
  };

  const renderScreen = (props) => {
    if (isMasterUserLogin()) return checkPermAndRenderScreen(props);
    else return <Redirect to='/employeDetails/login' />;
  };
  return <Route {...rest} render={renderScreen} />;
};
function mapStateToProps(state) {
  return {
    isAuthenticated: state.userSession.isAuthenticated || false,
  };
}
export default connect(mapStateToProps)(PrivateRoute);
PrivateRoute.propTypes = {
  component: propTypes.elementType.isRequired,
};
