import { ACTION_TYPES } from '../../../../../../constants';
const defaultState = {
  slotDetails: '',
  loading: false,
};

const slotBooking = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.BOOK_SLOT_SUCCESS: {
      return {
        ...state,
        slotDetails: action.payload,
        loading: false,
      };
    }
    case ACTION_TYPES.BOOK_SLOT_PENDING: {
      return {
        ...state,
        loading: true,
      };
    }

    case ACTION_TYPES.BOOK_SLOT_FAILURE: {
      return {
        ...state,
        loading: false,
        slotDetails: '',
      };
    }
    default:
      return state;
  }
};
export default slotBooking;
