import { SAGA_ACTION_TYPES } from '../../../../../../constants'
export const bookSlot = (value) => {
  return {
    type: SAGA_ACTION_TYPES.SAGA_BOOK_SLOT,
    payload: { ...value },
  }
}
