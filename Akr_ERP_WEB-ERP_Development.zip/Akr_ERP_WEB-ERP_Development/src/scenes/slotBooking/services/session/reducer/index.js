import { ACTION_TYPES } from '../../../../../constants';
import * as localStorage from '../../../../../services/localStorage';

function addAuthDetailsToLocalStorage(authToken, userId, userName) {
  localStorage.setLocalStorageItem('authToken', authToken);
  localStorage.setLocalStorageItem('userId', userId);
  localStorage.setLocalStorageItem('userName', userName);
}

function getDefaultState() {
  //FETCH ALL SESSION PROPERTIES FROM LOCAL STORAGE TO AFFECT STORE
  return {
    auth_token: localStorage.getLocalStorageItem('authToken'),
    userId: localStorage.getLocalStorageItem('userId'),
    isAuthenticated: !!localStorage.getLocalStorageItem('authToken'),
    userName: localStorage.getLocalStorageItem('userName'),
  };
}

const session = (state = getDefaultState(), action) => {
  switch (action.type) {
    case ACTION_TYPES.LOGIN_USER_SUCCESS: {
      addAuthDetailsToLocalStorage(
        action.payload.token,
        action.payload.user_details.party_logid,
        action.payload.user_details.PartyName
      );
      return {
        ...state,
        auth_token: action.payload.token,
        isAuthenticated: true,
        userId: action.payload.user_details.party_logid,
        userName: action.payload.user_details.PartyName,
      };
    }
    case ACTION_TYPES.AUTH_LOGOUT: {
      localStorage.removeLocalStorageItem('authToken');

      return {
        ...state,
        auth_token: '',
        isAuthenticated: false,
        userId: '',
        userName: '',
      };
    }

    case ACTION_TYPES.UNAUTH_ERROR: {
      //REMOVE EVERYTHING IN LOCAL STORAGE
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        authToken: '',
        error: { message: 'Session Timeout! Please signin again' },
        showLogOutError: false,
        userId: '',
        userName: '',
      };
    }
    case ACTION_TYPES.LOGIN_USER_ERROR: {
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        authToken: '',
        error: { message: 'Session Timeout! Please signin again' },
        showLogOutError: false,
        userId: '',
        userName: '',
      };
    }
    default:
      return state;
  }
};
export default session;
