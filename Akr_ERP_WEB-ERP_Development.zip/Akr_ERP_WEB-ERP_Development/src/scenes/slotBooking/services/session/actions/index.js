import { ACTION_TYPES, SAGA_ACTION_TYPES } from '../../../../../constants'

export const login = (username, password) => ({
  type: SAGA_ACTION_TYPES.SAGA_LOGIN_USER,
  payload: { username: username, password: password },
})
export const logout = () => ({
  type: ACTION_TYPES.AUTH_LOGOUT,
})
export const unauthError = () => ({
  type: ACTION_TYPES.UNAUTH_ERROR,
})
