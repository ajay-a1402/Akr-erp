import { Container, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import api from '../../services/api/dashboard';
import MaterialTable from 'material-table';
import * as localStorage from '../../../../services/localStorage';
import withWidth from '@material-ui/core/withWidth';
import * as _ from 'lodash';
import PropTypes from 'prop-types';
const useStyles = makeStyles((theme) => ({
  tableHeading: {
    paddingBottom: theme.spacing(4),
  },
}));

const BookedSlots = () => {
  const classes = useStyles();
  const [rowData, setRowData] = useState();
  const [loading, setLoading] = useState();
  useEffect(() => {
    setLoading(true);
    api.fetchSlotBooked(
      (res) => {
        setRowData(res.data.data);
        setLoading(false);
      },
      (err) => {
        // eslint-disable-next-line no-console
        console.log(err);
        setLoading(false);
      },
      localStorage.getLocalStorageItem('userName')
    );
  }, []);
  return (
    <div>
      <Container>
        <Typography variant='h4' className={classes.tableHeading}>
          Booked Slots
        </Typography>
        <div style={{ maxWidth: '100%', maxHeight: '100%' }}>
          <MaterialTable
            columns={[
              {
                title: 'Date',
                field: 'Date',
                type: 'datetime',
                cellStyle: {
                  position: 'sticky',
                  left: 0,
                },
                dateSetting: { locale: 'en-GB' },
              },
              { title: 'Vessel', field: 'Vessel' },
              { title: 'process', field: 'process' },

              {
                title: 'loadTime',
                field: 'loadTime',
                type: 'datetime',
                dateSetting: { locale: 'en-GB' },
              },
              {
                title: 'UnloadTime',
                field: 'UnloadTime',
                type: 'datetime',
                dateSetting: { locale: 'en-GB' },
              },
              { title: 'Status', field: 'Status' },
            ]}
            data={rowData}
            title='Slot deatails'
            isLoading={loading}
            options={{
              pageSize: 10,
              maxBodyHeight: 500,
              sorting: true,
            }}
          />
        </div>
      </Container>
    </div>
  );
};

export default withWidth()(BookedSlots);
BookedSlots.propTypes = {
  width: PropTypes.any,
};
