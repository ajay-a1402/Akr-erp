import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import propTypes from 'prop-types';
import _ from 'lodash';
import SlotTable from './slotTable';
import SlotForm from './slotForm';
import { Grid } from '@material-ui/core';
import { connect } from 'react-redux';
import LinearProgress from '@material-ui/core/LinearProgress';

const useStyles = makeStyles((theme) => ({
  navigation: {
    display: 'flex',
    width: '100VW',
    backgroundColor: theme.palette.grey[400],
  },
  dashBoardRoot: {
    padding: theme.spacing(2),
  },
  dateCellContent: {
    height: '100%',
    justifyContent: 'flex-start',
  },
  vesselCellContent: {
    height: '100%',
    justifyContent: 'flex-start',
  },
  loaderContainer: {
    paddingBottom: theme.spacing(2),
  },
}));
const SlotDashBoard = (props) => {
  const { slotReducer } = props;
  const loading = _.isEqual(slotReducer.loading, true) ? true : false;
  const classes = useStyles();
  const [data, setData] = useState({
    colour: '',
    process: '',
    Qty: '',
    Select_Date: '',
    Select_vessel: '',
  });

  return (
    <>
      <div className={classes.dashBoardRoot}>
        <>
          {loading ? (
            <div className={classes.loaderContainer}>
              <LinearProgress color='primary' />
            </div>
          ) : (
            ''
          )}
        </>

        <Grid container>
          <Grid item xs={12}>
            <SlotForm setData={setData} data={data} />
          </Grid>
          <Grid item xs={12}>
            <SlotTable setData={setData} data={data} />
          </Grid>
        </Grid>
      </div>
    </>
  );
};
const mapStateToProps = (state) => ({
  session: state.session,
  slotReducer: state.slotReducer,
});
export default connect(mapStateToProps, null)(SlotDashBoard);

SlotDashBoard.propTypes = {
  session: propTypes.object,
  slotReducer: propTypes.object,
};
