import _ from 'lodash';
import React, { useState, useImperativeHandle } from 'react';
import { useTheme } from '@material-ui/core';
import { convertGmtToLocalTime } from '../../../../../com_utils';
import moment from 'moment';
import propTypes from 'prop-types';
export const withCellRenderState = (CellRenderer) => {
  // eslint-disable-next-line react/display-name
  return React.forwardRef((props, ref) => {
    /* eslint-disable react/prop-types */

    const [value, setValue] = useState(props.value);

    useImperativeHandle(ref, () => {
      return {
        refresh: (params) => {
          if (params.value !== value) {
            setValue(params.value);
          }
          return true;
        },
      };
    });
    return <CellRenderer {...props}></CellRenderer>;
  });
};
withCellRenderState.propTypes = {
  value: propTypes.object,
};
export const dateCellRenderer = (props) => {
  const { value, data } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );

  return (
    <div className={containerClassName}>
      <span>
        {data
          ? moment(convertGmtToLocalTime(data.Date)).format('DD-MM-YYYY')
          : ''}
      </span>
    </div>
  );
};
dateCellRenderer.propTypes = {
  value: propTypes.any,
};
export const vesselCellRenderer = (props) => {
  const theme = useTheme();
  const { value, data } = props;
  let values = JSON.parse(data[props.colDef.field]);
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  const Range = {
    High: theme.palette.primary.dark,
    medium: theme.palette.warning.light,
    low: theme.palette.error.light,
  };
  if (_.inRange(data[props.colDef.field], -25, 4) && Range.low) {
    props.api.disableClickSelection = true;
  }
  return (
    <div
      className={containerClassName}
      style={{
        // paddingLeft: '10px',
        backgroundColor:
          (_.inRange(values.avail, 16, 25) && Range.High) ||
          (_.inRange(values.avail, 4, 16) && Range.medium) ||
          (_.inRange(values.avail, -100, 4) && Range.low),
      }}
    >
      <span
        style={{
          backgroundColor: value ? '#82c43c' : '#fc5a5a',
        }}
      ></span>
      <div className='m-details'>
        <span>Avail: {values.avail}</span>
        <span
          style={{
            paddingTop: '2px',
            fontSize: 'small',
          }}
        >
          Start Date: {moment(data.Date).add(-5, 'd').format('DD/MM/yyyy')}
        </span>
        <span
          style={{
            paddingTop: '2px',
            fontSize: 'small',
          }}
        >
          End Date: {moment(data.Date).add(5, 'd').format('DD/MM/yyyy')}
        </span>
      </div>
    </div>
  );
};
vesselCellRenderer.propTypes = {
  value: propTypes.object,
  data: propTypes.any,
};
