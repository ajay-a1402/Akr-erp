import React, { useEffect, useState, useRef } from 'react';
import {
  TextField,
  Typography,
  Grid,
  Button,
  useMediaQuery,
  createTheme,
  ThemeProvider,
  useTheme,
} from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { DatePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import axios from 'axios';
import { format, subDays } from 'date-fns';
import * as _ from 'lodash';
import { useDispatch } from 'react-redux';
import { useLocation } from 'react-router-dom';
import propTypes from 'prop-types';

//internal imports
import { API_ENDPOINTS } from '../../constants';
import { DateCell } from './customCellRender';
import { showAdvanceSnackbar } from '../../services/snackbarAdvance/actions';
import {
  Root,
  FormContainer,
  ButtonWrapper,
  DialogBox,
} from './styledComponents';
function useQuery() {
  const { search } = useLocation();

  return React.useMemo(() => new URLSearchParams(search), [search]);
}
const DetectionScreen = () => {
  const dispatch = useDispatch();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const [open, setOpen] = React.useState(false);
  const [pswd, setPswd] = useState('');
  const [rowData, setRowData] = useState([]);
  const [empid, setEmpId] = useState(null);
  const [FromDate, handleFromDate] = useState();
  const [ToDate, handleToDate] = useState();

  const Type = useQuery().get('type');

  useEffect(() => {
    let toDateString = new Date().toString();
    handleFromDate(subDays(new Date(), 30));
    handleToDate(toDateString);
    window.onhelp = function () {
      return false;
    };

    window.onkeydown = (evt) => {
      switch (evt.keyCode) {
        //ESC
        case 121:
          setOpen((open) => !open);
          break;
        //F1

        default:
          return true;
      }
      //Returning false overrides default browser event
      return false;
    };
  }, []);

  function formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  const handleClose = (value) => {
    setOpen(false);
    setPswd(value);
  };
  const handleFetch = () => {
    axios
      .get(
        // eslint-disable-next-line no-undef
        `${process.env.REACT_APP_BACKEND_API_PROXY}${API_ENDPOINTS.GET_CANTEEN_DATA}`,
        {
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
          timeout: 5000,
          params: {
            userId: empid,
            fromDate: formatDate(FromDate),
            toDate: formatDate(ToDate),
            type: Type,
          },
        }
      )
      .then((res) => {
        setRowData(res.data.data);
      })
      .catch((err) => {
        dispatch(
          showAdvanceSnackbar({
            msg: _.get(err.response, 'statusText', 'Check network Connection'),
            severity: 'error',
            onclose: true,
          })
        );
      });
  };

  const columns = [
    { field: 'id', headerName: 'sno', width: 50 },
    { field: 'AEmpno', headerName: 'EmpNo', width: 150 },
    { field: 'EmployeeName', headerName: 'Name', flex: 1, minWidth: 150 },
    { field: 'unitname', headerName: 'Unit', flex: 1, minWidth: 150 },
    { field: 'Deductiontype', headerName: 'Type', width: 150 },
    { field: 'Amount', headerName: 'Amount', width: 150 },
    {
      field: 'Dateandtime',
      headerName: 'Detection Date',
      width: 250,
      renderCell: DateCell,
    },
    {
      field: 'EntryDate',
      headerName: 'Entery Date',
      width: 250,
      renderCell: DateCell,
    },
    { field: 'Remarks', headerName: 'Remarks', width: 250 },
  ];
  const handleChange = (e) => {
    let value = e.target.value;
    setEmpId(value);
  };
  return (
    <Wrapper>
      {pswd === '2022' && (
        <Root>
          <FormContainer>
            <Grid container columnSpacing={1} rowSpacing={1}>
              <Grid item container xs={12} md={3}>
                <Typography>EmpNo:</Typography>

                <TextField onChange={handleChange} fullWidth />
              </Grid>
              <Grid item xs={12} md={3}>
                <Typography>From Date:</Typography>
                <DatePicker
                  value={FromDate}
                  onChange={handleFromDate}
                  renderInput={(params) => {
                    const value = _.get(params, 'inputProps.value');
                    const date = format(new Date(value), 'dd - MMM -yyyy');

                    return (
                      <TextField
                        {...params}
                        inputProps={{ value: date }}
                        fullWidth
                      />
                    );
                  }}
                />
              </Grid>
              <Grid item xs={12} md={3}>
                <Typography>To Date:</Typography>
                <DatePicker
                  value={ToDate}
                  onChange={handleToDate}
                  renderInput={(params) => {
                    const value = _.get(params, 'inputProps.value');
                    const date = format(new Date(value), 'dd - MMM - yyyy');
                    return (
                      <TextField
                        {...params}
                        inputProps={{ value: date }}
                        fullWidth
                      />
                    );
                  }}
                />
              </Grid>
              <ButtonWrapper item={true} xs={12} md={3}>
                <Button
                  variant='contained'
                  onClick={handleFetch}
                  disabled={!empid && true}
                  fullWidth={isMobile}
                >
                  Get Details
                </Button>
              </ButtonWrapper>
            </Grid>
          </FormContainer>
          <div style={{ height: '90Vh', width: '100%' }}>
            <DataGrid
              rows={rowData}
              columns={columns}
              // disableSelectionOnClick
              components={{
                Toolbar: GridToolbar,
              }}
            />
          </div>
        </Root>
      )}
      <SimpleDialog onClose={handleClose} open={open} />
    </Wrapper>
  );
};
const newtheme = createTheme();

const Wrapper = ({ children }) => {
  return (
    <ThemeProvider theme={newtheme}>
      {' '}
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        {children}
      </LocalizationProvider>
    </ThemeProvider>
  );
};
Wrapper.propTypes = {
  children: propTypes.node.isRequired,
};
function SimpleDialog(props) {
  const { onClose, open } = props;
  const [value, setValue] = useState('');

  const handleClose = () => {
    onClose(value);
  };

  const handlevalueChange = (e) => {
    setValue(e.target.value);
  };
  const onEnterKey = (e) => {
    if (e.key === 'Enter') {
      onClose(value);
    }
  };
  return (
    <DialogBox onClose={handleClose} open={open}>
      <MutantField onChange={handlevalueChange} onKeyDown={onEnterKey} />
    </DialogBox>
  );
}
SimpleDialog.propTypes = {
  onClose: propTypes.func.isRequired,
  open: propTypes.bool.isRequired,
};

const MutantField = ({ onChange, onKeyDown }) => {
  const KeyRef = useRef(null);

  useEffect(() => {
    if (KeyRef.current) KeyRef.current.focus();
  }, [open]);
  return (
    <TextField inputRef={KeyRef} onChange={onChange} onKeyDown={onKeyDown} />
  );
};
MutantField.propTypes = {
  onChange: propTypes.func.isRequired,
  onKeyDown: propTypes.func.isRequired,
};
export default DetectionScreen;
