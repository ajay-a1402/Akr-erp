import { Typography } from "@material-ui/core";
import { format } from "date-fns";

const DateCell = ({ value, field }) => {
  const time = format(new Date(value), "dd-MM-yyyy");
  return <Typography>{time}</Typography>;
};
export { DateCell };
