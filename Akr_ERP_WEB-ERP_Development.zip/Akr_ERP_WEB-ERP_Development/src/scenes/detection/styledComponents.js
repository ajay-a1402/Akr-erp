import { Grid, Dialog } from "@mui/material";
import { styled } from "@mui/material/styles";
export const Root = styled("div")(({ theme }) => ({
  padding: theme.spacing(1),
}));
export const FormContainer = styled("div")(({ theme }) => ({
  margin: theme.spacing(2, 0),
}));
export const ButtonWrapper = styled(Grid)(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
}));
export const DialogBox = styled(Dialog)(({ theme }) => ({}));
