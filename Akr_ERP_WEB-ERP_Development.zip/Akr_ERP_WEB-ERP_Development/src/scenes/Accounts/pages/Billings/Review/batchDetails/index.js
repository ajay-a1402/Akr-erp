import React, { useState, useEffect, useMemo } from 'react';
import propTypes from 'prop-types';
import { convertLocalTimeToGmtStr } from '../../../../../../com_utils';
import { makeStyles } from '@material-ui/core/styles';
import { Autocomplete } from '@material-ui/lab';
import {
  Grid,
  Typography,
  Box,
  TextField,
  Icon,
  Divider,
  Button,
  useTheme,
  useMediaQuery,
} from '@material-ui/core';
import {} from '@material-ui/core/styles';
import * as _ from 'lodash';
import classnames from 'classnames';
import { useDispatch } from 'react-redux';
import api from '../../../../services/api';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';
import {
  clearAllSession,
  getSessionStorageItem,
} from '../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import { stubTrue } from 'lodash-es';
import { statusCode } from '../../../../../../constants';
const useStyles = makeStyles((theme) => ({
  root: {
    paddingLeft: theme.spacing(2),
  },
  mainWrapper: {
    // marginBottom: theme.spacing(2),
  },
  fieldlLabel: {
    // marginRight: theme.spacing(2),
    color: theme.palette.grey[800],
  },
  batchLabelContainer: {
    display: 'flex',
    fontSize: '12px',
  },
  circle: {
    background: ' #e3e3e3',
    borderRadius: ' 50%',
    // -moz-border-radius: '50%',
    // -webkit-border-radius:' 50%',
    color: ' #6e6e6e',
    display: 'inline-block',
    fontWeight: 'bold',
    lineHeight: '20px',
    marginRight: '5px',
    textAlign: 'center',
    width: '20px',
    fontSize: '12px',
    marginBottom: theme.spacing(2),
  },
  approved: {
    background: theme.palette.success.main,
    color: theme.palette.almostBlack[0],
  },
  numberColumn: {
    display: 'flex',
    flexDirection: 'column',
    marginLeft: theme.spacing(2),
  },
  subWrapper: {
    paddingRight: theme.spacing(1),
  },
  autocompleteText: {
    fontSize: '12px',
  },
  approveButton: {
    backgroundColor: theme.palette.success.main,
    '&:hover': {
      backgroundColor: theme.palette.success.main,
    },
    '&:disabled': {
      backgroundColor: theme.palette.success.light,
    },
  },
  rejectButton: {
    backgroundColor: theme.palette.warning.main,
    '&:hover': {
      backgroundColor: theme.palette.warning.main,
    },
    '&:disabled': {
      backgroundColor: theme.palette.warning.light,
    },
  },
}));
const BatchDetails = ({
  batchOptions,
  setReviewState,
  reviewState,
  setBatchOptions,
}) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down('md'));
  const handleUpdate = (status) => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to ${
          status === 1 ? 'Approve' : 'Reject'
        } this Batch?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          api.updateBatchApproveStatus(
            (res) => {
              dispatch(hideLoader());
              if (res.data.status !== 'fail') {
                setBatchOptions(res.data.data);
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Status Updated sucessfully',
                    severity: 'success',
                    onclose: true,
                  })
                );
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: _.get(
                      res.data,
                      'messege',
                      `Fail to ${status === 1 ? 'Approve' : 'Reject'} `
                    ),
                    severity: 'warning',
                    onclose: true,
                  })
                );
              }
            },
            (err) => {
              dispatch(hideLoader());
              if (err.response) {
                if (err.response.status === statusCode.badRequest) {
                  clearAllSession();
                  history.replace('/accounts/authfail');
                }
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Check network Connection',
                    severity: 'error',
                    onclose: true,
                  })
                );
              }
            },
            {
              PayBatchEnno: _.get(reviewState.selectedBatch, 'PayBatchEnno', 0),
              userId: getSessionStorageItem('UserId'),
              status: status,
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };

  return (
    <div className={classes.root}>
      <Grid container spacing={2}>
        <Grid container item xs={12} md={10} spacing={3}>
          <Grid item container className={classes.mainWrapper} spacing={1}>
            <Grid item container xs={12} md={4} className={classes.subWrapper}>
              <Grid item xs={4} md={3}>
                <Typography className={classes.fieldlLabel}>Batch :</Typography>
              </Grid>
              <Grid item xs={8} md={9}>
                <Autocomplete
                  className={classes.autoComplete}
                  classes={{ option: classes.options }}
                  options={batchOptions}
                  noOptionsText='no batches found'
                  onChange={(_event, newValue) => {
                    setReviewState((prev) => ({
                      ...prev,
                      selectedBatch: newValue,
                    }));
                  }}
                  getOptionLabel={(option) => {
                    return option.BatchAmount + '';
                  }}
                  renderOption={(option) => (
                    <Box className={classes.batchLabelContainer}>
                      <Box>
                        <Typography className={classes.autocompleteText}>
                          Entery No: {option.PayBatchEnno}
                        </Typography>
                        <Box style={{ display: 'flex' }}>
                          <Icon
                            style={{ marginRight: '15px', fontSize: '14px' }}
                          >
                            currency_rupee
                          </Icon>
                          <Typography className={classes.autocompleteText}>
                            {option.BatchAmount}
                          </Typography>
                        </Box>
                        <Box style={{ display: 'flex' }}>
                          {' '}
                          <Icon
                            style={{ marginRight: '15px', fontSize: '14px' }}
                          >
                            person
                          </Icon>
                          <Typography className={classes.autocompleteText}>
                            {option.EmployeeName}
                          </Typography>
                        </Box>
                        <>
                          <Box style={{ display: 'flex' }}>
                            <Icon
                              style={{ marginRight: '15px', fontSize: '14px' }}
                            >
                              event_available
                            </Icon>
                            <Typography className={classes.autocompleteText}>
                              {' '}
                              {convertLocalTimeToGmtStr(option.Entrydate).slice(
                                0,
                                11
                              )}{' '}
                            </Typography>{' '}
                          </Box>
                        </>
                      </Box>
                      <Box className={classes.numberColumn}>
                        <Typography className={classes.autocompleteText}>
                          Approve{' '}
                          <span
                            className={classnames(classes.circle, {
                              [classes.approved]: option.app1flag,
                            })}
                          >
                            1
                          </span>
                        </Typography>
                        <Typography className={classes.autocompleteText}>
                          Approve{' '}
                          <span
                            className={classnames(classes.circle, {
                              [classes.approved]: option.app2flag,
                            })}
                          >
                            2
                          </span>
                        </Typography>
                      </Box>
                      {/* </Box> */}
                    </Box>
                  )}
                  renderInput={(params) => (
                    <TextField {...params} variant='outlined' fullWidth />
                  )}
                />
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={5} md={4}>
                {' '}
                <Typography className={classes.fieldlLabel}>
                  {' '}
                  Batch Date :
                </Typography>
              </Grid>
              <Grid item xs={7} md={8}>
                {' '}
                <Typography>
                  {' '}
                  {!_.isEmpty(reviewState.selectedBatch?.Entrydate)
                    ? convertLocalTimeToGmtStr(
                        _.get(reviewState.selectedBatch, 'Entrydate')
                      ).slice(0, 16)
                    : '00:00:000'}
                </Typography>
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={58}>
                {' '}
                <Typography className={classes.fieldlLabel}>
                  {' '}
                  Batch Amount :
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  {_.get(reviewState.selectedBatch, 'BatchAmount', 0)}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item container className={classes.mainWrapper} spacing={1}>
            <Grid item container xs={12} md={4}>
              <Grid item xs={4}>
                {' '}
                <Typography className={classes.fieldlLabel}> Bank :</Typography>
              </Grid>
              <Grid item xs={7}>
                {' '}
                <Typography>
                  {_.get(reviewState.selectedBatch, 'OurBankName', '')}
                </Typography>
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={5}>
                {' '}
                <Typography className={classes.fieldlLabel}>
                  {' '}
                  Avail Amount :
                </Typography>
              </Grid>
              <Grid item xs={7}>
                {' '}
                <Typography>
                  {_.get(reviewState.selectedBatch, 'FundAvailable', 0)}
                </Typography>
              </Grid>
            </Grid>
            <Grid item container xs={12} md={3}>
              {/* <Grid item xs={4}>
              {' '}
              <Typography className={classes.fieldlLabel}>
                {' '}
                Balance :
              </Typography>
            </Grid>
            <Grid item xs={8}>
              {' '}
              <Typography>
                {_.get(reviewState.selectedBatch, 'BatchAmount', 0)}
              </Typography>
            </Grid> */}
            </Grid>
          </Grid>
        </Grid>
        <Grid item container xs={12} md={2}>
          <Grid item xs={6} md={12}>
            <Button
              disabled={_.isEmpty(reviewState.selectedBatch)}
              className={classes.approveButton}
              onClick={() => {
                handleUpdate(1);
              }}
              defaultValue={1}
            >
              Approve
            </Button>
          </Grid>
          <Grid item xs={6} md={12}>
            <Button
              disabled={_.isEmpty(reviewState.selectedBatch)}
              className={classes.rejectButton}
              onClick={() => {
                handleUpdate(0);
              }}
            >
              Reject
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};
export default BatchDetails;
