import React, { useState, useEffect, useMemo } from 'react';
import propTypes from 'prop-types';

import {
  Grid,
  Typography,
  Box,
  TextField,
  Icon,
  Divider,
  Button,
  Toolbar,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Api from '../../../services/api';
import * as _ from 'lodash';
import BatchDetails from './batchDetails';
import BatchReviewTable from './batchReviewTable';
import ReviewInvoiceTabel from './invoiceTable';
import {
  clearAllSession,
  getSessionStorageItem,
} from '../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import { API_ENDPOINTS, statusCode } from '../../../../../constants';
import { useDispatch } from 'react-redux';
import { showAdvanceSnackbar } from '../../../../../services/snackbarAdvance/actions';
const useStyles = makeStyles((theme) => ({
  root: {
    paddingLeft: theme.spacing(2),
  },
  mainWrapper: {
    marginBottom: theme.spacing(2),
  },
  fieldlLabel: {
    marginRight: theme.spacing(2),
  },
  mainContainer: {
    padding: theme.spacing(0.5, 0.5, 0.5, 1),
  },
}));
const BatchReview = () => {
  const classes = useStyles();
  const [batchOptions, setBatchOptions] = useState([]);
  const [reviewState, setReviewState] = useState({
    selectedBatch: {},
    party: null,
    isSelected: false,
  });
  const history = useHistory();
  const dispatch = useDispatch();

  useEffect(() => {
    Api.GetRequest(
      API_ENDPOINTS.FETCH_REVIEW_BATCHES,
      (res) => {
        setBatchOptions(res.data.data);
      },
      (err) => {
        if (err.response) {
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(err.response.data, 'messege', 'Error'),
              severity: 'error',
              onclose: true,
            })
          );
        }
      }
    );
  }, []);
  return (
    <>
      <Toolbar />
      <div className={classes.mainContainer}>
        <BatchDetails
          batchOptions={batchOptions}
          reviewState={reviewState}
          setReviewState={setReviewState}
          setBatchOptions={setBatchOptions}
        />
        <BatchReviewTable
          reviewState={reviewState}
          setReviewState={setReviewState}
        />
        <ReviewInvoiceTabel
          reviewState={reviewState}
          setReviewState={setReviewState}
        />
      </div>
    </>
  );
};
export default BatchReview;
