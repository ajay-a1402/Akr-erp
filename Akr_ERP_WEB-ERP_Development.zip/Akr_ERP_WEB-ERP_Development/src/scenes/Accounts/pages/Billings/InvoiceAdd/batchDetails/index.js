import React, { useState, useEffect, useMemo } from 'react';
import propTypes from 'prop-types';
import {
  Grid,
  Typography,
  Box,
  TextField,
  Icon,
  Dialog,
  Button,
  AppBar,
  Slide,
  IconButton,
  Toolbar,
  Container,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import withWidth from '@material-ui/core/withWidth';

import { Autocomplete } from '@material-ui/lab';
import Api from '../../../../services/api';
import * as Actions from '../../../../services/api/actions';
import * as _ from 'lodash';
import { convertLocalTimeToGmtStr } from '../../../../../../com_utils';
import { connect, useDispatch } from 'react-redux';
import { compose } from 'redux';

import { isGuest, isMember, isApprovar } from '../../../../utils';
import {
  clearAllSession,
  getSessionStorageItem,
  removeSessionStorageItem,
} from '../../../../../../services/sessionStorage';
import { useHistory } from 'react-router';
import {
  hideLoader,
  showConfirmMessage,
  showLoader,
} from '../../../../../../services/loader/actions';
import { showAdvanceSnackbar } from '../../../../../../services/snackbarAdvance/actions';
import AgGridCustom from '../../../../../../com_components/AgGridCustom';
import { API_ENDPOINTS, statusCode } from '../../../../../../constants';
import api from '../../../../services/api';
import useAppBarHeight from '../../../../../../hooks/useAppBarHeight';

const KEY_BACKSPACE = 8;
const KEY_DELETE = 46;
const KEY_ENTER = 13;
const KEY_TAB = 9;

const useStyles = makeStyles((theme) => ({
  fieldWrapper: {
    display: 'flex',
  },

  staticCellStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
  mainWrapper: {
    marginBottom: theme.spacing(1),
    '& .MuiTypography-body1': {
      fontSize: '14px',
    },
    '& .MuiButton-root': {},
  },
  batchLabelContainer: {
    // display: 'flex',
  },
  batchLabelWrapperSub: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  options: {
    '&:hover': {
      backgroundColor: theme.palette.grey[100],
    },
  },
  fieldlLabel: {
    marginRight: theme.spacing(2),
  },
  Button: { backgroundColor: theme.palette.info.main },
  failureButton: {
    backgroundColor: theme.palette.error.light,
    '&:hover': {
      backgroundColor: '#f25555',
    },
  },
  successButton: {
    backgroundColor: theme.palette.success.light,
    '&:hover': {
      backgroundColor: '#589c57',
    },
  },

  appBar: {
    backgroundColor: theme.palette.secondary.dark,
  },
  appBarHeading: {
    paddingLeft: theme.spacing(2),
  },
}));

const BatchForm = (props) => {
  const {
    changeBatch,
    state,
    width,
    UpdateSelectedInvoice,
    UpdateAvailAmount,
  } = props;
  const classes = useStyles();
  //variable for batch details
  const [batchOptions, setBatchOptions] = useState([]);
  //variable for bank details
  const [bankOptions, setBankOptions] = useState([]);
  const [batchId, setBatchId] = useState(null);
  const history = useHistory();
  const dispatch = useDispatch();
  const [formState, setFormState] = useState({
    bank: null,
  });
  useEffect(() => {
    Api.fetchBatchDetails({ token: getSessionStorageItem('accounts-Auth') })
      .then((res) => {
        setBatchOptions(res.data.data);
      })
      .catch((err) => {
        if (err.response) {
          if (_.get(err.response, 'status', null) === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: _.get(err.response.data, 'messege', 'Error'),
                severity: 'error',
                onclose: true,
              })
            );
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      });
    setTimeout(() => {
      Api.fetchBankDetails()
        .then((res) => {
          setBankOptions(_.get(res.data, 'data', []));
        })
        .catch((err) => {
          dispatch(
            showAdvanceSnackbar({
              msg: _.get(
                err.response,
                'statusText',
                'Check network Connection'
              ),
              severity: 'error',
              onclose: true,
            })
          );
        });
    }, 200);
    return () => {
      UpdateAvailAmount(0), changeBatch(null);
      setBatchId(null), setFormState(null);
    };
  }, []);

  // function to calculate balance
  const getBalance = useMemo(() => {
    return _.sumBy(state.selectedInvoice, (data) => {
      return data.AllotAmount;
    });
  }, [state.selectedInvoice]);

  //handle function for  amount
  // eslint-disable-next-line no-useless-escape
  const handleAmount = (e) => {
    if (e.target.value === '') {
      UpdateAvailAmount(0);
      return;
    } else {
      UpdateAvailAmount(e.target.value);
    }
  };
  const restPage = () => {
    setBatchId(null);
    changeBatch({});
    UpdateAvailAmount(0);
    setFormState((prev) => ({
      ...prev,
      bank: null,
    }));
  };
  //function to upload
  const handleUpload = () => {
    dispatch(
      showConfirmMessage(
        `Are you sure, you want to Add this Bills?`,
        '',
        'Confirm',
        () => {
          dispatch(showLoader('Please wait...'));
          Api.updateBatchWithBills(
            (res) => {
              dispatch(hideLoader());

              dispatch(
                showAdvanceSnackbar({
                  msg: 'Bills Saved sucessfully',
                  severity: 'success',
                  onclose: true,
                })
              );
              setBatchOptions(res.data.data);
              restPage();
            },
            (err) => {
              dispatch(hideLoader());
              if (err.response) {
                if (err.response.status === statusCode.badRequest) {
                  clearAllSession();
                  history.replace('/accounts/authfail');
                } else {
                  dispatch(
                    showAdvanceSnackbar({
                      msg: _.get(err.response.data, 'messege', err),
                      severity: 'error',
                      onclose: true,
                    })
                  );
                }
              } else {
                dispatch(
                  showAdvanceSnackbar({
                    msg: 'Check network Connection',
                    severity: 'error',
                    onclose: true,
                  })
                );
              }
            },
            {
              selectedInvoice: state.selectedInvoice,
              PayBatchEnno: state.batch.PayBatchEnno,
              PayAllotEnno: state.batch.PayAllotEnno,
              batchDetails: state.batchDetails,
            }
          );
        },
        'Cancel',
        () => {
          dispatch(hideLoader());
        },
        'add_task'
      )
    );
  };

  // function to clear selectOptions
  const handleClear = () => {
    UpdateSelectedInvoice([]);
  };
  const isAllowed = useMemo(() => {
    if (
      _.get(state, 'AvailableAmount', 0) == 0 ||
      formState.bank == null ||
      _.isEmpty(state.batch)
    )
      return false;
    else return true;
  }, [state, formState]);

  //dunction to change bank
  const handleBank = (event, newValue) => {
    // console.log(newValue);
    setFormState((prev) => ({
      ...prev,
      bank: _.get(newValue, 'Bankid', null),
    }));
  };
  const handleCreatePayBatch = () => {
    dispatch(showLoader('Please wait...'));
    Api.PostRequest(
      API_ENDPOINTS.CREATE_PAYBATCH_ALLOT,
      (res) => {
        dispatch(hideLoader());
        setBatchOptions(res.data.data);
        let filtered = _.find(res.data.data, (o) => {
          return o.PayBatchEnno === batchId;
        });
        changeBatch(filtered);
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: _.get(err.response.data, 'messege', err),
                severity: 'error',
                onclose: true,
              })
            );
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      {
        userId: getSessionStorageItem('UserId'),
        ourBankId: formState.bank,
        availableAmount: parseFloat(_.get(state, 'AvailableAmount', 0)),
        PayBatchEnno: state.batch.PayBatchEnno,
      }
    );
  };
  const handleUpdatePayBatch = () => {
    dispatch(showLoader('Please wait...'));
    Api.PostRequest(
      API_ENDPOINTS.UPDATE_PAYBATCH_ALLOT,
      (res) => {
        dispatch(hideLoader());
        setBatchOptions(res.data.data);

        let filtered = _.find(res.data.data, (o) => {
          return o.PayBatchEnno === batchId;
        });
        changeBatch(filtered);
      },
      (err) => {
        dispatch(hideLoader());
        if (err.response) {
          if (err.response.status === statusCode.badRequest) {
            clearAllSession();
            history.replace('/accounts/authfail');
          } else {
            dispatch(
              showAdvanceSnackbar({
                msg: _.get(err.response.data, 'messege', err),
                severity: 'error',
                onclose: true,
              })
            );
          }
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: 'Check network Connection',
              severity: 'error',
              onclose: true,
            })
          );
        }
      },
      {
        ourBankId: formState.bank,
        availableAmount: parseFloat(_.get(state, 'AvailableAmount', 0)),
        PayAllotEnno: state.batch.PayAllotEnno,
      }
    );
  };

  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const [bankState, setBank] = useState();
  useEffect(() => {
    let test = _.find(bankOptions, (o) => {
      return o.Bankid === _.get(formState, 'bank');
    });
    setBank(test);
  }, [bankOptions, formState]);

  const colDef = [
    {
      field: 'index',
      hide: true,
      valueGetter: 'node.rowIndex',
    },
    {
      field: 'Bno',
      headerName: 'B NO',
      headerTooltip: 'Batch number',
      tooltipField: 'Bno',
      minWidth: 100,
      cellClass: classes.staticCellStyle,
    },

    {
      field: 'Billgroupno',
      headerName: 'Bill Group',
      headerTooltip: 'Bill Group No',
      tooltipField: 'Billgroupno',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'PartyName',
      headerName: 'Party Name',
      headerTooltip: 'Party Name',
      tooltipField: 'Partyname',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BDate',
      headerName: 'Date',
      headerTooltip: 'Bill Date',
      minWidth: 180,
      cellClass: [classes.staticCellStyle],
      cellRenderer: 'dateCellRenderer',
    },
    {
      field: 'partyid',
      headerName: 'vendor code',
      headerTooltip: 'vendor code',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },

    {
      field: 'BillAmount',
      headerName: 'Bill Amount',
      headerTooltip: 'Bill Amount',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BillBalance',
      headerName: 'Bill Balance',
      headerTooltip: 'Bill Balance',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'BillPaidBalance',
      headerName: 'Bill Paid Balance',
      minWidth: 180,
      headerTooltip: 'Bill Paid Balance',
      cellClass: classes.staticCellStyle,
    },
    {
      field: 'AllotAmount',
      headerName: 'Allot Amount',
      headerTooltip: 'Allot Amount',
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
  ];
  const appbarHeight = useAppBarHeight();
  let tableHeight = useMemo(() => {
    let currentHeight = window.innerHeight;
    return currentHeight - appbarHeight;
  });
  return (
    <div>
      <Grid container className={classes.mainWrapper}>
        <Grid item container xs={12} md={10}>
          <Grid item container spacing={2} xs={12}>
            <Grid item container xs={12} md={4}>
              <Grid item xs={4}>
                <Typography>Batch :</Typography>
              </Grid>
              <Grid item xs={8}>
                <Autocomplete
                  className={classes.autoComplete}
                  classes={{ option: classes.options }}
                  fullWidth
                  value={_.get(state, 'batch') ? _.get(state, 'batch') : null}
                  options={batchOptions}
                  getOptionSelected={(props, value) =>
                    props?.PayBatchEnno === value?.PayBatchEnno
                  }
                  noOptionsText='no batches found'
                  onChange={(event, newValue) => {
                    changeBatch(newValue);
                    setBatchId(_.get(newValue, 'PayBatchEnno'));
                    setFormState((prev) => ({
                      ...prev,
                      bank: _.get(newValue, 'OurBankId'),
                    }));
                    UpdateAvailAmount(
                      _.isNull(_.get(newValue, 'FundAvailable', 0))
                        ? 0
                        : _.get(newValue, 'FundAvailable', 0)
                    );
                  }}
                  getOptionLabel={(option) => {
                    return 'Enno : ' + option.PayBatchEnno + '';
                  }}
                  renderOption={(option) => (
                    <Box className={classes.batchLabelContainer}>
                      <Typography className={classes.autocompleteText}>
                        Entery No: {option.PayBatchEnno}
                      </Typography>
                      <Box style={{ display: 'flex' }}>
                        <Icon style={{ marginRight: '15px' }}>
                          currency_rupee
                        </Icon>
                        <Typography>{option.BatchAmount}</Typography>
                      </Box>
                      <Box style={{ display: 'flex' }}>
                        {' '}
                        <Icon style={{ marginRight: '15px' }}>person</Icon>
                        <Typography>{option.EmployeeName}</Typography>
                      </Box>
                      <>
                        <Box style={{ display: 'flex' }}>
                          <Icon style={{ marginRight: '15px' }}>
                            event_available
                          </Icon>
                          <Typography>
                            {' '}
                            {convertLocalTimeToGmtStr(option.Entrydate).slice(
                              0,
                              11
                            )}{' '}
                          </Typography>{' '}
                        </Box>
                      </>
                    </Box>
                  )}
                  renderInput={(params) => (
                    <TextField {...params} variant='outlined' fullWidth />
                  )}
                />
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              {!isGuest() && (
                <>
                  {' '}
                  <Grid item xs={4}>
                    <Typography>Bank A/C :</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Autocomplete
                      options={bankOptions}
                      noOptionsText='no bank found'
                      value={bankState ? bankState : null}
                      getOptionSelected={(props, value) =>
                        props?.Bankid === value?.Bankid
                      }
                      getOptionLabel={(option) => {
                        return option.OurBankName;
                      }}
                      renderInput={(params) => {
                        return (
                          <TextField {...params} variant='outlined' fullWidth />
                        );
                      }}
                      onChange={handleBank}
                    />
                  </Grid>
                </>
              )}
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={4}>
                <Typography className={classes.fieldlLabel}>
                  Amount :
                </Typography>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  label=''
                  variant='outlined'
                  disabled={!isMember()}
                  error={_.get(state, 'AvailableAmount', 0) == 0 && true}
                  helperText={
                    _.get(state, 'AvailableAmount', 0) == 0 && '** REQUIRED **'
                  }
                  value={
                    _.isNull(_.get(state, 'AvailableAmount', 0))
                      ? 0
                      : _.get(state, 'AvailableAmount', 0)
                  }
                  onChange={handleAmount}
                  onKeyDown={(e) => {
                    if (
                      (e.keyCode >= 96 && e.keyCode <= 105) ||
                      e.keyCode == 8 ||
                      e.keyCode == 110 ||
                      (e.keyCode > 36 && e.keyCode <= 40)
                    ) {
                      return;
                    } else {
                      if (e.preventDefault) e.preventDefault();
                    }
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item container spacing={2} xs={12}>
            <Grid item container xs={12} md={4}>
              <Grid item xs={6}>
                <Typography className={classes.fieldlLabel}>
                  {' '}
                  Batch Date :
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  {' '}
                  {!_.isEmpty(state.batch?.Entrydate)
                    ? convertLocalTimeToGmtStr(
                        _.get(state.batch, 'Entrydate')
                      ).slice(0, 16)
                    : '00:00:000'}
                </Typography>
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={6}>
                <Typography className={classes.fieldlLabel}>
                  Batch Amount :
                </Typography>
              </Grid>
              <Grid item xs={6}>
                {' '}
                <Typography> {_.get(state.batch, 'BatchAmount', 0)}</Typography>
              </Grid>
            </Grid>
            <Grid item container xs={12} md={4}>
              <Grid item xs={6}>
                <Typography className={classes.fieldlLabel}>
                  Balance :
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  {/* {parseFloat(_.get(state, 'AvailableAmount', 0)) - getBalance} */}
                  {_.get(state, 'AvailableAmount', 0) - getBalance}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid item container spacing={2} xs={12} md={2}>
          {isMember() && (
            <>
              <Grid item xs={12}>
                <Button
                  className={classes.successButton}
                  disabled={!isAllowed}
                  fullWidth
                  onClick={
                    _.isNull(_.get(state, 'batch.PayAllotEnno', null))
                      ? handleCreatePayBatch
                      : handleUpdatePayBatch
                  }
                >
                  {_.isNull(_.get(state, 'batch.PayAllotEnno', null))
                    ? 'Create pay batch'
                    : 'Update pay batch'}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Button
                  className={classes.failureButton}
                  disabled={_.isEmpty(state.selectedInvoice)}
                  fullWidth
                  // onClick={handleClear}
                  onClick={handleUpload}
                >
                  Update Bills
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Button
                  className={classes.failureButton}
                  disabled={_.isEmpty(state.selectedInvoice)}
                  fullWidth
                  // onClick={handleClear}
                  onClick={handleClear}
                >
                  Clear
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Button
                  className={classes.Button}
                  // disabled={_.isEmpty(state.selectedInvoice)}
                  fullWidth
                  onClick={handleClickOpen}
                >
                  View selected
                </Button>
              </Grid>
            </>
          )}
        </Grid>
      </Grid>
      <Dialog
        fullScreen
        TransitionComponent={Transition}
        onClose={handleClose}
        aria-labelledby='simple-dialog-title'
        open={open}
      >
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton
              edge='end'
              color='inherit'
              onClick={handleClose}
              aria-label='close'
            >
              <Icon>close</Icon>
            </IconButton>
            <Typography variant='h6' className={classes.appBarHeading}>
              Selected Bills
            </Typography>
          </Toolbar>
        </AppBar>

        <Box>
          <Toolbar />
          <div style={{ maxWidth: '100vW' }}>
            <AgGridCustom
              columnDefs={colDef}
              defaultColDef={{
                initialWidth: 140,
                sortable: true,
              }}
              height={tableHeight}
              rowHeight={_.isEqual(width, 'xs') ? 40 : 50}
              rowData={_.get(state, 'selectedInvoice', [])}
            />
          </div>
        </Box>
      </Dialog>
    </div>
  );
};

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction='up' ref={ref} {...props} />;
});

const mapStateToProps = (state) => ({
  state: state.AccountsBillsReducer,
});
const mapDispatchToProps = (dispatch) => ({
  changeBatch: (value) => dispatch(Actions.ChangeBatch(value)),
  UpdateAvailAmount: (value) => dispatch(Actions.updateAvailAmount(value)),
  UpdateSelectedInvoice: (data) => {
    dispatch(Actions.updateSelectedInvoice(data));
  },
  UpdateBatchBills: (data) => {
    dispatch(Actions.updateBillsToServer(data));
  },
});
BatchForm.propTypes = {
  UpdateBatchBills: propTypes.func,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  withWidth()
)(BatchForm);
