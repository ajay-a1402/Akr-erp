import React, { useEffect, useMemo, useCallback, useState } from "react";
import api from "../../../../services/api";
import * as _ from "lodash";
import AgGridCustom from "../../../../../../com_components/AgGridCustom";
import propTypes from "prop-types";
import { batch, connect, useDispatch } from "react-redux";
import {
  Grid,
  Typography,
  Button,
  useMediaQuery,
  useTheme,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import classnames from "classnames";
import {
  withCellRenderState,
  dateCellRenderer,
} from "./customCells/customCell";
import withWidth, { isWidthUp } from "@material-ui/core/withWidth";

import editableNumericCell from "./customCells/editableNumericCell";
import { isApprovar, isGuest, isMember } from "../../../../utils";
import {
  updateBillsInvoices,
  updateSelectedInvoice,
} from "../../../../services/api/actions";
import { showAdvanceSnackbar } from "../../../../../../services/snackbarAdvance/actions";
const useStyles = makeStyles((theme) => ({
  invoiceContainer: {
    padding: theme.spacing(2, 0, 5, 0),
  },
  invoiceToolBar: {
    display: "flex",
    alignItems: "center",
  },
  invoiceToolBarSub: {
    display: "flex",
  },
  staticCellStyle: {
    textAlign: "center",
    justifyContent: "center",
    fontSize: "10px",
  },
  nameCellStyle: {
    textAlign: "left",
    "& .ag-header-cell-label": {
      /* Necessary to allow for text to grow vertically */
    },
  },
  heading: {
    fontWeight: 600,
  },

  batchNoHeader: {
    paddingLeft: `${theme.spacing(0.2)} !important`,
  },
  dateCellContent: {
    height: "100%",
    display: "flex",
    // '&:focus': {},
  },
  actionContainer: {
    display: "flex",
    justifyContent: "flex-end",
    padding: theme.spacing(1, 2),
  },
  approveButton: {
    backgroundColor: theme.palette.success.light,
  },
  headerCell: {
    fontSize: "12px",
    backgroundColor: theme.palette.grey[100],
    padding: `${theme.spacing(0.5, 0)} !important`,
  },
}));
const InvoiceTabel = (props) => {
  const { state, UpdateSelectedInvoice, width, UpdateInvoices } = props;

  const [rowData, setRowData] = useState([]);
  const [rowEdited, setEdited] = useState({});
  const [InvoiceList, setInvoiceList] = useState([]);
  const gridref = React.useRef();
  const [balAmount, setBalAmount] = useState(0);
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down("md"));
  const classes = useStyles();
  const dispatch = useDispatch();
  useEffect(() => {
    let compareArray = _.filter(_.get(state, "selectedInvoice", []), (o) => {
      return o.partyid === _.get(state, "vendorID", "");
    });
    setRowData(
      _.unionWith(
        compareArray,
        _.get(state, "invoiceList", []),
        (object, other) => {
          return (
            object.partyid == other.partyid &&
            object.Billgroupno == other.Billgroupno &&
            object.Bno == other.Bno
          );
        }
      )
    );
    setTimeout(() => {
      autoSelect();
    }, [1000]);
    setEdited({});
    setInvoiceList([]);
    return () => {
      setBalAmount(0);
    };
  }, [state.invoiceList, state.batch]);

  const autoSelect = () => {
    let total = _.get(state, "alottedAmount", 0);
    gridref?.current?.api.deselectAll();
    gridref?.current?.api.forEachNode((node) => {
      if (total >= _.get(node, "data.AllotAmount", 0)) {
        total = total - _.get(node, "data.AllotAmount", 0);
        node.setSelected(true);
      }
    });
  };

  const valueGetter = (props) => {
    let total = _.get(state, "alottedAmount", 0);
    return (props.data.AllotAmount = _.get(props.data, "AllotAmount", 0));
  };
  const ValueSetter = (props) => {
    if (props.newValue <= props.data.BillBalance) {
      props.data.AllotAmount = props.newValue;
    }
  };
  const getBalance = useMemo(() => {
    return _.sumBy(state.selectedInvoice, (data) => {
      return data.AllotAmount;
    });
  }, [state.selectedInvoice]);

  const colDef = [
    {
      field: "index",
      hide: true,
      valueGetter: "node.rowIndex",
    },
    {
      field: "Bno",
      headerName: "B NO",
      headerTooltip: "Batch number",
      tooltipField: "Bno",

      headerClass: classnames(classes.batchNoHeader, classes.headerCell),
      headerCheckGridSelection: false,
      checkGridSelection: true,
      checkboxSelection: true,
      headerCheckGridSelectionFilteredOnly: true,
      minWidth: 100,
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },

    {
      field: "Billgroupno",
      headerName: "Bill Group",
      headerTooltip: "Bill Group No",
      tooltipField: "Billgroupno",
      minWidth: 180,
      headerClass: classnames(classes.headerCell),

      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },
    {
      field: "PartyName",
      headerName: "Party Name",
      headerTooltip: "Party Name",
      headerClass: classnames(classes.headerCell),

      tooltipField: "Partyname",
      minWidth: 180,
      cellClass: classnames(classes.staticCellStyle, classes.nameCellStyle),
    },
    {
      field: "BDate",
      headerName: "Date",
      headerTooltip: "Bill Date",
      cellClass: [classes.staticCellStyle],
      headerClass: classnames(classes.headerCell),
      minWidth: 180,
      cellRenderer: "dateCellRenderer",
      cellRendererParams: {
        containerClass: classes.dateCellContent,
      },
    },
    {
      field: "partyid",
      headerName: "vendor code",
      headerTooltip: "vendor code",
      headerClass: classnames(classes.headerCell),
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },

    {
      field: "BillAmount",
      headerName: "Bill Amount",
      headerTooltip: "Bill Amount",
      minWidth: 180,
      headerClass: classnames(classes.headerCell),
      cellClass: classes.staticCellStyle,
    },
    {
      field: "BillBalance",
      headerName: "Bill Balance",
      headerTooltip: "Bill Balance",
      headerClass: classnames(classes.headerCell),
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: "BillPaidBalance",
      headerName: "Bill Paid Bal",
      headerTooltip: "Bill Paid Balance",
      headerClass: classnames(classes.headerCell),
      minWidth: 180,
      cellClass: classes.staticCellStyle,
    },
    {
      field: "AllotAmount",
      headerName: "Allot Amount",
      headerTooltip: "Allot Amount",
      headerClass: classnames(classes.headerCell),
      minWidth: 180,
      // editable: (params) => {
      //   return params.node.selected === true && isMember();
      // },
      valueSetter: ValueSetter,
      editable: true,
      valueGetter: valueGetter,
      cellEditor: "numericCellEditor",
      cellClass: classes.staticCellStyle,
      hide: isGuest(),
    },
  ];
  const handleSave = () => {
    if (gridref !== undefined) {
      let result = gridref.current.api.getSelectedRows();
      if (_.isEmpty(result)) {
        dispatch(
          showAdvanceSnackbar({
            msg: "select Invoice first",
            severity: "warning",
            onclose: true,
          })
        );
      } else {
        if (parseFloat(_.get(state, "AvailableAmount", 0)) - getBalance > 0) {
          // eslint-disable-next-line no-debugger
          // debugger;
          UpdateSelectedInvoice([
            ..._.filter(_.get(state, "selectedInvoice", []), (o) => {
              return o.partyid !== result[0].partyid;
            }),
            ...result,
          ]);
          dispatch(
            showAdvanceSnackbar({
              msg: "Invoice List saved",
              severity: "success",
              onclose: true,
            })
          );
        } else {
          dispatch(
            showAdvanceSnackbar({
              msg: "Amount not avail",
              severity: "warning",
              onclose: true,
            })
          );
        }
        UpdateInvoices({
          data: [],
          AlottedAmount: 0,
          vendorID: null,
        });
        setInvoiceList([]);
      }
    }
  };

  const handleSelection = (props) => {
    let result = props.api.getSelectedRows();
    if (
      _.sumBy(result, function (o) {
        return o.AllotAmount;
      }) > _.get(state, "alottedAmount", 0)
    ) {
      props.api.forEachNode((node) => {
        if (
          node.rowIndex ===
          props.api.rowModel.selectionService.lastSelectedNode.rowIndex
        )
          node.setSelected(false);
      });
    } else {
      setInvoiceList(result);
    }
  };
  let tableHeight = 250;
  return (
    <Grid
      container
      className={classes.invoiceContainer}
      id="invoiceDetails-toolbar"
    >
      <Grid container item>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" className={classes.heading}>
            Invoice Details
          </Typography>
        </Grid>
        <Grid
          item
          container
          xs={12}
          spacing={2}
          md={6}
          className={classes.invoiceToolBar}
        >
          <Grid item xs={12} md={6}>
            <Typography style={{ width: "250px" }}>
              Alloted Amount : {_.get(state, "alottedAmount", 0)}
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography style={{ width: "250px" }}>
              Balance Amount :
              {_.get(state, "alottedAmount", 0) -
                _.sumBy(InvoiceList, function (o) {
                  return o.AllotAmount;
                })}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <AgGridCustom
          getRef={gridref}
          rowData={rowData}
          columnDefs={colDef}
          // checkboxSelection={true}
          noDataTxt="No bills available"
          suppressRowClickSelection={true}
          rowSelection={"multiple"}
          height={isBelowMd ? 100 : tableHeight}
          rowHeight={_.isEqual(width, "xs") ? 10 : 40}
          frameworkComponents={{
            dateCellRenderer: withCellRenderState(dateCellRenderer),
            numericCellEditor: editableNumericCell,
          }}
          defaultColDef={{
            initialWidth: 100,
            sortable: true,
            resizable: true,
          }}
          handleCellClick={(e) => {}}
          onCellValueChanged={(e) => {
            let result = e.api.getSelectedRows();
            setInvoiceList(result);
            setTimeout(() => {
              autoSelect();
            }, [200]);
          }}
          enterMovesDown={true}
          enterMovesDownAfterEdit={true}
          onSelectionChanged={handleSelection}
        />
      </Grid>
      <Grid item className={classes.actionContainer}>
        {!_.isEmpty(rowData) && (
          <>
            {isMember() && (
              <Button className={classes.approveButton} onClick={handleSave}>
                save
              </Button>
            )}
          </>
        )}
      </Grid>
    </Grid>
  );
};
const mapStateToProps = (state) => ({
  state: state.AccountsBillsReducer,
});
const mapDispatchToProps = (dispatch) => ({
  UpdateSelectedInvoice: (data) => {
    dispatch(updateSelectedInvoice(data));
  },
  UpdateInvoices: (data) => dispatch(updateBillsInvoices(data)),
});
InvoiceTabel.propTypes = {};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withWidth()(InvoiceTabel));
