import React from "react";
import propTypes from "prop-types";
import { Divider, Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import BatchForm from "./batchDetails";
import BatchTable from "./BatchTable";
import InvoiceTable from "./InvoiceTable";
import { Link } from "react-router-dom";
const useStyles = makeStyles((theme) => ({
  container: {
    paddingLeft: theme.spacing(3),
  },
}));
const BatchInvoiceAdd = (props) => {
  const classes = useStyles();
  return (
    <div className={classes.container}>
      <Grid container>
        <Grid item xs={12} id="invoice-add-form-Container">
          <BatchForm />
          <Divider />
        </Grid>
        <Grid item xs={12} id="invoice-add-batchtable-container">
          <BatchTable />
        </Grid>
        <Grid item xs={12}>
          <InvoiceTable />
        </Grid>
      </Grid>
    </div>
  );
};

BatchInvoiceAdd.propTypes = {};

export default BatchInvoiceAdd;
