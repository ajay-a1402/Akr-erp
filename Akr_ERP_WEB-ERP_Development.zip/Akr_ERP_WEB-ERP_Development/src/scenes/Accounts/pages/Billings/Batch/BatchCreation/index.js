import { Box, Grid, Toolbar, Typography } from "@material-ui/core";
import classNames from "classnames";
import BillForm from "./batchForm";
import BillTable from "./BillTable";
import { makeStyles } from "@material-ui/core/styles";
import { useRef, useEffect, useState } from "react";

const useStyles = makeStyles((theme) => ({
  rootContainer: {
    paddingLeft: theme.spacing(1),
  },
}));

const BatchCreate = () => {
  const classes = useStyles();
  const tableRef = useRef();
  const formContainerRef = useRef();
  const [formcontainerprops, setFormContainerProps] = useState({
    height: null,
  });
  useEffect(() => {
    if (formContainerRef.current)
      setFormContainerProps((prev) => ({
        ...prev,
        height: formContainerRef.current.clientHeight,
      }));
  }, []);
  return (
    <Box className={classes.rootContainer}>
      <Grid container>
        <Grid item xs={12} innerRef={formContainerRef}>
          <BillForm tableRef={tableRef} />
        </Grid>
        <Grid item xs={12}>
          <BillTable
            tableRef={tableRef}
            formcontainerprops={formcontainerprops}
          />
        </Grid>
      </Grid>
    </Box>
  );
};
export default BatchCreate;
