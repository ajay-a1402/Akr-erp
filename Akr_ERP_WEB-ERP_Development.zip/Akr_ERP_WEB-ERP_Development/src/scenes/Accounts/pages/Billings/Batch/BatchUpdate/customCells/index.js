import _ from 'lodash';
import React, { useState, useImperativeHandle } from 'react';
import { Icon, IconButton, useTheme } from '@material-ui/core';
import { convertGmtToLocalTime } from '../../../../../../../com_utils';
import moment from 'moment';
import propTypes from 'prop-types';
export const withCellRenderState = (CellRenderer) => {
  // eslint-disable-next-line react/display-name
  return React.forwardRef((props, ref) => {
    /* eslint-disable react/prop-types */

    const [value, setValue] = useState(props.value);

    useImperativeHandle(ref, () => {
      return {
        refresh: (params) => {
          if (params.value !== value) {
            setValue(params.value);
          }
          return true;
        },
      };
    });
    return <CellRenderer {...props}></CellRenderer>;
  });
};
withCellRenderState.propTypes = {
  value: propTypes.object,
};
export const dateCellRenderer = (props) => {
  const { value, data } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  return (
    <div className={containerClassName}>
      <span>
        {data
          ? moment(convertGmtToLocalTime(data.BDate)).format('DD-MM-YYYY')
          : ''}
      </span>
    </div>
  );
};
dateCellRenderer.propTypes = {
  value: propTypes.any,
};
export const approveCellRenderer = (props) => {
  const { value, data } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  return (
    <div className={containerClassName}>
      <span>
        <Icon style={{ color: value && 'green' }}>
          {value ? `task_alt` : `dangerous`}
        </Icon>
      </span>
    </div>
  );
};
approveCellRenderer.propTypes = {
  value: propTypes.any,
};
export const deleteCellRenderer = (props) => {
  const { value, data } = props;
  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  const onClickDelete = _.get(props, 'colDef.cellRendererParams.onClickDelete');
  return (
    <div className={containerClassName}>
      <IconButton
        onClick={() => {
          onClickDelete(data);
        }}
      >
        <Icon>delete_outline</Icon>
      </IconButton>
    </div>
  );
};
deleteCellRenderer.propTypes = {
  value: propTypes.any,
};
