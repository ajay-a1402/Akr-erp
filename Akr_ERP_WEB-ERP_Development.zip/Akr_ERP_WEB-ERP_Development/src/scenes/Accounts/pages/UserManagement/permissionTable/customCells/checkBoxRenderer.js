import _ from 'lodash';
import React, {
  useState,
  useImperativeHandle,
  useEffect,
  useRef,
  forwardRef,
} from 'react';
import { useTheme, Checkbox } from '@material-ui/core';
import moment from 'moment';
import propTypes from 'prop-types';
// eslint-disable-next-line react/display-name
export default forwardRef((props, ref) => {
  /* eslint-disable react/prop-types */
  const [value, setValue] = useState(props.value);

  const containerClassName = _.get(
    props,
    'colDef.cellRendererParams.containerClass'
  );
  const disableClick = _.get(
    props,
    'colDef.cellRendererParams.disableClick',
    false
  );
  useEffect(() => {
    let colId = props.column.colId;
    props.node.setDataValue(colId, value);
  }, [value]);

  useImperativeHandle(ref, () => {
    return {
      getValue() {
        return value;
      },

      myCustomFunction() {
        return {
          rowIndex: props.rowIndex,
          colId: props.column.getId(),
        };
      },
    };
  });

  return (
    <div className={containerClassName}>
      <Checkbox
        checked={value}
        disabled={disableClick}
        onChange={(e) => {
          setValue(() => {
            if (e.target.checked) {
              return 1;
            } else {
              return 0;
            }
          });
        }}
      />
    </div>
  );
});

export const withCellRenderState = (CellRenderer) => {
  // eslint-disable-next-line react/display-name
  return React.forwardRef((props, ref) => {
    /* eslint-disable react/prop-types */

    const [value, setValue] = useState(props.value);

    useImperativeHandle(ref, () => {
      return {
        refresh: (params) => {
          if (params.value !== value) {
            setValue(params.value);
          }
          return true;
        },
      };
    });
    return <CellRenderer {...props}></CellRenderer>;
  });
};
withCellRenderState.propTypes = {
  value: propTypes.object,
};
