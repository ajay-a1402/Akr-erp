import { Typography, Box, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import SADEMOJI from '../../../../assets/emojiSad.png';
import React from 'react';
const useStyles = makeStyles((theme) => ({
  Container: {
    display: 'flex',
    justifyContent: 'center',
    // height: '100VH',
    padding: theme.spacing(6, 4),
  },
  pagetext: {},
  imageWrapper: {
    textAlign: '-webkit-center',
    width: 'inherit',
    [theme.breakpoints.up('sm')]: {
      textAlign: '-webkit-right',
    },
  },
  pageImg: {
    backgroundImage: `url(${SADEMOJI})`,
    height: '150px',
    width: '150px',
    backgroundSize: 'cover',
  },
}));
const AuthFail = () => {
  const classes = useStyles();
  return (
    <Box className={classes.Container}>
      <div>
        <Grid container>
          <Grid item md={4} className={classes.imageWrapper}>
            <div className={classes.pageImg}></div>
          </Grid>
          <Grid item md={8}>
            <Typography variant='h1'>401</Typography>
            <Typography variant='h5'>OOPS! Unauthorized</Typography>

            <Typography>
              Sorry but the page you are looking for is still exist. You need to
              login again...
            </Typography>
          </Grid>
        </Grid>
      </div>
    </Box>
  );
};

export default AuthFail;
