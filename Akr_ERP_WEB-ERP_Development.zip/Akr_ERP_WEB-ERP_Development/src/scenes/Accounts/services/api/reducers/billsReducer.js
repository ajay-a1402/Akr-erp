import { ACTION_TYPES } from '../../../../../constants';
import * as _ from 'lodash';
const defaultState = {
  // batchDetails: {},
  selectedInvoice: [],
  batch: null,
  batchAmount: 0,
  selectedVendors: [],
  invoiceList: null,
  alottedAmount: null,
  vendorID: null,
  AvailableAmount: 0,
};

const AccountsBillsReducer = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.CHANGE_BATCH: {
      return {
        ...state,
        batch: action.payload,
      };
    }
    case ACTION_TYPES.UPDATE_BILLS_AVAIL_AMOUNT: {
      return {
        ...state,
        AvailableAmount: action.payload,
      };
    }
    case ACTION_TYPES.UPDATE_BILLS_INVOICE_LIST: {
      return {
        ...state,
        invoiceList: _.get(action.payload, 'data', []),
        alottedAmount: _.get(action.payload, 'AlottedAmount', null),
        vendorID: _.get(action.payload, 'vendorID', null),
      };
    }
    case ACTION_TYPES.UPDATE_REVIEW_INVOICE_LIST: {
      return {
        ...state,
        reviewState: {
          invoiceList: _.get(action.payload, 'data', []),
          alottedAmount: _.get(action.payload, 'AlottedAmount', null),
          vendorID: _.get(action.payload, 'vendorID', null),
        },
      };
    }
    case ACTION_TYPES.UPDATE_SELECTED_INVOICE: {
      return {
        ...state,
        selectedInvoice: action.payload,
      };
    }
    case ACTION_TYPES.UPDATE_BATCH_LIST: {
      return {
        ...state,
        batchDetails: action.payload,
      };
    }
    default:
      return state;
  }
};
export default AccountsBillsReducer;
