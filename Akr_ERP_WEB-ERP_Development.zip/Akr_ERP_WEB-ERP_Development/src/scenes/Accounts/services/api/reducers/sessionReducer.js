import { ACTION_TYPES } from '../../../../../constants';
import * as _ from 'lodash';
const defaultState = {
  userDetails: {},
  isAuthenticated: false,
};

const AccountsSessionReducer = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.UPDATE_ACCOUNTS_SESSION: {
      return {
        ...state,
        userDetails: _.get(action.payload, 'details', {}),
        isAuthenticated: _.get(action.payload, 'isAuthenticated', false),
      };
    }
    default:
      return state;
  }
};
export default AccountsSessionReducer;
