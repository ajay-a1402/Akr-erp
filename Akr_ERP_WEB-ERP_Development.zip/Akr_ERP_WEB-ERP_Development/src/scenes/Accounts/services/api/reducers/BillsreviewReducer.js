import { ACTION_TYPES } from '../../../../../constants';
import * as _ from 'lodash';
const defaultState = {
  reviewState: {
    invoiceList: null,
    alottedAmount: null,
    vendorID: null,
  },
};

const AccountsBillsReviewReducer = (state = defaultState, action) => {
  switch (action.type) {
    case ACTION_TYPES.UPDATE_REVIEW_INVOICE_LIST: {
      return {
        ...state,
        reviewState: {
          invoiceList: _.get(action.payload, 'data', []),
          alottedAmount: _.get(action.payload, 'AlottedAmount', null),
          vendorID: _.get(action.payload, 'vendorID', null),
        },
      };
    }
    default:
      return state;
  }
};
export default AccountsBillsReviewReducer;
