/* eslint-disable no-use-before-define */
import React, { useEffect, useRef } from 'react';
import { useTheme, alpha, makeStyles } from '@material-ui/core/styles';
import Popper from '@material-ui/core/Popper';
import propTypes from 'prop-types';
import CloseIcon from '@material-ui/icons/Close';
import DoneIcon from '@material-ui/icons/Done';
import Autocomplete from '@material-ui/lab/Autocomplete';
import * as _ from 'lodash';
import {
  Box,
  Icon,
  InputBase,
  ButtonBase,
  Typography,
  IconButton,
  Chip,
} from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    // width: 221,
    fontSize: 13,
  },
  selectButton: {
    fontSize: 13,
    width: '100%',
    display: 'flex',
    textAlign: 'left',
    justifyContent: 'center',
    padding: '8px 8px',
    backgroundColor: theme.palette.grey[100],
    color: '#586069',
    fontWeight: 600,
    '&:hover,&:focus': {
      color: theme.palette.almostBlack[0],
      backgroundColor: theme.palette.grey[800],
    },
    '& p': {
      width: '100%',
      fontWeight: 600,
    },
    '& svg': {
      width: 16,
      height: 16,
    },
  },
  tag: {
    marginTop: 3,
    // height: 20,
    padding: '.15em 4px',
    fontWeight: 600,
    lineHeight: '15px',
    borderRadius: 2,
    backgroundColor: theme.palette.grey[400],
  },
  popper: {
    border: '1px solid rgba(27,31,35,.15)',
    boxShadow: '0 3px 12px rgba(27,31,35,.15)',
    borderRadius: 3,
    width: 300,
    zIndex: 1,
    fontSize: 13,
    color: '#586069',
    backgroundColor: '#f6f8fa',
  },
  header: {
    borderBottom: '1px solid #e1e4e8',
    padding: '8px 10px',
    fontWeight: 600,
  },
  inputBase: {
    padding: 10,
    width: '100%',
    borderBottom: '1px solid #dfe2e5',
    '& input': {
      borderRadius: 4,
      backgroundColor: theme.palette.common.white,
      padding: 8,
      transition: theme.transitions.create(['border-color', 'box-shadow']),
      border: '1px solid #ced4da',
      fontSize: 14,
      '&:focus': {
        boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
        borderColor: theme.palette.primary.main,
      },
    },
  },
  paper: {
    boxShadow: 'none',
    margin: 0,
    color: '#586069',
    fontSize: 13,
  },
  option: {
    minHeight: 'auto',
    alignItems: 'flex-start',
    padding: 8,
    '&[aria-selected="true"]': {
      backgroundColor: 'transparent',
    },
    '&[data-focus="true"]': {
      backgroundColor: theme.palette.action.hover,
    },
  },
  popperDisablePortal: {
    position: 'relative',
  },
  iconSelected: {
    width: 17,
    height: 17,
    marginRight: 5,
    marginLeft: -2,
  },
  color: {
    width: 14,
    height: 14,
    flexShrink: 0,
    borderRadius: 3,
    marginRight: 8,
    marginTop: 2,
  },
  text: {
    flexGrow: 1,
  },
  close: {
    opacity: 0.6,
    width: 18,
    height: 18,
  },
  listBox: {
    maxHeight: '150px',
    overflowX: 'hidden',
    width: '100%',
    padding: theme.spacing(2, 0.5),
    '&::-webkit-scrollbar': {
      width: '0.4em',
    },
    '&::-webkit-scrollbar-track': {
      boxShadow: 'inset 0 0 6px rgba(0,0,0,0.00)',
      webkitBoxShadow: 'inset 0 0 6px rgba(0,0,0,0.00)',
    },
    '&::-webkit-scrollbar-thumb': {
      background: 'linear-gradient(180deg, #D0368A 0%, #708AD4 99%)',
      boxshadow: 'inset 2px 2px 5px 0 rgba(#fff, 0.5)',
      borderRadius: '100px',
    },
  },
  chips: {
    margin: theme.spacing(1, 1),
    fontSize: '12px',
    height: 'Auto',
    '& .MuiChip-label': {
      whiteSpace: 'pre-wrap',
    },
  },
}));

export default function AutocompleteWithChip(props) {
  const {
    options,
    label,
    description,
    icon,
    loading,
    selected,
    SectionHeight,
    deleteSelected,
    updateSelected,
  } = props;
  const classes = useStyles();
  const ref = useRef(null);
  const [anchorEl, setAnchorEl] = React.useState(null);

  const [key, setKey] = React.useState('');
  const [pendingValue, setPendingValue] = React.useState([]);
  const theme = useTheme();

  const handleClick = (event) => {
    setPendingValue(selected);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (event, reason) => {
    if (reason === 'toggleInput') {
      return;
    }
    updateSelected(pendingValue);
    if (anchorEl) {
      anchorEl.focus();
    }
    setAnchorEl(null);
  };
  const onChangeKey = (e) => {
    setKey(e.target.value);
  };
  const open = Boolean(anchorEl);
  const id = open ? 'github-label' : undefined;

  //handle detelete value from the display chip
  const handleDelete = (chipToDelete) => {
    deleteSelected(chipToDelete);
  };
  return (
    <React.Fragment>
      <div className={classes.root}>
        <ButtonBase
          disableRipple
          className={classes.selectButton}
          aria-describedby={id}
          onClick={handleClick}
          ref={ref}
          title={label + '- title'}
        >
          <Typography>{label}</Typography>
          <Icon>{icon}</Icon>
        </ButtonBase>
        <Box
          className={classes.listBox}
          style={{ Height: SectionHeight + 'px' }}
        >
          {_.isEmpty(selected) ? (
            <Typography>No vendor Selected</Typography>
          ) : (
            selected.map((label) => (
              // <div
              //   key={label.name}
              //   className={classes.tag}
              //   // style={{
              //   //   backgroundColor: theme.palette.grey[600],
              //   //   color: theme.palette.getContrastText(label.color),
              //   // }}
              // >
              //   {label.Label}
              // </div>
              <Chip
                key={label.Id}
                label={label.Label}
                variant='outlined'
                className={classes.chips}
                onDelete={() => {
                  handleDelete(label);
                }}
                color='primary'
                deleteIcon={<CloseIcon />}
              />
            ))
          )}
        </Box>
      </div>
      <Popper
        id={id}
        open={open}
        anchorEl={anchorEl}
        placement='bottom-start'
        style={{
          width: _.get(ref.current, 'offsetWidth', 150),
        }}
        className={classes.popper}
      >
        <div className={classes.header}>{description}</div>

        <Autocomplete
          open
          multiple
          onClose={handleClose}
          classes={{
            paper: classes.paper,
            option: classes.option,
            popperDisablePortal: classes.popperDisablePortal,
          }}
          value={pendingValue}
          onChange={(event, newValue) => {
            setPendingValue(newValue);
          }}
          disableCloseOnSelect
          disablePortal
          renderTags={() => null}
          noOptionsText='No labels'
          loading={loading}
          renderOption={(option, { selected }) => (
            <React.Fragment>
              <DoneIcon
                className={classes.iconSelected}
                style={{ visibility: selected ? 'visible' : 'hidden' }}
              />
              {/* <span
                className={classes.color}
                style={{ backgroundColor: option.color }}
              /> */}
              <div className={classes.text}>
                {option.Label}
                {/* <br />
                {option.description} */}
              </div>
              <CloseIcon
                className={classes.close}
                style={{ visibility: selected ? 'visible' : 'hidden' }}
              />
            </React.Fragment>
          )}
          options={_.uniq([...options, ...selected]).sort((a, b) => {
            // Display the selected labels first.
            let ai = selected.indexOf(a);
            ai = ai === -1 ? selected.length + options.indexOf(a) : ai;
            let bi = selected.indexOf(b);
            bi = bi === -1 ? selected.length + options.indexOf(b) : bi;
            return ai - bi;
          })}
          getOptionLabel={(option) => option.Label}
          renderInput={(params) => (
            <>
              <InputBase
                ref={params.InputProps.ref}
                inputProps={params.inputProps}
                autoFocus
                className={classes.inputBase}
                onChange={onChangeKey}
              />
            </>
          )}
        />
      </Popper>
    </React.Fragment>
  );
}

// function getRandomColor() {
//   var letters = '0123456789ABCDEF';
//   var color = '#';
//   for (var i = 0; i < 6; i++) {
//     color += letters[Math.floor(Math.random() * 16)];
//   }
//   return color;
// }

AutocompleteWithChip.propTypes = {
  options: propTypes.array.isRequired,
  label: propTypes.string.isRequired,
  description: propTypes.string,
  icon: propTypes.string,
  loading: propTypes.bool.isRequired,
  params: propTypes.string,
  selected: propTypes.array,
  SectionHeight: propTypes.string,
  deleteSelected: propTypes.func,
  updateSelected: propTypes.func,
};
// From https://github.com/abdonrd/github-labels
