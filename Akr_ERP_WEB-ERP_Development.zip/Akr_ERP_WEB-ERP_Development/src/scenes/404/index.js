import React from 'react';
import { Typography, Box, Grid } from '@material-ui/core';
import SearchPage from '../../assets/pagenotfound.png';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  Container: {
    display: 'flex',
    justifyContent: 'center',
    // height: '100VH',
    padding: theme.spacing(6, 4),
  },
  pagetext: {},
  imageWrapper: {
    textAlign: '-webkit-center',
    width: 'inherit',
    [theme.breakpoints.up('sm')]: {
      textAlign: '-webkit-right',
    },
  },
  pageImg: {
    backgroundImage: `url(${SearchPage})`,
    height: '300px',
    width: '250px',
    backgroundSize: 'cover',
  },
}));
const PageNotFound = () => {
  const classes = useStyles();

  return (
    <Box className={classes.Container}>
      <div>
        <Grid container>
          <Grid item md={4} className={classes.imageWrapper}>
            <div className={classes.pageImg}></div>
          </Grid>
          <Grid item md={8}>
            <Typography variant='h1'>404</Typography>
            <Typography variant='h5'>OOPS! Page Not Found</Typography>

            <Typography>
              Sorry but the page you are looking for does not exist, have been
              removed. name changed or is temporarily unavailable
            </Typography>
          </Grid>
        </Grid>
      </div>
    </Box>
  );
};

export default PageNotFound;
