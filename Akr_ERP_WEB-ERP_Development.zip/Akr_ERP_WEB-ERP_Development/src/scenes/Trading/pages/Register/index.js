import React, { useEffect, useMemo, useCallback, useRef } from 'react';
import propTypes from 'prop-types';
import * as Yup from 'yup';

import { Formik, Field, Form } from 'formik';
import * as _ from 'lodash';
import { TextField, Box, Typography, Button } from '@material-ui/core';
// import CustomForm from '../../../../com_components/CustomForm';
const fieldDefs = [
  {
    label: 'First Name',
    type: 'text',
    field: 'firstname',
    fieldClass: '',
  },
  {
    label: 'last Name',
    field: 'lastname',
    type: 'text',
    fieldClass: '',
  },
];
const ActionsDef = [{}];
const RegistrationForm = () => {
  const initialValues = { firstname: '', lastname: '' };
  const formRef = useRef([]);
  const validationSchema = Yup.object().shape({
    firstname: Yup.string()
      .min(2, 'Too Short!')
      .max(70, 'Too Long!')
      .required('Required'),
    lastname: Yup.string().required('Required'),
  });
  formRef.current = _.map(
    fieldDefs,
    (field, idx) => (formRef.current[idx] = React.createRef())
  );
  console.log('forem', formRef);
  return (
    <div>
      <Formik initialValues={initialValues} validationSchema={validationSchema}>
        {({ errors, touched, handleSubmit }) => (
          <>
            <Box>
              {_.map(fieldDefs, (field, idx) => (
                <Box key={idx}>
                  <Typography>{field.label}</Typography>
                  <TextField
                    className={field.fieldClass}
                    name={field.field}
                    ref={formRef.current[idx]}
                    error={touched[field.field] && Boolean(errors[field.field])}
                    type={field.type}
                    {...field.fieldProps}
                  />
                </Box>
              ))}
            </Box>
            <Box>
              <Button onClick={handleSubmit} onKeyDown={handleSubmit}>
                Submit
              </Button>
              <Button onClick={handleSubmit} onKeyDown={handleSubmit}>
                Clear
              </Button>
            </Box>
          </>
        )}
      </Formik>
    </div>
  );
};
export default RegistrationForm;
RegistrationForm.prototype;
