export const ROLE_MODULES = {
  SLOT_DASHBOARD: 'slotDashBoard',
  USER_MANAGEMENT: 'userMangement',
  ACCOUNTS_MANAGEMENT: 'accountsManagement',
};

export const ROLE_MODULES_LABEL = {
  [ROLE_MODULES.DASHBOARDS]: 'Slot DashBoard',
  [ROLE_MODULES.USER_MANAGEMENT]: 'User ManageMent',
  [ROLE_MODULES.ACCOUNTS_MANAGEMENT]: 'Accounts ManageMent',
};
