import React, { useEffect } from 'react';
import wishBackground from '../assets/wishbackground.jpg';
import { Typography, Box } from '@material-ui/core';
import Axios from 'axios';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import { Fireworks, useFireworks } from 'fireworks-js/dist/react';
import { useParams } from 'react-router-dom';
const CustomColor = withStyles({
  root: {
    background: '-webkit-linear-gradient(45deg, #de6262   30%, #ffb88c 90%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
})(Typography);

const useStyles = makeStyles((theme) => ({
  rooContainer: {
    backgroundImage: `url(${wishBackground})`,
    backgroundSize: 'cover',
    // background: '#000',
    height: '100Vh',
    top: 0,
    left: 0,
    width: '100%',
  },
  fireWork: {
    height: '95Vh',
    width: '100vW',
    position: 'absolute',
  },
  TextContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    flexDirection: 'column',
    alignItems: 'center',
    height: '100Vh',
  },
  wishes: {
    color: '#42f5e0',
    textAlign: 'center',
    fontFamily: `'Rock 3D', cursive`,
    fontSize: '50px',
    [theme.breakpoints.down('md')]: {
      fontSize: '25px',
      padding: theme.spacing(2),
    },
  },
  Quotes: {
    fontFamily: `'Moon Dance', cursive`,
    fontWeight: 900,
    fontSize: '50px',
    [theme.breakpoints.down('md')]: {
      fontSize: '25px',
      padding: theme.spacing(2),
    },
  },
  footer: {
    color: '#fcfcf7',
  },
  footerText: {
    //   textTransform: 'uppercase',
    //   backgroundImage: `linear-gradient(to right, #eddfa6, #f2dad3, #f5dff3, #ecedc0)`,
    //   WebkitBackgroundClip: 'text',
    //   backgroundClip: 'text',
    //   color: 'transparent',
    //   backgroundSize: '10%',
    //   backgroundPosition: ' -100%',
    //   fontWeight: 900,
    //   animation: `animatedText 5s infinite alternate-reverse`,
  },
  // '@keyframes animatedText': {
  //   to: {
  //     backgroundPosition: '100%',
  //   },
  // },
}));
const WishesPage = () => {
  const classes = useStyles();
  let { id } = useParams();

  useEffect(() => {
    id &&
      Axios.get(
        // eslint-disable-next-line no-undef
        `${process.env.REACT_APP_BACKEND_API_PROXY}/newYear//getWish`,
        {
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
          timeout: 5000,
          params: { id: id },
        }
      )
        .then(() => {})
        .catch(() => {});
  }, []);
  const { enabled, options } = useFireworks({
    initialStart: true,
    initialOptions: {
      hue: {
        min: 0,
        max: 345,
      },
      delay: {
        min: 15,
        max: 15,
      },
      rocketsPoint: 50,
      speed: 2,
      acceleration: 1,
      friction: 0.96,
      gravity: 1,
      particles: 200,
      trace: 2,
      explosion: 20,
      autoresize: true,
      brightness: {
        min: 50,
        max: 80,
        decay: {
          min: 0.015,
          max: 0.03,
        },
      },
      boundaries: {
        visible: false,
      },
      sound: {
        enabled: false,
        files: [
          'https://fireworks.js.org/sounds/explosion0.mp3',
          'https://fireworks.js.org/sounds/explosion1.mp3',
          'https://fireworks.js.org/sounds/explosion2.mp3',
        ],
        volume: {
          min: 1,
          max: 2,
        },
      },
      mouse: {
        click: false,
        move: false,
        max: 1,
      },
    },
  });

  return (
    <div className={classes.rooContainer}>
      <Fireworks
        className={classes.fireWork}
        enabled={enabled}
        options={options}
      />
      {/* <img src={newYearFont} /> */}
      <Box className={classes.TextContainer}>
        <div></div>
        <div>
          <CustomColor className={classes.Quotes}>
            New Year’s Day is the first page in a blank book: Write a phenomenal
            story!
          </CustomColor>
          <Typography className={classes.wishes}>
            Happy new year <span>2022 !</span>
          </Typography>
        </div>
        <div className={classes.footer}>
          <Typography variant='caption' className='footerText'>
            By Team ERP
          </Typography>
        </div>
      </Box>
    </div>
  );
};

export default WishesPage;
