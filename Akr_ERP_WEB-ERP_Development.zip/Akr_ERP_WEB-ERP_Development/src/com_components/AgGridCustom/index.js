import React, { useRef, useCallback, useEffect, useState } from "react";
import propTypes from "prop-types";
import ReactResizeDetector from "react-resize-detector";
import { makeStyles } from "@material-ui/core/styles";
import classnames from "classnames";
import _ from "lodash";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-material.css";
import LoadingIndicator from "../LoadingIndicator";

const TABLE_HEADER_HEIGHT = 30;

const useStyles = makeStyles((theme) => ({
  table: (props) => ({
    position: "relative",
    height: "100VH",
    "&.ag-theme-material": {
      "& ::-webkit-scrollbar, ::-webkit-scrollbar-track": {
        width: "10px",
        height: "10px",
        "-webkit-appearance": "none",
        backgroundColor: _.get(
          props,
          "scrollBar.trackColor",
          "rgba(255, 255, 255, 0)"
        ), //, //'transparent'
      },
      "& ::-webkit-scrollbar-thumb": {
        backgroundColor: _.get(
          props,
          "scrollBar.thumbColor",
          "rgba(213, 213, 220, 1)"
        ), //theme.palette.almostBlack[400],
        height: "80px",
        borderRadius: "5px",
      },
    },
    "& .ag-header": {
      textTransform: "uppercase",
      letterSpacing: "2px",
      fontSize: theme.typography.pxToRem(11),
      background: _.get(props, "tableStyles.headerBgColor"),

      "& .ag-pinned-left-header": {
        cursor: "not-allowed",
        backgroundColor: theme.palette.grey[500],
      },
    },
    "&.ag-theme-material .ag-header-cell": {
      color: _.get(props, "tableStyles.headerTxtColor"),
    },
    "&.ag-theme-material .ag-cell": {
      fontSize: theme.typography.pxToRem(14),
      paddingRight: "0px",
      paddingLeft: "1px",
      "& .ag-react-container": {
        height: "100%",
        "& div": {
          "white-space": "nowrap",
          "text-overflow": "ellipsis",
          overflow: "hidden",
        },
      },
    },
    "&.ag-theme-material .ag-cell-focus": {
      borderColor: "none",
      backgroundColor: "none",
      border: "none !important",
      color: theme.palette.primary.main,
    },
    "&.ag-theme-material .ag-cell-not-inline-editing": {
      border: "none",
    },

    "&.ag-theme-material .ag-row": {
      background: _.get(props, "tableStyles.rowBgColor"),
      color: _.get(props, "tableStyles.rowTxtColor"),
      borderColor: _.get(props, "tableStyles.rowSeparatorColor"),
      cursor: "pointer",
      // backgroundColor: '#b7c7bb',

      "& .ag-cell-last-left-pinned": {
        cursor: "not-allowed",
        backgroundColor: theme.palette.grey[500],
      },
    },
    "&.ag-theme-material .ag-row:hover": {
      backgroundColor: theme.palette.grey[50],
      // backgroundColor: 'rgba(250,250,251,1)',
    },
  }),
  loaderContainer: {
    position: "absolute",
    top: TABLE_HEADER_HEIGHT,
    paddingTop: theme.spacing(2),
    width: "100%",
    height: "100%",
    textAlign: "center",
    background: theme.palette.common.white,
  },
}));

const AgGridCustom = (props) => {
  const {
    columnDefs,
    rowData,
    onRowClicked,
    defaultColDef,
    handleCellClick,
    loading,
    rowHeight,
    frameworkComponents,
    selectionFunction,
    noDataTxt,
    height,
    getRef,
    // eslint-disable-next-line no-unused-vars
    ...rest
  } = props;

  const gridOptions = useRef();

  const [gridApi, setGridApi] = useState(null);

  const setOrUnsetResizeColsToFit = useCallback(
    (sizeColumnsToFit, gridApi, columnApi) => {
      if (!sizeColumnsToFit) columnApi.autoSizeAllColumns(false);
      else gridApi.sizeColumnsToFit();
    },
    [gridApi]
  );

  const updateRowData = useCallback(
    (rowData, gridApi, columnApi) => {
      gridApi?.setRowData(rowData);
      gridApi?.setColumnDefs(columnDefs);
      setOrUnsetResizeColsToFit(true, gridApi, columnApi);
    },
    [setOrUnsetResizeColsToFit]
  );

  useEffect(() => {
    if (_.get(gridOptions, "current.api")) {
      updateRowData(
        rowData,
        gridOptions.current.api,
        gridOptions.current.columnApi
      );
    }
  }, [rowData, updateRowData]);

  const [currentWidth, setCurrentWidth] = useState(null);

  useEffect(() => {
    if (_.get(gridOptions, "current.api")) {
      const gridApi = gridOptions.current.api;
      const gridColApi = gridOptions.current.columnApi;
      gridApi.setColumnDefs(columnDefs);
      gridApi.resetRowHeights();

      setOrUnsetResizeColsToFit(true, gridApi, gridColApi);
    }
  }, [columnDefs, setOrUnsetResizeColsToFit, currentWidth]);

  const onResizeLayout = (width) => {
    setCurrentWidth(width);
  };
  const onGridReady = useCallback(
    (params) => {
      gridOptions.current = params;
      setTimeout(() => {
        if (getRef !== undefined) {
          getRef.current = params;
        }
      }, 2000);

      setGridApi(params.api);

      setOrUnsetResizeColsToFit(true, params.api, params.columnApi);
    },
    [setOrUnsetResizeColsToFit]
  );

  const classes = useStyles({
    tableStyles: {
      headerBgColor: "rgba(158,156,156,0.08)",
      headerTxtColor: "rgba(68,68,79,1)",
      rowBgColor: "rgba(255,255,255,1)",
      rowTxtColor: "rgba(0,0,0,0.87)",
      rowSeparatorColor: "rgba(226,226,226,1)",
    },
    scrollBar: {
      trackColor: "rgba(255, 255, 255, 0)",
      thumbColor: "rgba(213, 213, 220, 1)",
    },
  });

  const onCellClicked = (e) => {
    if (!e.column.colDef.disableClickSelection) {
      handleCellClick(e);
    } else {
      e.api.gridOptionsWrapper.gridOptions.suppressRowClickSelection = false;
    }
  };

  return (
    <div
      className={classnames("ag-theme-material", classes.table)}
      style={{ height: `${height}px` }}
    >
      <AgGridReact
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        sizeColumnsToFit
        enableCellChangeFlash={false}
        rowData={rowData}
        frameworkComponents={frameworkComponents}
        animateRows
        onGridReady={onGridReady}
        headerHeight={30}
        onRowClicked={onRowClicked && onRowClicked}
        onCellClicked={onCellClicked}
        rowHeight={rowHeight}
        overlayNoRowsTemplate={noDataTxt ? noDataTxt : null}
        suppressDragLeaveHidesColumns
        tooltipShowDelay={0}
        {...rest}
      >
        {props.children}
      </AgGridReact>

      {loading && (
        <div className={classes.loaderContainer}>
          <LoadingIndicator></LoadingIndicator>
        </div>
      )}
      <ReactResizeDetector handleWidth handleHeight onResize={onResizeLayout} />
    </div>
  );
};

AgGridCustom.propTypes = {
  columnDefs: propTypes.array,
  rowData: propTypes.array.isRequired,
  loading: propTypes.bool,
  onRowClicked: propTypes.func,
  rowHeight: propTypes.number,
  frameworkComponents: propTypes.object,
  disableClickSelectionRenderers: propTypes.arrayOf(propTypes.string),
  noDataTxt: propTypes.string,
  defaultColDef: propTypes.any,
  handleCellClick: propTypes.func,
  children: propTypes.any,
  height: propTypes.number,
};

export default AgGridCustom;
