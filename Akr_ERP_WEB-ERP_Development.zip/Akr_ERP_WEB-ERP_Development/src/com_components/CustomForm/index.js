import React, { useEffect, useMemo, useCallback } from 'react';
import { TextField, Box, Typography } from '@material-ui/core';
import { Formik, Field, Form } from 'formik';
import propTypes from 'prop-types';
import * as _ from 'lodash';
export default function CustomForm(props) {
  const { fieldDefs, initialValues } = props;

  return (
    <div>
      <Formik initialValues={initialValues}>
        {({ errors, touched }) => (
          <>
            <Box>
              {_.map(fieldDefs, (field, idx) => (
                <Box key={idx}>
                  <Typography>{field.label}</Typography>
                  <TextField
                    className={field.fieldClass}
                    type={field.type}
                    {...field.fieldProps}
                  />
                </Box>
              ))}
            </Box>
          </>
        )}
      </Formik>
    </div>
  );
}

CustomForm.propTypes = {
  fieldDefs: propTypes.arrayOf(propTypes.object).isRequired,
};
const fieldDefsProps = {
  label: propTypes.string,
  type: propTypes.string,
  fieldClass: propTypes.string,
  fieldProps: propTypes.array,
};
