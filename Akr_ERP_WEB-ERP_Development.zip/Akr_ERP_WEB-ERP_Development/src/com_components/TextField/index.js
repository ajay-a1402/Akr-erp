import React from 'react';
import TextField from '@mui/material/TextField';
import _ from 'lodash';
import propTypes from 'prop-types';
import classnames from 'classnames';
export default function InputField(props) {
  const {
    field,
    form,
    type,
    label,
    disabled,
    inputProps,
    autoFocus,
    margin,
    multiple,
    rows,
    placeholder,
    InputProps,
    size = 'medium',
    fieldValue,
    fullWidth,
    ref,
    customClass,
    onKeyDown,
  } = props;
  const err = _.get(form.errors, field.name);
  const isTouched = _.get(form.touched, field.name);
  const value = _.get(form.values, field.name);
  return (
    <TextField
      name={field.name}
      error={Boolean(err && isTouched)}
      type={type}
      className={classnames(customClass, 'Custom-input-field')}
      id={field.name}
      label={label}
      inputRef={ref}
      onKeyDown={onKeyDown}
      onChange={field.onChange}
      onBlur={field.onBlur}
      value={fieldValue ? fieldValue : value}
      autoFocus={autoFocus}
      helperText={err && isTouched && String(err)}
      // eslint-disable-next-line no-extra-boolean-cast
      margin={!!margin ? margin : 'normal'}
      size={size}
      variant='outlined'
      placeholder={placeholder}
      multiline={multiple ? true : false}
      rows={rows ? rows : ''}
      fullWidth={fullWidth}
      inputProps={{
        readOnly: Boolean(disabled),
        ...inputProps,
      }}
      InputProps={InputProps}
    />
  );
}
InputField.propTypes = {
  field: propTypes.object.isRequired,
  form: propTypes.object,
  type: propTypes.string.isRequired,
  label: propTypes.String,
  disabled: propTypes.bool,
  inputProps: propTypes.object,
  autoFocus: propTypes.bool,
  margin: propTypes.string,
  multiple: propTypes.bool,
  rows: propTypes.string,
  placeholder: propTypes.string,
  InputProps: propTypes.objec,
  size: propTypes.string,
  fieldValue: propTypes.any,
  fullWidth: propTypes.bool,
  ref: propTypes.any,
  customClass: propTypes.any,
  nextRef: propTypes.any,
};
