/* eslint-disable no-console */
export function setSessionStorageItem(key, value) {
  try {
    sessionStorage.setItem(key, value);
  } catch (e) {
    console.error(
      'ERROR OCCURED WHILE SETTING LOCAL STORAGE ITEM',
      'KEY',
      key,
      'VALUE',
      value,
      e
    );
  }
}

export function removeSessionStorageItem(key) {
  try {
    sessionStorage.removeItem(key);
  } catch (e) {
    console.error(
      'ERROR OCCURED WHILE REMOVING LOCAL STORAGE ITEM',
      'KEY',
      key,
      e
    );
  }
}

export function getSessionStorageItem(key) {
  try {
    return sessionStorage.getItem(key);
  } catch (e) {
    console.error(
      'ERROR OCCURED WHILE GETTING LOCAL STORAGE ITEM',
      'KEY',
      key,
      e
    );
  }
}

export function clearAllSession() {
  sessionStorage.clear();
}
