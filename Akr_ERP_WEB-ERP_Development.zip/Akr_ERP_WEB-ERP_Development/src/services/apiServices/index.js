/* eslint-disable no-undef */
import Axios from 'axios';

export default {
  fetchWithParams: (EndPoint, Token, sucessCallback, errorCallback, params) => {
    Axios.get(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${Token}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
      params: { ...params },
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  GetRequest: (EndPoint, Token, sucessCallback, errorCallback) => {
    Axios.get(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${Token}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  PostRequest: (EndPoint, Token, sucessCallback, errorCallback, values) => {
    Axios.post(
      `${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`,
      values,
      {
        headers: {
          Authorization: `Bearer ${Token}`,
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        timeout: 5000,
      }
    )
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  DeleteRequest: (EndPoint, Token, sucessCallback, errorCallback, values) => {
    Axios.delete(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, {
      headers: {
        Authorization: `Bearer ${Token}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      data: { ...values },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
  PutRequest: (EndPoint, Token, sucessCallback, errorCallback, values) => {
    Axios.put(`${process.env.REACT_APP_BACKEND_API_PROXY}${EndPoint}`, values, {
      headers: {
        Authorization: `Bearer ${Token}`,
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      timeout: 5000,
    })
      .then((resp) => {
        sucessCallback && sucessCallback(resp);
      })
      .catch((err) => {
        errorCallback && errorCallback(err);
      });
  },
};
