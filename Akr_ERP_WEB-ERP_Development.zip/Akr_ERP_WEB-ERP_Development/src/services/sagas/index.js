import { all } from 'redux-saga/effects';
import { loginWatcher } from '../../scenes/slotBooking/services/session/sagas';
import { slotWatcher } from '../../scenes/slotBooking/services/api/dashboard/sagas';
import { UserloginWatcher } from '../../scenes/userManagement/services/session/sagas';
import { userManagementWatcher } from '../../scenes/userManagement/services/api/sagas';
import { AccountsWatcher } from '../../scenes/Accounts/services/api/sagas';
export default function* rootSaga() {
  yield all([
    loginWatcher(),
    slotWatcher(),
    UserloginWatcher(),
    userManagementWatcher(),
    AccountsWatcher(),
  ]);
}
