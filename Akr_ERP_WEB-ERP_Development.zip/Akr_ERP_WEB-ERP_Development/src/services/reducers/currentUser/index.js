import { ACTION_TYPES } from '../../../../constants'
function getDefaultState() {
  //FETCH ALL USER DETAILS FROM LOCAL STORAGE TO AFFECT STORE
  return {
    isFetchingUser: true,
    isFetchingUserFailed: false,
    isFetchingUserError: undefined,
    userDetails: {},
  }
}
const users = (state = getDefaultState(), action) => {
  switch (action.type) {
    case ACTION_TYPES.FETCH_CURRENT_USER_FULFILLED: {
      return {
        ...state,
        isFetchingUser: false,
        isFetchingUserFailed: false,
        isFetchingUserError: undefined,
        userDetails: action.payload.data.data,
      }
    }
  }
}
