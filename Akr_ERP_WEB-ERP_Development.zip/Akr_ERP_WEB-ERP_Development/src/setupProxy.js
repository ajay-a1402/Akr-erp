/* eslint-disable no-undef */
const { createProxyMiddleware } = require('http-proxy-middleware');
module.exports = function (app) {
  console.log(process.env.REACT_APP_BACKEND_API_PROXY);
  app.use(
    '/api/**"',
    createProxyMiddleware({
      target: process.env.REACT_APP_BACKEND_API_PROXY,
      changeOrigin: true,
      pathRewrite: { '^/api': '' },
    })
  );
  //   app.use(
  //     '/cors',
  //     createProxyMiddleware({
  //       target: process.env.REACT_APP_CORS_API_PROXY,
  //       changeOrigin: true,
  //       //ws: true,
  //       /*onProxyReq(proxyReq) {
  //             if (proxyReq.getHeader("origin")) {
  //                 proxyReq.setHeader("origin", "http://159.69.215.121:7000")
  //             }
  //         },*/ //FOR ANY CROS ERROR
  //       pathRewrite: { '^/cors': '' },
  //       //logLevel: 'debug', //ENABLE THIS FOR PROXY LOGGING
  //     })
  //   );
};
